#ifndef org_tartarus_snowball_SnowballProgram_H
#define org_tartarus_snowball_SnowballProgram_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class Serializable;
  }
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace tartarus {
    namespace snowball {

      class SnowballProgram : public ::java::lang::Object {
       public:
        enum {
          mid_getCurrent_cb1e3f35ce7b2bd1,
          mid_getCurrentBuffer_de6d194e81f65e82,
          mid_getCurrentBufferLength_f03edc6a210ac78c,
          mid_setCurrent_9b22ecdee06ea23c,
          mid_setCurrent_aa00de56570a625d,
          mid_insert_06d2355e1ec7a7b4,
          mid_in_grouping_b_3b76c26a1f6c8787,
          mid_eq_s_b_e954bdc5b64f5e34,
          mid_out_grouping_b_3b76c26a1f6c8787,
          mid_find_among_b_f97db12ad2f18ede,
          mid_slice_del_a5783a25d44ba15b,
          mid_slice_from_c3de4787507adac3,
          mid_in_grouping_3b76c26a1f6c8787,
          mid_slice_check_a5783a25d44ba15b,
          mid_replace_s_0cf566d6d3f31642,
          mid_copy_from_40d5b027d948e79f,
          mid_out_grouping_3b76c26a1f6c8787,
          mid_eq_s_e954bdc5b64f5e34,
          mid_find_among_f97db12ad2f18ede,
          mid_slice_to_0888ce519724b72c,
          mid_assign_to_0888ce519724b72c,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit SnowballProgram(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        SnowballProgram(const SnowballProgram& obj) : ::java::lang::Object(obj) {}

        ::java::lang::String getCurrent() const;
        JArray< jchar > getCurrentBuffer() const;
        jint getCurrentBufferLength() const;
        void setCurrent(const ::java::lang::String &) const;
        void setCurrent(const JArray< jchar > &, jint) const;
      };
    }
  }
}

#include <Python.h>

namespace org {
  namespace tartarus {
    namespace snowball {
      extern PyType_Def PY_TYPE_DEF(SnowballProgram);
      extern PyTypeObject *PY_TYPE(SnowballProgram);

      class t_SnowballProgram {
      public:
        PyObject_HEAD
        SnowballProgram object;
        static PyObject *wrap_Object(const SnowballProgram&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
