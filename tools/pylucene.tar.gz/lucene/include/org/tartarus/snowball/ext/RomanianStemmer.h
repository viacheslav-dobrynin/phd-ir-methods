#ifndef org_tartarus_snowball_ext_RomanianStemmer_H
#define org_tartarus_snowball_ext_RomanianStemmer_H

#include "org/tartarus/snowball/SnowballStemmer.h"

namespace java {
  namespace lang {
    class Object;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace tartarus {
    namespace snowball {
      namespace ext {

        class RomanianStemmer : public ::org::tartarus::snowball::SnowballStemmer {
         public:
          enum {
            mid_init$_a5783a25d44ba15b,
            mid_equals_2a09f73f0549554f,
            mid_hashCode_f03edc6a210ac78c,
            mid_stem_201fceb6e9f1d0c5,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit RomanianStemmer(jobject obj) : ::org::tartarus::snowball::SnowballStemmer(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          RomanianStemmer(const RomanianStemmer& obj) : ::org::tartarus::snowball::SnowballStemmer(obj) {}

          RomanianStemmer();

          jboolean equals(const ::java::lang::Object &) const;
          jint hashCode() const;
          jboolean stem() const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace tartarus {
    namespace snowball {
      namespace ext {
        extern PyType_Def PY_TYPE_DEF(RomanianStemmer);
        extern PyTypeObject *PY_TYPE(RomanianStemmer);

        class t_RomanianStemmer {
        public:
          PyObject_HEAD
          RomanianStemmer object;
          static PyObject *wrap_Object(const RomanianStemmer&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
