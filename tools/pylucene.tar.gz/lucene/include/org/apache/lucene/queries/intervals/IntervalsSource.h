#ifndef org_apache_lucene_queries_intervals_IntervalsSource_H
#define org_apache_lucene_queries_intervals_IntervalsSource_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace intervals {
          class IntervalIterator;
          class IntervalMatchesIterator;
          class IntervalsSource;
        }
      }
      namespace search {
        class QueryVisitor;
      }
      namespace index {
        class LeafReaderContext;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace io {
    class IOException;
  }
  namespace util {
    class Collection;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace intervals {

          class IntervalsSource : public ::java::lang::Object {
           public:
            enum {
              mid_init$_a5783a25d44ba15b,
              mid_equals_2a09f73f0549554f,
              mid_hashCode_f03edc6a210ac78c,
              mid_intervals_2018b166ca148f7f,
              mid_matches_79b7ad0e4c2a42b5,
              mid_minExtent_f03edc6a210ac78c,
              mid_pullUpDisjunctions_7ff6744e4f3958ed,
              mid_toString_cb1e3f35ce7b2bd1,
              mid_visit_5317a3ad125acf95,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit IntervalsSource(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            IntervalsSource(const IntervalsSource& obj) : ::java::lang::Object(obj) {}

            IntervalsSource();

            jboolean equals(const ::java::lang::Object &) const;
            jint hashCode() const;
            ::org::apache::lucene::queries::intervals::IntervalIterator intervals(const ::java::lang::String &, const ::org::apache::lucene::index::LeafReaderContext &) const;
            ::org::apache::lucene::queries::intervals::IntervalMatchesIterator matches(const ::java::lang::String &, const ::org::apache::lucene::index::LeafReaderContext &, jint) const;
            jint minExtent() const;
            ::java::util::Collection pullUpDisjunctions() const;
            ::java::lang::String toString() const;
            void visit(const ::java::lang::String &, const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace intervals {
          extern PyType_Def PY_TYPE_DEF(IntervalsSource);
          extern PyTypeObject *PY_TYPE(IntervalsSource);

          class t_IntervalsSource {
          public:
            PyObject_HEAD
            IntervalsSource object;
            static PyObject *wrap_Object(const IntervalsSource&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
