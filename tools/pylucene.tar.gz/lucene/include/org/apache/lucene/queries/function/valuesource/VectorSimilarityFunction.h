#ifndef org_apache_lucene_queries_function_valuesource_VectorSimilarityFunction_H
#define org_apache_lucene_queries_function_valuesource_VectorSimilarityFunction_H

#include "org/apache/lucene/queries/function/ValueSource.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace index {
        class VectorSimilarityFunction;
        class LeafReaderContext;
      }
      namespace queries {
        namespace function {
          class FunctionValues;
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace util {
    class Map;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          namespace valuesource {

            class VectorSimilarityFunction : public ::org::apache::lucene::queries::function::ValueSource {
             public:
              enum {
                mid_init$_487722f6520be9e9,
                mid_description_cb1e3f35ce7b2bd1,
                mid_equals_2a09f73f0549554f,
                mid_getValues_fc4ba0c58720ebff,
                mid_hashCode_f03edc6a210ac78c,
                mid_func_201a6df022e6d97c,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit VectorSimilarityFunction(jobject obj) : ::org::apache::lucene::queries::function::ValueSource(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              VectorSimilarityFunction(const VectorSimilarityFunction& obj) : ::org::apache::lucene::queries::function::ValueSource(obj) {}

              VectorSimilarityFunction(const ::org::apache::lucene::index::VectorSimilarityFunction &, const ::org::apache::lucene::queries::function::ValueSource &, const ::org::apache::lucene::queries::function::ValueSource &);

              ::java::lang::String description() const;
              jboolean equals(const ::java::lang::Object &) const;
              ::org::apache::lucene::queries::function::FunctionValues getValues(const ::java::util::Map &, const ::org::apache::lucene::index::LeafReaderContext &) const;
              jint hashCode() const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          namespace valuesource {
            extern PyType_Def PY_TYPE_DEF(VectorSimilarityFunction);
            extern PyTypeObject *PY_TYPE(VectorSimilarityFunction);

            class t_VectorSimilarityFunction {
            public:
              PyObject_HEAD
              VectorSimilarityFunction object;
              static PyObject *wrap_Object(const VectorSimilarityFunction&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
