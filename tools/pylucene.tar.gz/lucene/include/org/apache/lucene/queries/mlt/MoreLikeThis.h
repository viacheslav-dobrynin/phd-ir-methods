#ifndef org_apache_lucene_queries_mlt_MoreLikeThis_H
#define org_apache_lucene_queries_mlt_MoreLikeThis_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace search {
        namespace similarities {
          class TFIDFSimilarity;
        }
        class Query;
      }
      namespace index {
        class IndexReader;
      }
      namespace analysis {
        class Analyzer;
      }
    }
  }
}
namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace util {
    class Map;
    class Set;
    class Collection;
  }
  namespace io {
    class IOException;
    class Reader;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace mlt {

          class MoreLikeThis : public ::java::lang::Object {
           public:
            enum {
              mid_init$_7f764aba78a42e0c,
              mid_init$_1f9eebe7d6558185,
              mid_describeParams_cb1e3f35ce7b2bd1,
              mid_getAnalyzer_d7b85d5764ff6020,
              mid_getBoostFactor_a9dac2c40463ba96,
              mid_getFieldNames_c0724ba8b8f42824,
              mid_getMaxDocFreq_f03edc6a210ac78c,
              mid_getMaxNumTokensParsed_f03edc6a210ac78c,
              mid_getMaxQueryTerms_f03edc6a210ac78c,
              mid_getMaxWordLen_f03edc6a210ac78c,
              mid_getMinDocFreq_f03edc6a210ac78c,
              mid_getMinTermFreq_f03edc6a210ac78c,
              mid_getMinWordLen_f03edc6a210ac78c,
              mid_getSimilarity_2f034a486a367557,
              mid_getStopWords_9cfd5750b6ef4685,
              mid_isBoost_201fceb6e9f1d0c5,
              mid_like_dd9f4a10e6a45704,
              mid_like_26f76a4f6ad7bbd8,
              mid_like_00ed3fd14dddbfc9,
              mid_retrieveInterestingTerms_e4c45a509d5692fb,
              mid_retrieveInterestingTerms_d83b14dc8958d815,
              mid_setAnalyzer_b2343671f18a93d8,
              mid_setBoost_a5b6a940fc16c6a1,
              mid_setBoostFactor_d35827da2088dce4,
              mid_setFieldNames_d7b3e75f1a119a36,
              mid_setMaxDocFreq_8730ba9dfaf23a7b,
              mid_setMaxDocFreqPct_8730ba9dfaf23a7b,
              mid_setMaxNumTokensParsed_8730ba9dfaf23a7b,
              mid_setMaxQueryTerms_8730ba9dfaf23a7b,
              mid_setMaxWordLen_8730ba9dfaf23a7b,
              mid_setMinDocFreq_8730ba9dfaf23a7b,
              mid_setMinTermFreq_8730ba9dfaf23a7b,
              mid_setMinWordLen_8730ba9dfaf23a7b,
              mid_setSimilarity_ad91285c142f05f8,
              mid_setStopWords_7e00acd17cceab22,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit MoreLikeThis(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            MoreLikeThis(const MoreLikeThis& obj) : ::java::lang::Object(obj) {}

            static jboolean DEFAULT_BOOST;
            static JArray< ::java::lang::String > *DEFAULT_FIELD_NAMES;
            static jint DEFAULT_MAX_DOC_FREQ;
            static jint DEFAULT_MAX_NUM_TOKENS_PARSED;
            static jint DEFAULT_MAX_QUERY_TERMS;
            static jint DEFAULT_MAX_WORD_LENGTH;
            static jint DEFAULT_MIN_DOC_FREQ;
            static jint DEFAULT_MIN_TERM_FREQ;
            static jint DEFAULT_MIN_WORD_LENGTH;
            static ::java::util::Set *DEFAULT_STOP_WORDS;

            MoreLikeThis(const ::org::apache::lucene::index::IndexReader &);
            MoreLikeThis(const ::org::apache::lucene::index::IndexReader &, const ::org::apache::lucene::search::similarities::TFIDFSimilarity &);

            ::java::lang::String describeParams() const;
            ::org::apache::lucene::analysis::Analyzer getAnalyzer() const;
            jfloat getBoostFactor() const;
            JArray< ::java::lang::String > getFieldNames() const;
            jint getMaxDocFreq() const;
            jint getMaxNumTokensParsed() const;
            jint getMaxQueryTerms() const;
            jint getMaxWordLen() const;
            jint getMinDocFreq() const;
            jint getMinTermFreq() const;
            jint getMinWordLen() const;
            ::org::apache::lucene::search::similarities::TFIDFSimilarity getSimilarity() const;
            ::java::util::Set getStopWords() const;
            jboolean isBoost() const;
            ::org::apache::lucene::search::Query like(jint) const;
            ::org::apache::lucene::search::Query like(const ::java::util::Map &) const;
            ::org::apache::lucene::search::Query like(const ::java::lang::String &, const JArray< ::java::io::Reader > &) const;
            JArray< ::java::lang::String > retrieveInterestingTerms(jint) const;
            JArray< ::java::lang::String > retrieveInterestingTerms(const ::java::io::Reader &, const ::java::lang::String &) const;
            void setAnalyzer(const ::org::apache::lucene::analysis::Analyzer &) const;
            void setBoost(jboolean) const;
            void setBoostFactor(jfloat) const;
            void setFieldNames(const JArray< ::java::lang::String > &) const;
            void setMaxDocFreq(jint) const;
            void setMaxDocFreqPct(jint) const;
            void setMaxNumTokensParsed(jint) const;
            void setMaxQueryTerms(jint) const;
            void setMaxWordLen(jint) const;
            void setMinDocFreq(jint) const;
            void setMinTermFreq(jint) const;
            void setMinWordLen(jint) const;
            void setSimilarity(const ::org::apache::lucene::search::similarities::TFIDFSimilarity &) const;
            void setStopWords(const ::java::util::Set &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace mlt {
          extern PyType_Def PY_TYPE_DEF(MoreLikeThis);
          extern PyTypeObject *PY_TYPE(MoreLikeThis);

          class t_MoreLikeThis {
          public:
            PyObject_HEAD
            MoreLikeThis object;
            static PyObject *wrap_Object(const MoreLikeThis&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
