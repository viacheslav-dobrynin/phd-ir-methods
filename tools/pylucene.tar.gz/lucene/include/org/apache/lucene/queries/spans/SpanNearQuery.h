#ifndef org_apache_lucene_queries_spans_SpanNearQuery_H
#define org_apache_lucene_queries_spans_SpanNearQuery_H

#include "org/apache/lucene/queries/spans/SpanQuery.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          class SpanWeight;
          class SpanNearQuery$Builder;
        }
      }
      namespace search {
        class Query;
        class QueryVisitor;
        class IndexSearcher;
        class ScoreMode;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Cloneable;
    class Object;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {

          class SpanNearQuery : public ::org::apache::lucene::queries::spans::SpanQuery {
           public:
            enum {
              mid_init$_8e0751a8328a9633,
              mid_createWeight_9e1f53ad8e8bb167,
              mid_equals_2a09f73f0549554f,
              mid_getClauses_39ae684707aa84b5,
              mid_getField_cb1e3f35ce7b2bd1,
              mid_getSlop_f03edc6a210ac78c,
              mid_hashCode_f03edc6a210ac78c,
              mid_isInOrder_201fceb6e9f1d0c5,
              mid_newOrderedNearQuery_15516585a6018e73,
              mid_newUnorderedNearQuery_15516585a6018e73,
              mid_rewrite_934f770a09887431,
              mid_toString_4fd613927a288526,
              mid_visit_84cb151476e58e4d,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit SpanNearQuery(jobject obj) : ::org::apache::lucene::queries::spans::SpanQuery(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            SpanNearQuery(const SpanNearQuery& obj) : ::org::apache::lucene::queries::spans::SpanQuery(obj) {}

            SpanNearQuery(const JArray< ::org::apache::lucene::queries::spans::SpanQuery > &, jint, jboolean);

            ::org::apache::lucene::queries::spans::SpanWeight createWeight(const ::org::apache::lucene::search::IndexSearcher &, const ::org::apache::lucene::search::ScoreMode &, jfloat) const;
            jboolean equals(const ::java::lang::Object &) const;
            JArray< ::org::apache::lucene::queries::spans::SpanQuery > getClauses() const;
            ::java::lang::String getField() const;
            jint getSlop() const;
            jint hashCode() const;
            jboolean isInOrder() const;
            static ::org::apache::lucene::queries::spans::SpanNearQuery$Builder newOrderedNearQuery(const ::java::lang::String &);
            static ::org::apache::lucene::queries::spans::SpanNearQuery$Builder newUnorderedNearQuery(const ::java::lang::String &);
            ::org::apache::lucene::search::Query rewrite(const ::org::apache::lucene::search::IndexSearcher &) const;
            ::java::lang::String toString(const ::java::lang::String &) const;
            void visit(const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          extern PyType_Def PY_TYPE_DEF(SpanNearQuery);
          extern PyTypeObject *PY_TYPE(SpanNearQuery);

          class t_SpanNearQuery {
          public:
            PyObject_HEAD
            SpanNearQuery object;
            static PyObject *wrap_Object(const SpanNearQuery&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
