#ifndef org_apache_lucene_queries_intervals_FilteredIntervalsSource_H
#define org_apache_lucene_queries_intervals_FilteredIntervalsSource_H

#include "org/apache/lucene/queries/intervals/IntervalsSource.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace intervals {
          class IntervalIterator;
          class IntervalMatchesIterator;
        }
      }
      namespace search {
        class QueryVisitor;
      }
      namespace index {
        class LeafReaderContext;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace io {
    class IOException;
  }
  namespace util {
    class Collection;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace intervals {

          class FilteredIntervalsSource : public ::org::apache::lucene::queries::intervals::IntervalsSource {
           public:
            enum {
              mid_init$_d52c5386154c5a98,
              mid_equals_2a09f73f0549554f,
              mid_hashCode_f03edc6a210ac78c,
              mid_intervals_2018b166ca148f7f,
              mid_matches_79b7ad0e4c2a42b5,
              mid_maxGaps_0ea073c51e093ef7,
              mid_maxWidth_0ea073c51e093ef7,
              mid_minExtent_f03edc6a210ac78c,
              mid_pullUpDisjunctions_7ff6744e4f3958ed,
              mid_toString_cb1e3f35ce7b2bd1,
              mid_visit_5317a3ad125acf95,
              mid_accept_f0b293bd213c7918,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit FilteredIntervalsSource(jobject obj) : ::org::apache::lucene::queries::intervals::IntervalsSource(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            FilteredIntervalsSource(const FilteredIntervalsSource& obj) : ::org::apache::lucene::queries::intervals::IntervalsSource(obj) {}

            FilteredIntervalsSource(const ::java::lang::String &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);

            jboolean equals(const ::java::lang::Object &) const;
            jint hashCode() const;
            ::org::apache::lucene::queries::intervals::IntervalIterator intervals(const ::java::lang::String &, const ::org::apache::lucene::index::LeafReaderContext &) const;
            ::org::apache::lucene::queries::intervals::IntervalMatchesIterator matches(const ::java::lang::String &, const ::org::apache::lucene::index::LeafReaderContext &, jint) const;
            static ::org::apache::lucene::queries::intervals::IntervalsSource maxGaps(const ::org::apache::lucene::queries::intervals::IntervalsSource &, jint);
            static ::org::apache::lucene::queries::intervals::IntervalsSource maxWidth(const ::org::apache::lucene::queries::intervals::IntervalsSource &, jint);
            jint minExtent() const;
            ::java::util::Collection pullUpDisjunctions() const;
            ::java::lang::String toString() const;
            void visit(const ::java::lang::String &, const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace intervals {
          extern PyType_Def PY_TYPE_DEF(FilteredIntervalsSource);
          extern PyTypeObject *PY_TYPE(FilteredIntervalsSource);

          class t_FilteredIntervalsSource {
          public:
            PyObject_HEAD
            FilteredIntervalsSource object;
            static PyObject *wrap_Object(const FilteredIntervalsSource&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
