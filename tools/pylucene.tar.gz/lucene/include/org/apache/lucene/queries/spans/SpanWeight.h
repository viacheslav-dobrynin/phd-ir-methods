#ifndef org_apache_lucene_queries_spans_SpanWeight_H
#define org_apache_lucene_queries_spans_SpanWeight_H

#include "org/apache/lucene/search/Weight.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          class SpanQuery;
          class Spans;
          class SpanWeight$Postings;
        }
      }
      namespace index {
        class Term;
        class TermStates;
        class LeafReaderContext;
      }
      namespace search {
        class Matches;
        class IndexSearcher;
        class Explanation;
        class LeafSimScorer;
        class ScorerSupplier;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
  }
  namespace util {
    class Map;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {

          class SpanWeight : public ::org::apache::lucene::search::Weight {
           public:
            enum {
              mid_init$_3d6c04c6a8b30963,
              mid_explain_cfea02f1f9d81777,
              mid_extractTermStates_5063440bb525b708,
              mid_getSimScorer_c6289130b6d5875d,
              mid_getSpans_f791c97b68d32a93,
              mid_matches_699f808f60545acd,
              mid_scorerSupplier_86f15d2ab90a768f,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit SpanWeight(jobject obj) : ::org::apache::lucene::search::Weight(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            SpanWeight(const SpanWeight& obj) : ::org::apache::lucene::search::Weight(obj) {}

            SpanWeight(const ::org::apache::lucene::queries::spans::SpanQuery &, const ::org::apache::lucene::search::IndexSearcher &, const ::java::util::Map &, jfloat);

            ::org::apache::lucene::search::Explanation explain(const ::org::apache::lucene::index::LeafReaderContext &, jint) const;
            void extractTermStates(const ::java::util::Map &) const;
            ::org::apache::lucene::search::LeafSimScorer getSimScorer(const ::org::apache::lucene::index::LeafReaderContext &) const;
            ::org::apache::lucene::queries::spans::Spans getSpans(const ::org::apache::lucene::index::LeafReaderContext &, const ::org::apache::lucene::queries::spans::SpanWeight$Postings &) const;
            ::org::apache::lucene::search::Matches matches(const ::org::apache::lucene::index::LeafReaderContext &, jint) const;
            ::org::apache::lucene::search::ScorerSupplier scorerSupplier(const ::org::apache::lucene::index::LeafReaderContext &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          extern PyType_Def PY_TYPE_DEF(SpanWeight);
          extern PyTypeObject *PY_TYPE(SpanWeight);

          class t_SpanWeight {
          public:
            PyObject_HEAD
            SpanWeight object;
            static PyObject *wrap_Object(const SpanWeight&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
