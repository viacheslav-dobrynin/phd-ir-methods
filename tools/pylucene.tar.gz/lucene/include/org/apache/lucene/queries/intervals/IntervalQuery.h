#ifndef org_apache_lucene_queries_intervals_IntervalQuery_H
#define org_apache_lucene_queries_intervals_IntervalQuery_H

#include "org/apache/lucene/search/Query.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace search {
        class QueryVisitor;
        class IndexSearcher;
        class ScoreMode;
        class Weight;
      }
      namespace queries {
        namespace intervals {
          class IntervalsSource;
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace intervals {

          class IntervalQuery : public ::org::apache::lucene::search::Query {
           public:
            enum {
              mid_init$_d52c5386154c5a98,
              mid_init$_d16c2b82b0c3c110,
              mid_init$_9a05b07351b1ba5b,
              mid_createWeight_1ffda6c7942c608a,
              mid_equals_2a09f73f0549554f,
              mid_getField_cb1e3f35ce7b2bd1,
              mid_hashCode_f03edc6a210ac78c,
              mid_toString_4fd613927a288526,
              mid_visit_84cb151476e58e4d,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit IntervalQuery(jobject obj) : ::org::apache::lucene::search::Query(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            IntervalQuery(const IntervalQuery& obj) : ::org::apache::lucene::search::Query(obj) {}

            IntervalQuery(const ::java::lang::String &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            IntervalQuery(const ::java::lang::String &, const ::org::apache::lucene::queries::intervals::IntervalsSource &, jfloat);
            IntervalQuery(const ::java::lang::String &, const ::org::apache::lucene::queries::intervals::IntervalsSource &, jfloat, jfloat);

            ::org::apache::lucene::search::Weight createWeight(const ::org::apache::lucene::search::IndexSearcher &, const ::org::apache::lucene::search::ScoreMode &, jfloat) const;
            jboolean equals(const ::java::lang::Object &) const;
            ::java::lang::String getField() const;
            jint hashCode() const;
            ::java::lang::String toString(const ::java::lang::String &) const;
            void visit(const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace intervals {
          extern PyType_Def PY_TYPE_DEF(IntervalQuery);
          extern PyTypeObject *PY_TYPE(IntervalQuery);

          class t_IntervalQuery {
          public:
            PyObject_HEAD
            IntervalQuery object;
            static PyObject *wrap_Object(const IntervalQuery&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
