#ifndef org_apache_lucene_queries_CommonTermsQuery_H
#define org_apache_lucene_queries_CommonTermsQuery_H

#include "org/apache/lucene/search/Query.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace util {
    class List;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace index {
        class IndexReader;
        class Term;
        class TermStates;
        class LeafReaderContext;
      }
      namespace search {
        class QueryVisitor;
        class IndexSearcher;
        class BooleanClause$Occur;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {

        class CommonTermsQuery : public ::org::apache::lucene::search::Query {
         public:
          enum {
            mid_init$_ee4477bf17aadcc0,
            mid_add_f0ea16905547f5c1,
            mid_collectTermStates_4a62b5a5992b2479,
            mid_equals_2a09f73f0549554f,
            mid_getHighFreqBoost_a9dac2c40463ba96,
            mid_getHighFreqMinimumNumberShouldMatch_a9dac2c40463ba96,
            mid_getHighFreqOccur_22a1757e1a1f4950,
            mid_getLowFreqBoost_a9dac2c40463ba96,
            mid_getLowFreqMinimumNumberShouldMatch_a9dac2c40463ba96,
            mid_getLowFreqOccur_22a1757e1a1f4950,
            mid_getMaxTermFrequency_a9dac2c40463ba96,
            mid_getTerms_7b3206bb4e2462d2,
            mid_hashCode_f03edc6a210ac78c,
            mid_rewrite_934f770a09887431,
            mid_setHighFreqMinimumNumberShouldMatch_d35827da2088dce4,
            mid_setLowFreqMinimumNumberShouldMatch_d35827da2088dce4,
            mid_toString_4fd613927a288526,
            mid_visit_84cb151476e58e4d,
            mid_newTermQuery_cbe6d9b359c904df,
            mid_buildQuery_7280026db1bcb71b,
            mid_calcLowFreqMinimumNumberShouldMatch_ff66fe240ad72894,
            mid_calcHighFreqMinimumNumberShouldMatch_ff66fe240ad72894,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit CommonTermsQuery(jobject obj) : ::org::apache::lucene::search::Query(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          CommonTermsQuery(const CommonTermsQuery& obj) : ::org::apache::lucene::search::Query(obj) {}

          CommonTermsQuery(const ::org::apache::lucene::search::BooleanClause$Occur &, const ::org::apache::lucene::search::BooleanClause$Occur &, jfloat);

          void add(const ::org::apache::lucene::index::Term &) const;
          void collectTermStates(const ::org::apache::lucene::index::IndexReader &, const ::java::util::List &, const JArray< ::org::apache::lucene::index::TermStates > &, const JArray< ::org::apache::lucene::index::Term > &) const;
          jboolean equals(const ::java::lang::Object &) const;
          jfloat getHighFreqBoost() const;
          jfloat getHighFreqMinimumNumberShouldMatch() const;
          ::org::apache::lucene::search::BooleanClause$Occur getHighFreqOccur() const;
          jfloat getLowFreqBoost() const;
          jfloat getLowFreqMinimumNumberShouldMatch() const;
          ::org::apache::lucene::search::BooleanClause$Occur getLowFreqOccur() const;
          jfloat getMaxTermFrequency() const;
          ::java::util::List getTerms() const;
          jint hashCode() const;
          ::org::apache::lucene::search::Query rewrite(const ::org::apache::lucene::search::IndexSearcher &) const;
          void setHighFreqMinimumNumberShouldMatch(jfloat) const;
          void setLowFreqMinimumNumberShouldMatch(jfloat) const;
          ::java::lang::String toString(const ::java::lang::String &) const;
          void visit(const ::org::apache::lucene::search::QueryVisitor &) const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        extern PyType_Def PY_TYPE_DEF(CommonTermsQuery);
        extern PyTypeObject *PY_TYPE(CommonTermsQuery);

        class t_CommonTermsQuery {
        public:
          PyObject_HEAD
          CommonTermsQuery object;
          static PyObject *wrap_Object(const CommonTermsQuery&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
