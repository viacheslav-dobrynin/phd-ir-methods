#ifndef org_apache_lucene_queries_function_valuesource_SortedSetFieldSource_H
#define org_apache_lucene_queries_function_valuesource_SortedSetFieldSource_H

#include "org/apache/lucene/queries/function/valuesource/FieldCacheSource.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace search {
        class SortField;
        class SortedSetSelector$Type;
      }
      namespace queries {
        namespace function {
          class FunctionValues;
        }
      }
      namespace index {
        class LeafReaderContext;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace util {
    class Map;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          namespace valuesource {

            class SortedSetFieldSource : public ::org::apache::lucene::queries::function::valuesource::FieldCacheSource {
             public:
              enum {
                mid_init$_9b22ecdee06ea23c,
                mid_init$_5bc977f81ba03eb6,
                mid_description_cb1e3f35ce7b2bd1,
                mid_equals_2a09f73f0549554f,
                mid_getSortField_3bc7bf5849b97a27,
                mid_getValues_fc4ba0c58720ebff,
                mid_hashCode_f03edc6a210ac78c,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit SortedSetFieldSource(jobject obj) : ::org::apache::lucene::queries::function::valuesource::FieldCacheSource(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              SortedSetFieldSource(const SortedSetFieldSource& obj) : ::org::apache::lucene::queries::function::valuesource::FieldCacheSource(obj) {}

              SortedSetFieldSource(const ::java::lang::String &);
              SortedSetFieldSource(const ::java::lang::String &, const ::org::apache::lucene::search::SortedSetSelector$Type &);

              ::java::lang::String description() const;
              jboolean equals(const ::java::lang::Object &) const;
              ::org::apache::lucene::search::SortField getSortField(jboolean) const;
              ::org::apache::lucene::queries::function::FunctionValues getValues(const ::java::util::Map &, const ::org::apache::lucene::index::LeafReaderContext &) const;
              jint hashCode() const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          namespace valuesource {
            extern PyType_Def PY_TYPE_DEF(SortedSetFieldSource);
            extern PyTypeObject *PY_TYPE(SortedSetFieldSource);

            class t_SortedSetFieldSource {
            public:
              PyObject_HEAD
              SortedSetFieldSource object;
              static PyObject *wrap_Object(const SortedSetFieldSource&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
