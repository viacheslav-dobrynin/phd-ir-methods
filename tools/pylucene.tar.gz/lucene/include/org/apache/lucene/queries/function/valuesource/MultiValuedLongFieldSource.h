#ifndef org_apache_lucene_queries_function_valuesource_MultiValuedLongFieldSource_H
#define org_apache_lucene_queries_function_valuesource_MultiValuedLongFieldSource_H

#include "org/apache/lucene/queries/function/valuesource/LongFieldSource.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace search {
        class SortField;
        class SortedNumericSelector$Type;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          namespace valuesource {

            class MultiValuedLongFieldSource : public ::org::apache::lucene::queries::function::valuesource::LongFieldSource {
             public:
              enum {
                mid_init$_628f061a7911461c,
                mid_description_cb1e3f35ce7b2bd1,
                mid_equals_2a09f73f0549554f,
                mid_getSortField_3bc7bf5849b97a27,
                mid_hashCode_f03edc6a210ac78c,
                mid_getNumericDocValues_98a2674df5fc27c4,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit MultiValuedLongFieldSource(jobject obj) : ::org::apache::lucene::queries::function::valuesource::LongFieldSource(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              MultiValuedLongFieldSource(const MultiValuedLongFieldSource& obj) : ::org::apache::lucene::queries::function::valuesource::LongFieldSource(obj) {}

              MultiValuedLongFieldSource(const ::java::lang::String &, const ::org::apache::lucene::search::SortedNumericSelector$Type &);

              ::java::lang::String description() const;
              jboolean equals(const ::java::lang::Object &) const;
              ::org::apache::lucene::search::SortField getSortField(jboolean) const;
              jint hashCode() const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          namespace valuesource {
            extern PyType_Def PY_TYPE_DEF(MultiValuedLongFieldSource);
            extern PyTypeObject *PY_TYPE(MultiValuedLongFieldSource);

            class t_MultiValuedLongFieldSource {
            public:
              PyObject_HEAD
              MultiValuedLongFieldSource object;
              static PyObject *wrap_Object(const MultiValuedLongFieldSource&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
