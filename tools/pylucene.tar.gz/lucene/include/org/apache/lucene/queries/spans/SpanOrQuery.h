#ifndef org_apache_lucene_queries_spans_SpanOrQuery_H
#define org_apache_lucene_queries_spans_SpanOrQuery_H

#include "org/apache/lucene/queries/spans/SpanQuery.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          class SpanWeight;
        }
      }
      namespace search {
        class Query;
        class QueryVisitor;
        class IndexSearcher;
        class ScoreMode;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {

          class SpanOrQuery : public ::org::apache::lucene::queries::spans::SpanQuery {
           public:
            enum {
              mid_init$_e236ceef92368ea2,
              mid_createWeight_9e1f53ad8e8bb167,
              mid_equals_2a09f73f0549554f,
              mid_getClauses_39ae684707aa84b5,
              mid_getField_cb1e3f35ce7b2bd1,
              mid_hashCode_f03edc6a210ac78c,
              mid_rewrite_934f770a09887431,
              mid_toString_4fd613927a288526,
              mid_visit_84cb151476e58e4d,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit SpanOrQuery(jobject obj) : ::org::apache::lucene::queries::spans::SpanQuery(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            SpanOrQuery(const SpanOrQuery& obj) : ::org::apache::lucene::queries::spans::SpanQuery(obj) {}

            SpanOrQuery(const JArray< ::org::apache::lucene::queries::spans::SpanQuery > &);

            ::org::apache::lucene::queries::spans::SpanWeight createWeight(const ::org::apache::lucene::search::IndexSearcher &, const ::org::apache::lucene::search::ScoreMode &, jfloat) const;
            jboolean equals(const ::java::lang::Object &) const;
            JArray< ::org::apache::lucene::queries::spans::SpanQuery > getClauses() const;
            ::java::lang::String getField() const;
            jint hashCode() const;
            ::org::apache::lucene::search::Query rewrite(const ::org::apache::lucene::search::IndexSearcher &) const;
            ::java::lang::String toString(const ::java::lang::String &) const;
            void visit(const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          extern PyType_Def PY_TYPE_DEF(SpanOrQuery);
          extern PyTypeObject *PY_TYPE(SpanOrQuery);

          class t_SpanOrQuery {
          public:
            PyObject_HEAD
            SpanOrQuery object;
            static PyObject *wrap_Object(const SpanOrQuery&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
