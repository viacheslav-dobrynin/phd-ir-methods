#ifndef org_apache_lucene_queries_spans_SpanPositionRangeQuery_H
#define org_apache_lucene_queries_spans_SpanPositionRangeQuery_H

#include "org/apache/lucene/queries/spans/SpanPositionCheckQuery.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          class SpanQuery;
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class Object;
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {

          class SpanPositionRangeQuery : public ::org::apache::lucene::queries::spans::SpanPositionCheckQuery {
           public:
            enum {
              mid_init$_5c78255b236a01c8,
              mid_equals_2a09f73f0549554f,
              mid_getEnd_f03edc6a210ac78c,
              mid_getStart_f03edc6a210ac78c,
              mid_hashCode_f03edc6a210ac78c,
              mid_toString_4fd613927a288526,
              mid_acceptPosition_b53aa17c2911c66e,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit SpanPositionRangeQuery(jobject obj) : ::org::apache::lucene::queries::spans::SpanPositionCheckQuery(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            SpanPositionRangeQuery(const SpanPositionRangeQuery& obj) : ::org::apache::lucene::queries::spans::SpanPositionCheckQuery(obj) {}

            SpanPositionRangeQuery(const ::org::apache::lucene::queries::spans::SpanQuery &, jint, jint);

            jboolean equals(const ::java::lang::Object &) const;
            jint getEnd() const;
            jint getStart() const;
            jint hashCode() const;
            ::java::lang::String toString(const ::java::lang::String &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          extern PyType_Def PY_TYPE_DEF(SpanPositionRangeQuery);
          extern PyTypeObject *PY_TYPE(SpanPositionRangeQuery);

          class t_SpanPositionRangeQuery {
          public:
            PyObject_HEAD
            SpanPositionRangeQuery object;
            static PyObject *wrap_Object(const SpanPositionRangeQuery&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
