#ifndef org_apache_lucene_queries_function_FunctionScoreQuery_H
#define org_apache_lucene_queries_function_FunctionScoreQuery_H

#include "org/apache/lucene/search/Query.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace search {
        class DoubleValuesSource;
        class QueryVisitor;
        class IndexSearcher;
        class ScoreMode;
        class Weight;
      }
      namespace queries {
        namespace function {
          class FunctionScoreQuery;
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {

          class FunctionScoreQuery : public ::org::apache::lucene::search::Query {
           public:
            enum {
              mid_init$_8fdff643da68caad,
              mid_boostByQuery_7711026c219256f1,
              mid_boostByValue_8d64fcc7b705a11d,
              mid_createWeight_1ffda6c7942c608a,
              mid_equals_2a09f73f0549554f,
              mid_getSource_10955d385334386e,
              mid_getWrappedQuery_1bbb14eb001e7ebc,
              mid_hashCode_f03edc6a210ac78c,
              mid_rewrite_934f770a09887431,
              mid_toString_4fd613927a288526,
              mid_visit_84cb151476e58e4d,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit FunctionScoreQuery(jobject obj) : ::org::apache::lucene::search::Query(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            FunctionScoreQuery(const FunctionScoreQuery& obj) : ::org::apache::lucene::search::Query(obj) {}

            FunctionScoreQuery(const ::org::apache::lucene::search::Query &, const ::org::apache::lucene::search::DoubleValuesSource &);

            static FunctionScoreQuery boostByQuery(const ::org::apache::lucene::search::Query &, const ::org::apache::lucene::search::Query &, jfloat);
            static FunctionScoreQuery boostByValue(const ::org::apache::lucene::search::Query &, const ::org::apache::lucene::search::DoubleValuesSource &);
            ::org::apache::lucene::search::Weight createWeight(const ::org::apache::lucene::search::IndexSearcher &, const ::org::apache::lucene::search::ScoreMode &, jfloat) const;
            jboolean equals(const ::java::lang::Object &) const;
            ::org::apache::lucene::search::DoubleValuesSource getSource() const;
            ::org::apache::lucene::search::Query getWrappedQuery() const;
            jint hashCode() const;
            ::org::apache::lucene::search::Query rewrite(const ::org::apache::lucene::search::IndexSearcher &) const;
            ::java::lang::String toString(const ::java::lang::String &) const;
            void visit(const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          extern PyType_Def PY_TYPE_DEF(FunctionScoreQuery);
          extern PyTypeObject *PY_TYPE(FunctionScoreQuery);

          class t_FunctionScoreQuery {
          public:
            PyObject_HEAD
            FunctionScoreQuery object;
            static PyObject *wrap_Object(const FunctionScoreQuery&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
