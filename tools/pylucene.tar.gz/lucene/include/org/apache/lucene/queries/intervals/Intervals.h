#ifndef org_apache_lucene_queries_intervals_Intervals_H
#define org_apache_lucene_queries_intervals_Intervals_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace analysis {
        class TokenStream;
        class Analyzer;
      }
      namespace util {
        class BytesRef;
        namespace automaton {
          class CompiledAutomaton;
        }
      }
      namespace queries {
        namespace intervals {
          class IntervalsSource;
        }
      }
    }
  }
}
namespace java {
  namespace util {
    class List;
    namespace function {
      class Predicate;
    }
  }
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace intervals {

          class Intervals : public ::java::lang::Object {
           public:
            enum {
              mid_after_9693b8de8066415e,
              mid_analyzedText_1d4bf6d82177f1b9,
              mid_analyzedText_411edf5cadcfd7de,
              mid_atLeast_592ebea14c5bc3b9,
              mid_before_9693b8de8066415e,
              mid_containedBy_9693b8de8066415e,
              mid_containing_9693b8de8066415e,
              mid_extend_5a563aa7ba0780db,
              mid_fixField_93de758063b31691,
              mid_fuzzyTerm_e0263f90a1d10f88,
              mid_fuzzyTerm_cb3deb2ea05ed26e,
              mid_maxgaps_f1bc11881689ccec,
              mid_maxwidth_f1bc11881689ccec,
              mid_multiterm_fa46c03f2809fef3,
              mid_multiterm_0faad52fcbd5f1b9,
              mid_noIntervals_369cb79745953eab,
              mid_nonOverlapping_9693b8de8066415e,
              mid_notContainedBy_9693b8de8066415e,
              mid_notContaining_9693b8de8066415e,
              mid_notWithin_d3992ca93e6ea6bc,
              mid_or_08b85680240ee769,
              mid_or_ae11cac0fdfe59d9,
              mid_or_599f27e541def3be,
              mid_or_6fa1f38d35ca3846,
              mid_ordered_08b85680240ee769,
              mid_overlapping_9693b8de8066415e,
              mid_phrase_bcafcb599a48be66,
              mid_phrase_08b85680240ee769,
              mid_prefix_27b905b8f3ade23c,
              mid_prefix_e17da1eacbb8d972,
              mid_range_4ba08029d1aaa19b,
              mid_range_799558e1ba2c40c9,
              mid_regexp_27b905b8f3ade23c,
              mid_regexp_e17da1eacbb8d972,
              mid_term_369cb79745953eab,
              mid_term_27b905b8f3ade23c,
              mid_term_ce2d13f7bafc80c1,
              mid_term_b28b3c41d13773ef,
              mid_unordered_08b85680240ee769,
              mid_unorderedNoOverlaps_9693b8de8066415e,
              mid_wildcard_27b905b8f3ade23c,
              mid_wildcard_e17da1eacbb8d972,
              mid_within_d3992ca93e6ea6bc,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit Intervals(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            Intervals(const Intervals& obj) : ::java::lang::Object(obj) {}

            static jint DEFAULT_MAX_EXPANSIONS;

            static ::org::apache::lucene::queries::intervals::IntervalsSource after(const ::org::apache::lucene::queries::intervals::IntervalsSource &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource analyzedText(const ::org::apache::lucene::analysis::TokenStream &, jint, jboolean);
            static ::org::apache::lucene::queries::intervals::IntervalsSource analyzedText(const ::java::lang::String &, const ::org::apache::lucene::analysis::Analyzer &, const ::java::lang::String &, jint, jboolean);
            static ::org::apache::lucene::queries::intervals::IntervalsSource atLeast(jint, const JArray< ::org::apache::lucene::queries::intervals::IntervalsSource > &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource before(const ::org::apache::lucene::queries::intervals::IntervalsSource &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource containedBy(const ::org::apache::lucene::queries::intervals::IntervalsSource &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource containing(const ::org::apache::lucene::queries::intervals::IntervalsSource &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource extend(const ::org::apache::lucene::queries::intervals::IntervalsSource &, jint, jint);
            static ::org::apache::lucene::queries::intervals::IntervalsSource fixField(const ::java::lang::String &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource fuzzyTerm(const ::java::lang::String &, jint);
            static ::org::apache::lucene::queries::intervals::IntervalsSource fuzzyTerm(const ::java::lang::String &, jint, jint, jboolean, jint);
            static ::org::apache::lucene::queries::intervals::IntervalsSource maxgaps(jint, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource maxwidth(jint, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource multiterm(const ::org::apache::lucene::util::automaton::CompiledAutomaton &, const ::java::lang::String &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource multiterm(const ::org::apache::lucene::util::automaton::CompiledAutomaton &, jint, const ::java::lang::String &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource noIntervals(const ::java::lang::String &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource nonOverlapping(const ::org::apache::lucene::queries::intervals::IntervalsSource &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource notContainedBy(const ::org::apache::lucene::queries::intervals::IntervalsSource &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource notContaining(const ::org::apache::lucene::queries::intervals::IntervalsSource &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource notWithin(const ::org::apache::lucene::queries::intervals::IntervalsSource &, jint, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource or$(const JArray< ::org::apache::lucene::queries::intervals::IntervalsSource > &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource or$(const ::java::util::List &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource or$(jboolean, const JArray< ::org::apache::lucene::queries::intervals::IntervalsSource > &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource or$(jboolean, const ::java::util::List &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource ordered(const JArray< ::org::apache::lucene::queries::intervals::IntervalsSource > &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource overlapping(const ::org::apache::lucene::queries::intervals::IntervalsSource &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource phrase(const JArray< ::java::lang::String > &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource phrase(const JArray< ::org::apache::lucene::queries::intervals::IntervalsSource > &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource prefix(const ::org::apache::lucene::util::BytesRef &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource prefix(const ::org::apache::lucene::util::BytesRef &, jint);
            static ::org::apache::lucene::queries::intervals::IntervalsSource range(const ::org::apache::lucene::util::BytesRef &, const ::org::apache::lucene::util::BytesRef &, jboolean, jboolean);
            static ::org::apache::lucene::queries::intervals::IntervalsSource range(const ::org::apache::lucene::util::BytesRef &, const ::org::apache::lucene::util::BytesRef &, jboolean, jboolean, jint);
            static ::org::apache::lucene::queries::intervals::IntervalsSource regexp(const ::org::apache::lucene::util::BytesRef &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource regexp(const ::org::apache::lucene::util::BytesRef &, jint);
            static ::org::apache::lucene::queries::intervals::IntervalsSource term(const ::java::lang::String &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource term(const ::org::apache::lucene::util::BytesRef &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource term(const ::java::lang::String &, const ::java::util::function::Predicate &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource term(const ::org::apache::lucene::util::BytesRef &, const ::java::util::function::Predicate &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource unordered(const JArray< ::org::apache::lucene::queries::intervals::IntervalsSource > &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource unorderedNoOverlaps(const ::org::apache::lucene::queries::intervals::IntervalsSource &, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource wildcard(const ::org::apache::lucene::util::BytesRef &);
            static ::org::apache::lucene::queries::intervals::IntervalsSource wildcard(const ::org::apache::lucene::util::BytesRef &, jint);
            static ::org::apache::lucene::queries::intervals::IntervalsSource within(const ::org::apache::lucene::queries::intervals::IntervalsSource &, jint, const ::org::apache::lucene::queries::intervals::IntervalsSource &);
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace intervals {
          extern PyType_Def PY_TYPE_DEF(Intervals);
          extern PyTypeObject *PY_TYPE(Intervals);

          class t_Intervals {
          public:
            PyObject_HEAD
            Intervals object;
            static PyObject *wrap_Object(const Intervals&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
