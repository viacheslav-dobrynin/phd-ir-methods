#ifndef org_apache_lucene_queries_function_FunctionValues_H
#define org_apache_lucene_queries_function_FunctionValues_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          class FunctionValues$ValueFiller;
          class ValueSourceScorer;
        }
      }
      namespace index {
        class LeafReaderContext;
      }
      namespace util {
        class BytesRefBuilder;
      }
      namespace search {
        class Explanation;
      }
    }
  }
}
namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {

          class FunctionValues : public ::java::lang::Object {
           public:
            enum {
              mid_init$_a5783a25d44ba15b,
              mid_boolVal_12fe561dd4de11f3,
              mid_byteVal_84ab8169028f033c,
              mid_byteVal_711c0f1b2324b40a,
              mid_byteVectorVal_c64573f38e8a66b0,
              mid_bytesVal_6285b110a85e3979,
              mid_cost_a9dac2c40463ba96,
              mid_doubleVal_c08ef01829a1bee6,
              mid_doubleVal_e23cea9ff2d6be72,
              mid_exists_12fe561dd4de11f3,
              mid_explain_85a0ee0c99c9a912,
              mid_floatVal_774c70860a3c670a,
              mid_floatVal_0d95389ef46195c5,
              mid_floatVectorVal_5bde8ca8e5c3696b,
              mid_getRangeScorer_942a86a5f022648a,
              mid_getScorer_9a954c651aa411b3,
              mid_getValueFiller_2cecd85c6542b531,
              mid_intVal_ff66fe240ad72894,
              mid_intVal_1d1159a43be048b0,
              mid_longVal_ea9b180a0520cdd6,
              mid_longVal_6682b4456634c3a4,
              mid_numOrd_f03edc6a210ac78c,
              mid_objectVal_1dce87679d904d14,
              mid_ordVal_ff66fe240ad72894,
              mid_shortVal_ec0a5b151bc158c7,
              mid_shortVal_511dc6362328a147,
              mid_strVal_aebd86204175b724,
              mid_strVal_c49753e646e40128,
              mid_toString_aebd86204175b724,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit FunctionValues(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            FunctionValues(const FunctionValues& obj) : ::java::lang::Object(obj) {}

            FunctionValues();

            jboolean boolVal(jint) const;
            jbyte byteVal(jint) const;
            void byteVal(jint, const JArray< jbyte > &) const;
            JArray< jbyte > byteVectorVal(jint) const;
            jboolean bytesVal(jint, const ::org::apache::lucene::util::BytesRefBuilder &) const;
            jfloat cost() const;
            jdouble doubleVal(jint) const;
            void doubleVal(jint, const JArray< jdouble > &) const;
            jboolean exists(jint) const;
            ::org::apache::lucene::search::Explanation explain(jint) const;
            jfloat floatVal(jint) const;
            void floatVal(jint, const JArray< jfloat > &) const;
            JArray< jfloat > floatVectorVal(jint) const;
            ::org::apache::lucene::queries::function::ValueSourceScorer getRangeScorer(const ::org::apache::lucene::index::LeafReaderContext &, const ::java::lang::String &, const ::java::lang::String &, jboolean, jboolean) const;
            ::org::apache::lucene::queries::function::ValueSourceScorer getScorer(const ::org::apache::lucene::index::LeafReaderContext &) const;
            ::org::apache::lucene::queries::function::FunctionValues$ValueFiller getValueFiller() const;
            jint intVal(jint) const;
            void intVal(jint, const JArray< jint > &) const;
            jlong longVal(jint) const;
            void longVal(jint, const JArray< jlong > &) const;
            jint numOrd() const;
            ::java::lang::Object objectVal(jint) const;
            jint ordVal(jint) const;
            jshort shortVal(jint) const;
            void shortVal(jint, const JArray< jshort > &) const;
            ::java::lang::String strVal(jint) const;
            void strVal(jint, const JArray< ::java::lang::String > &) const;
            ::java::lang::String toString(jint) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          extern PyType_Def PY_TYPE_DEF(FunctionValues);
          extern PyTypeObject *PY_TYPE(FunctionValues);

          class t_FunctionValues {
          public:
            PyObject_HEAD
            FunctionValues object;
            static PyObject *wrap_Object(const FunctionValues&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
