#ifndef org_apache_lucene_queries_function_docvalues_IntDocValues_H
#define org_apache_lucene_queries_function_docvalues_IntDocValues_H

#include "org/apache/lucene/queries/function/FunctionValues.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          class FunctionValues$ValueFiller;
          class ValueSource;
          class ValueSourceScorer;
        }
      }
      namespace index {
        class LeafReaderContext;
      }
    }
  }
}
namespace java {
  namespace lang {
    class String;
    class Class;
    class Object;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          namespace docvalues {

            class IntDocValues : public ::org::apache::lucene::queries::function::FunctionValues {
             public:
              enum {
                mid_init$_60f6db2a980466d1,
                mid_byteVal_84ab8169028f033c,
                mid_doubleVal_c08ef01829a1bee6,
                mid_floatVal_774c70860a3c670a,
                mid_getRangeScorer_942a86a5f022648a,
                mid_getValueFiller_2cecd85c6542b531,
                mid_intVal_ff66fe240ad72894,
                mid_longVal_ea9b180a0520cdd6,
                mid_objectVal_1dce87679d904d14,
                mid_shortVal_ec0a5b151bc158c7,
                mid_strVal_aebd86204175b724,
                mid_toString_aebd86204175b724,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit IntDocValues(jobject obj) : ::org::apache::lucene::queries::function::FunctionValues(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              IntDocValues(const IntDocValues& obj) : ::org::apache::lucene::queries::function::FunctionValues(obj) {}

              IntDocValues(const ::org::apache::lucene::queries::function::ValueSource &);

              jbyte byteVal(jint) const;
              jdouble doubleVal(jint) const;
              jfloat floatVal(jint) const;
              ::org::apache::lucene::queries::function::ValueSourceScorer getRangeScorer(const ::org::apache::lucene::index::LeafReaderContext &, const ::java::lang::String &, const ::java::lang::String &, jboolean, jboolean) const;
              ::org::apache::lucene::queries::function::FunctionValues$ValueFiller getValueFiller() const;
              jint intVal(jint) const;
              jlong longVal(jint) const;
              ::java::lang::Object objectVal(jint) const;
              jshort shortVal(jint) const;
              ::java::lang::String strVal(jint) const;
              ::java::lang::String toString(jint) const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          namespace docvalues {
            extern PyType_Def PY_TYPE_DEF(IntDocValues);
            extern PyTypeObject *PY_TYPE(IntDocValues);

            class t_IntDocValues {
            public:
              PyObject_HEAD
              IntDocValues object;
              static PyObject *wrap_Object(const IntDocValues&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
