#ifndef org_apache_lucene_queries_spans_SpanScorer_H
#define org_apache_lucene_queries_spans_SpanScorer_H

#include "org/apache/lucene/search/Scorer.h"

namespace java {
  namespace lang {
    class Class;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          class Spans;
        }
      }
      namespace search {
        class DocIdSetIterator;
        class TwoPhaseIterator;
        class LeafSimScorer;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {

          class SpanScorer : public ::org::apache::lucene::search::Scorer {
           public:
            enum {
              mid_init$_540c63be45bddfeb,
              mid_docID_f03edc6a210ac78c,
              mid_getMaxScore_774c70860a3c670a,
              mid_getSpans_4aac15403148b9d0,
              mid_iterator_c5495892aae7d33e,
              mid_score_a9dac2c40463ba96,
              mid_twoPhaseIterator_61d06e8a00c37c18,
              mid_scoreCurrentDoc_a9dac2c40463ba96,
              mid_setFreqCurrentDoc_a5783a25d44ba15b,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit SpanScorer(jobject obj) : ::org::apache::lucene::search::Scorer(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            SpanScorer(const SpanScorer& obj) : ::org::apache::lucene::search::Scorer(obj) {}

            SpanScorer(const ::org::apache::lucene::queries::spans::Spans &, const ::org::apache::lucene::search::LeafSimScorer &);

            jint docID() const;
            jfloat getMaxScore(jint) const;
            ::org::apache::lucene::queries::spans::Spans getSpans() const;
            ::org::apache::lucene::search::DocIdSetIterator iterator() const;
            jfloat score() const;
            ::org::apache::lucene::search::TwoPhaseIterator twoPhaseIterator() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          extern PyType_Def PY_TYPE_DEF(SpanScorer);
          extern PyTypeObject *PY_TYPE(SpanScorer);

          class t_SpanScorer {
          public:
            PyObject_HEAD
            SpanScorer object;
            static PyObject *wrap_Object(const SpanScorer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
