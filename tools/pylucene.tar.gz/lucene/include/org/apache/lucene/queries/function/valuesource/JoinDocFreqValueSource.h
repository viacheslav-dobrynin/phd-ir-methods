#ifndef org_apache_lucene_queries_function_valuesource_JoinDocFreqValueSource_H
#define org_apache_lucene_queries_function_valuesource_JoinDocFreqValueSource_H

#include "org/apache/lucene/queries/function/valuesource/FieldCacheSource.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace util {
    class Map;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          class FunctionValues;
        }
      }
      namespace index {
        class LeafReaderContext;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          namespace valuesource {

            class JoinDocFreqValueSource : public ::org::apache::lucene::queries::function::valuesource::FieldCacheSource {
             public:
              enum {
                mid_init$_56d5ffc79e73287a,
                mid_description_cb1e3f35ce7b2bd1,
                mid_equals_2a09f73f0549554f,
                mid_getValues_fc4ba0c58720ebff,
                mid_hashCode_f03edc6a210ac78c,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit JoinDocFreqValueSource(jobject obj) : ::org::apache::lucene::queries::function::valuesource::FieldCacheSource(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              JoinDocFreqValueSource(const JoinDocFreqValueSource& obj) : ::org::apache::lucene::queries::function::valuesource::FieldCacheSource(obj) {}

              static ::java::lang::String *NAME;

              JoinDocFreqValueSource(const ::java::lang::String &, const ::java::lang::String &);

              ::java::lang::String description() const;
              jboolean equals(const ::java::lang::Object &) const;
              ::org::apache::lucene::queries::function::FunctionValues getValues(const ::java::util::Map &, const ::org::apache::lucene::index::LeafReaderContext &) const;
              jint hashCode() const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          namespace valuesource {
            extern PyType_Def PY_TYPE_DEF(JoinDocFreqValueSource);
            extern PyTypeObject *PY_TYPE(JoinDocFreqValueSource);

            class t_JoinDocFreqValueSource {
            public:
              PyObject_HEAD
              JoinDocFreqValueSource object;
              static PyObject *wrap_Object(const JoinDocFreqValueSource&);
              static PyObject *wrap_jobject(const jobject&);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
