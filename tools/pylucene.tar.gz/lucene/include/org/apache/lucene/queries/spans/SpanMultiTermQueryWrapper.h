#ifndef org_apache_lucene_queries_spans_SpanMultiTermQueryWrapper_H
#define org_apache_lucene_queries_spans_SpanMultiTermQueryWrapper_H

#include "org/apache/lucene/queries/spans/SpanQuery.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          class SpanWeight;
          class SpanMultiTermQueryWrapper$SpanRewriteMethod;
        }
      }
      namespace search {
        class MultiTermQuery;
        class Query;
        class QueryVisitor;
        class IndexSearcher;
        class ScoreMode;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {

          class SpanMultiTermQueryWrapper : public ::org::apache::lucene::queries::spans::SpanQuery {
           public:
            enum {
              mid_init$_082577936cdbfc14,
              mid_createWeight_9e1f53ad8e8bb167,
              mid_equals_2a09f73f0549554f,
              mid_getField_cb1e3f35ce7b2bd1,
              mid_getRewriteMethod_93bd049c2c0d0013,
              mid_getWrappedQuery_1bbb14eb001e7ebc,
              mid_hashCode_f03edc6a210ac78c,
              mid_rewrite_934f770a09887431,
              mid_setRewriteMethod_d9080b6f034656c6,
              mid_toString_4fd613927a288526,
              mid_visit_84cb151476e58e4d,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit SpanMultiTermQueryWrapper(jobject obj) : ::org::apache::lucene::queries::spans::SpanQuery(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            SpanMultiTermQueryWrapper(const SpanMultiTermQueryWrapper& obj) : ::org::apache::lucene::queries::spans::SpanQuery(obj) {}

            static ::org::apache::lucene::queries::spans::SpanMultiTermQueryWrapper$SpanRewriteMethod *SCORING_SPAN_QUERY_REWRITE;

            SpanMultiTermQueryWrapper(const ::org::apache::lucene::search::MultiTermQuery &);

            ::org::apache::lucene::queries::spans::SpanWeight createWeight(const ::org::apache::lucene::search::IndexSearcher &, const ::org::apache::lucene::search::ScoreMode &, jfloat) const;
            jboolean equals(const ::java::lang::Object &) const;
            ::java::lang::String getField() const;
            ::org::apache::lucene::queries::spans::SpanMultiTermQueryWrapper$SpanRewriteMethod getRewriteMethod() const;
            ::org::apache::lucene::search::Query getWrappedQuery() const;
            jint hashCode() const;
            ::org::apache::lucene::search::Query rewrite(const ::org::apache::lucene::search::IndexSearcher &) const;
            void setRewriteMethod(const ::org::apache::lucene::queries::spans::SpanMultiTermQueryWrapper$SpanRewriteMethod &) const;
            ::java::lang::String toString(const ::java::lang::String &) const;
            void visit(const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          extern PyType_Def PY_TYPE_DEF(SpanMultiTermQueryWrapper);
          extern PyTypeObject *PY_TYPE(SpanMultiTermQueryWrapper);

          class t_SpanMultiTermQueryWrapper {
          public:
            PyObject_HEAD
            SpanMultiTermQueryWrapper object;
            PyTypeObject *parameters[1];
            static PyTypeObject **parameters_(t_SpanMultiTermQueryWrapper *self)
            {
              return (PyTypeObject **) &(self->parameters);
            }
            static PyObject *wrap_Object(const SpanMultiTermQueryWrapper&);
            static PyObject *wrap_jobject(const jobject&);
            static PyObject *wrap_Object(const SpanMultiTermQueryWrapper&, PyTypeObject *);
            static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
