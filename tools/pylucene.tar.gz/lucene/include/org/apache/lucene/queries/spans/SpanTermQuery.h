#ifndef org_apache_lucene_queries_spans_SpanTermQuery_H
#define org_apache_lucene_queries_spans_SpanTermQuery_H

#include "org/apache/lucene/queries/spans/SpanQuery.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          class SpanWeight;
        }
      }
      namespace index {
        class Term;
        class TermStates;
      }
      namespace search {
        class QueryVisitor;
        class IndexSearcher;
        class ScoreMode;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {

          class SpanTermQuery : public ::org::apache::lucene::queries::spans::SpanQuery {
           public:
            enum {
              mid_init$_f0ea16905547f5c1,
              mid_init$_57a08c1a35fce590,
              mid_createWeight_9e1f53ad8e8bb167,
              mid_equals_2a09f73f0549554f,
              mid_getField_cb1e3f35ce7b2bd1,
              mid_getTerm_408603af941708f9,
              mid_getTermStates_ab82a4bd9dd1daf5,
              mid_hashCode_f03edc6a210ac78c,
              mid_toString_4fd613927a288526,
              mid_visit_84cb151476e58e4d,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit SpanTermQuery(jobject obj) : ::org::apache::lucene::queries::spans::SpanQuery(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            SpanTermQuery(const SpanTermQuery& obj) : ::org::apache::lucene::queries::spans::SpanQuery(obj) {}

            SpanTermQuery(const ::org::apache::lucene::index::Term &);
            SpanTermQuery(const ::org::apache::lucene::index::Term &, const ::org::apache::lucene::index::TermStates &);

            ::org::apache::lucene::queries::spans::SpanWeight createWeight(const ::org::apache::lucene::search::IndexSearcher &, const ::org::apache::lucene::search::ScoreMode &, jfloat) const;
            jboolean equals(const ::java::lang::Object &) const;
            ::java::lang::String getField() const;
            ::org::apache::lucene::index::Term getTerm() const;
            ::org::apache::lucene::index::TermStates getTermStates() const;
            jint hashCode() const;
            ::java::lang::String toString(const ::java::lang::String &) const;
            void visit(const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          extern PyType_Def PY_TYPE_DEF(SpanTermQuery);
          extern PyTypeObject *PY_TYPE(SpanTermQuery);

          class t_SpanTermQuery {
          public:
            PyObject_HEAD
            SpanTermQuery object;
            static PyObject *wrap_Object(const SpanTermQuery&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
