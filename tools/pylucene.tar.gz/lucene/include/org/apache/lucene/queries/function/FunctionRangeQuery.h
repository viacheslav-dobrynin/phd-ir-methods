#ifndef org_apache_lucene_queries_function_FunctionRangeQuery_H
#define org_apache_lucene_queries_function_FunctionRangeQuery_H

#include "org/apache/lucene/search/Query.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Number;
    class Object;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          class ValueSource;
        }
      }
      namespace search {
        class QueryVisitor;
        class IndexSearcher;
        class ScoreMode;
        class Weight;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {

          class FunctionRangeQuery : public ::org::apache::lucene::search::Query {
           public:
            enum {
              mid_init$_19affb171c781bff,
              mid_init$_3f7661d629839976,
              mid_createWeight_1ffda6c7942c608a,
              mid_equals_2a09f73f0549554f,
              mid_getLowerVal_cb1e3f35ce7b2bd1,
              mid_getUpperVal_cb1e3f35ce7b2bd1,
              mid_getValueSource_a6195616ba4b009a,
              mid_hashCode_f03edc6a210ac78c,
              mid_isIncludeLower_201fceb6e9f1d0c5,
              mid_isIncludeUpper_201fceb6e9f1d0c5,
              mid_toString_4fd613927a288526,
              mid_visit_84cb151476e58e4d,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit FunctionRangeQuery(jobject obj) : ::org::apache::lucene::search::Query(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            FunctionRangeQuery(const FunctionRangeQuery& obj) : ::org::apache::lucene::search::Query(obj) {}

            FunctionRangeQuery(const ::org::apache::lucene::queries::function::ValueSource &, const ::java::lang::Number &, const ::java::lang::Number &, jboolean, jboolean);
            FunctionRangeQuery(const ::org::apache::lucene::queries::function::ValueSource &, const ::java::lang::String &, const ::java::lang::String &, jboolean, jboolean);

            ::org::apache::lucene::search::Weight createWeight(const ::org::apache::lucene::search::IndexSearcher &, const ::org::apache::lucene::search::ScoreMode &, jfloat) const;
            jboolean equals(const ::java::lang::Object &) const;
            ::java::lang::String getLowerVal() const;
            ::java::lang::String getUpperVal() const;
            ::org::apache::lucene::queries::function::ValueSource getValueSource() const;
            jint hashCode() const;
            jboolean isIncludeLower() const;
            jboolean isIncludeUpper() const;
            ::java::lang::String toString(const ::java::lang::String &) const;
            void visit(const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace function {
          extern PyType_Def PY_TYPE_DEF(FunctionRangeQuery);
          extern PyTypeObject *PY_TYPE(FunctionRangeQuery);

          class t_FunctionRangeQuery {
          public:
            PyObject_HEAD
            FunctionRangeQuery object;
            static PyObject *wrap_Object(const FunctionRangeQuery&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
