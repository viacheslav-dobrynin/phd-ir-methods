#ifndef org_apache_lucene_queries_spans_TermSpans_H
#define org_apache_lucene_queries_spans_TermSpans_H

#include "org/apache/lucene/queries/spans/Spans.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace index {
        class Term;
        class PostingsEnum;
      }
      namespace queries {
        namespace spans {
          class SpanCollector;
        }
      }
      namespace search {
        class LeafSimScorer;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {

          class TermSpans : public ::org::apache::lucene::queries::spans::Spans {
           public:
            enum {
              mid_init$_3f3f7cea6b12f3a0,
              mid_advance_ff66fe240ad72894,
              mid_collect_4593ac8ffac2528f,
              mid_cost_d192af3db8896a5e,
              mid_docID_f03edc6a210ac78c,
              mid_endPosition_f03edc6a210ac78c,
              mid_getPostings_1b6810faac690c7c,
              mid_nextDoc_f03edc6a210ac78c,
              mid_nextStartPosition_f03edc6a210ac78c,
              mid_positionsCost_a9dac2c40463ba96,
              mid_startPosition_f03edc6a210ac78c,
              mid_toString_cb1e3f35ce7b2bd1,
              mid_width_f03edc6a210ac78c,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit TermSpans(jobject obj) : ::org::apache::lucene::queries::spans::Spans(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            TermSpans(const TermSpans& obj) : ::org::apache::lucene::queries::spans::Spans(obj) {}

            TermSpans(const ::org::apache::lucene::search::LeafSimScorer &, const ::org::apache::lucene::index::PostingsEnum &, const ::org::apache::lucene::index::Term &, jfloat);

            jint advance(jint) const;
            void collect(const ::org::apache::lucene::queries::spans::SpanCollector &) const;
            jlong cost() const;
            jint docID() const;
            jint endPosition() const;
            ::org::apache::lucene::index::PostingsEnum getPostings() const;
            jint nextDoc() const;
            jint nextStartPosition() const;
            jfloat positionsCost() const;
            jint startPosition() const;
            ::java::lang::String toString() const;
            jint width() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          extern PyType_Def PY_TYPE_DEF(TermSpans);
          extern PyTypeObject *PY_TYPE(TermSpans);

          class t_TermSpans {
          public:
            PyObject_HEAD
            TermSpans object;
            static PyObject *wrap_Object(const TermSpans&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
