#ifndef org_apache_lucene_queries_mlt_MoreLikeThisQuery_H
#define org_apache_lucene_queries_mlt_MoreLikeThisQuery_H

#include "org/apache/lucene/search/Query.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace util {
    class Set;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace search {
        class QueryVisitor;
        class IndexSearcher;
      }
      namespace analysis {
        class Analyzer;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace mlt {

          class MoreLikeThisQuery : public ::org::apache::lucene::search::Query {
           public:
            enum {
              mid_init$_0c42772852d69ce2,
              mid_equals_2a09f73f0549554f,
              mid_getAnalyzer_d7b85d5764ff6020,
              mid_getLikeText_cb1e3f35ce7b2bd1,
              mid_getMaxQueryTerms_f03edc6a210ac78c,
              mid_getMinDocFreq_f03edc6a210ac78c,
              mid_getMinTermFrequency_f03edc6a210ac78c,
              mid_getMoreLikeFields_c0724ba8b8f42824,
              mid_getPercentTermsToMatch_a9dac2c40463ba96,
              mid_getStopWords_9cfd5750b6ef4685,
              mid_hashCode_f03edc6a210ac78c,
              mid_rewrite_934f770a09887431,
              mid_setAnalyzer_b2343671f18a93d8,
              mid_setLikeText_9b22ecdee06ea23c,
              mid_setMaxQueryTerms_8730ba9dfaf23a7b,
              mid_setMinDocFreq_8730ba9dfaf23a7b,
              mid_setMinTermFrequency_8730ba9dfaf23a7b,
              mid_setMoreLikeFields_d7b3e75f1a119a36,
              mid_setPercentTermsToMatch_d35827da2088dce4,
              mid_setStopWords_7e00acd17cceab22,
              mid_toString_4fd613927a288526,
              mid_visit_84cb151476e58e4d,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit MoreLikeThisQuery(jobject obj) : ::org::apache::lucene::search::Query(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            MoreLikeThisQuery(const MoreLikeThisQuery& obj) : ::org::apache::lucene::search::Query(obj) {}

            MoreLikeThisQuery(const ::java::lang::String &, const JArray< ::java::lang::String > &, const ::org::apache::lucene::analysis::Analyzer &, const ::java::lang::String &);

            jboolean equals(const ::java::lang::Object &) const;
            ::org::apache::lucene::analysis::Analyzer getAnalyzer() const;
            ::java::lang::String getLikeText() const;
            jint getMaxQueryTerms() const;
            jint getMinDocFreq() const;
            jint getMinTermFrequency() const;
            JArray< ::java::lang::String > getMoreLikeFields() const;
            jfloat getPercentTermsToMatch() const;
            ::java::util::Set getStopWords() const;
            jint hashCode() const;
            ::org::apache::lucene::search::Query rewrite(const ::org::apache::lucene::search::IndexSearcher &) const;
            void setAnalyzer(const ::org::apache::lucene::analysis::Analyzer &) const;
            void setLikeText(const ::java::lang::String &) const;
            void setMaxQueryTerms(jint) const;
            void setMinDocFreq(jint) const;
            void setMinTermFrequency(jint) const;
            void setMoreLikeFields(const JArray< ::java::lang::String > &) const;
            void setPercentTermsToMatch(jfloat) const;
            void setStopWords(const ::java::util::Set &) const;
            ::java::lang::String toString(const ::java::lang::String &) const;
            void visit(const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace mlt {
          extern PyType_Def PY_TYPE_DEF(MoreLikeThisQuery);
          extern PyTypeObject *PY_TYPE(MoreLikeThisQuery);

          class t_MoreLikeThisQuery {
          public:
            PyObject_HEAD
            MoreLikeThisQuery object;
            static PyObject *wrap_Object(const MoreLikeThisQuery&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
