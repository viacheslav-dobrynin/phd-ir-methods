#ifndef org_apache_lucene_queries_spans_ConjunctionSpans_H
#define org_apache_lucene_queries_spans_ConjunctionSpans_H

#include "org/apache/lucene/queries/spans/Spans.h"

namespace java {
  namespace io {
    class IOException;
  }
  namespace lang {
    class Class;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace search {
        class TwoPhaseIterator;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {

          class ConjunctionSpans : public ::org::apache::lucene::queries::spans::Spans {
           public:
            enum {
              mid_advance_ff66fe240ad72894,
              mid_asTwoPhaseIterator_61d06e8a00c37c18,
              mid_cost_d192af3db8896a5e,
              mid_docID_f03edc6a210ac78c,
              mid_getSubSpans_8cfd406d839e7c20,
              mid_nextDoc_f03edc6a210ac78c,
              mid_positionsCost_a9dac2c40463ba96,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit ConjunctionSpans(jobject obj) : ::org::apache::lucene::queries::spans::Spans(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            ConjunctionSpans(const ConjunctionSpans& obj) : ::org::apache::lucene::queries::spans::Spans(obj) {}

            jint advance(jint) const;
            ::org::apache::lucene::search::TwoPhaseIterator asTwoPhaseIterator() const;
            jlong cost() const;
            jint docID() const;
            JArray< ::org::apache::lucene::queries::spans::Spans > getSubSpans() const;
            jint nextDoc() const;
            jfloat positionsCost() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace queries {
        namespace spans {
          extern PyType_Def PY_TYPE_DEF(ConjunctionSpans);
          extern PyTypeObject *PY_TYPE(ConjunctionSpans);

          class t_ConjunctionSpans {
          public:
            PyObject_HEAD
            ConjunctionSpans object;
            static PyObject *wrap_Object(const ConjunctionSpans&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
