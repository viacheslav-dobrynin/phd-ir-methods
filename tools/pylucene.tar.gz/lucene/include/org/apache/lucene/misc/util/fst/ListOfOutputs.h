#ifndef org_apache_lucene_misc_util_fst_ListOfOutputs_H
#define org_apache_lucene_misc_util_fst_ListOfOutputs_H

#include "org/apache/lucene/util/fst/Outputs.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace store {
        class DataInput;
        class DataOutput;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
  namespace util {
    class List;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace util {
          namespace fst {

            class ListOfOutputs : public ::org::apache::lucene::util::fst::Outputs {
             public:
              enum {
                mid_init$_f6d3b3b69e9a0a3f,
                mid_add_c36cd8daf720e2b9,
                mid_asList_f4673ac0597255b6,
                mid_common_c36cd8daf720e2b9,
                mid_getNoOutput_1543ec1f1674e5aa,
                mid_merge_c36cd8daf720e2b9,
                mid_outputToString_ab94fa0faf1a0844,
                mid_ramBytesUsed_c221ddeb69ccaa0b,
                mid_read_fd7eaf63e45e9d70,
                mid_readFinalOutput_fd7eaf63e45e9d70,
                mid_skipFinalOutput_a20ee94bce710ea0,
                mid_skipOutput_a20ee94bce710ea0,
                mid_subtract_c36cd8daf720e2b9,
                mid_toString_cb1e3f35ce7b2bd1,
                mid_write_79bcd9f271c77a1f,
                mid_writeFinalOutput_79bcd9f271c77a1f,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit ListOfOutputs(jobject obj) : ::org::apache::lucene::util::fst::Outputs(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              ListOfOutputs(const ListOfOutputs& obj) : ::org::apache::lucene::util::fst::Outputs(obj) {}

              ListOfOutputs(const ::org::apache::lucene::util::fst::Outputs &);

              ::java::lang::Object add(const ::java::lang::Object &, const ::java::lang::Object &) const;
              ::java::util::List asList(const ::java::lang::Object &) const;
              ::java::lang::Object common(const ::java::lang::Object &, const ::java::lang::Object &) const;
              ::java::lang::Object getNoOutput() const;
              ::java::lang::Object merge(const ::java::lang::Object &, const ::java::lang::Object &) const;
              ::java::lang::String outputToString(const ::java::lang::Object &) const;
              jlong ramBytesUsed(const ::java::lang::Object &) const;
              ::java::lang::Object read(const ::org::apache::lucene::store::DataInput &) const;
              ::java::lang::Object readFinalOutput(const ::org::apache::lucene::store::DataInput &) const;
              void skipFinalOutput(const ::org::apache::lucene::store::DataInput &) const;
              void skipOutput(const ::org::apache::lucene::store::DataInput &) const;
              ::java::lang::Object subtract(const ::java::lang::Object &, const ::java::lang::Object &) const;
              ::java::lang::String toString() const;
              void write(const ::java::lang::Object &, const ::org::apache::lucene::store::DataOutput &) const;
              void writeFinalOutput(const ::java::lang::Object &, const ::org::apache::lucene::store::DataOutput &) const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace util {
          namespace fst {
            extern PyType_Def PY_TYPE_DEF(ListOfOutputs);
            extern PyTypeObject *PY_TYPE(ListOfOutputs);

            class t_ListOfOutputs {
            public:
              PyObject_HEAD
              ListOfOutputs object;
              PyTypeObject *parameters[1];
              static PyTypeObject **parameters_(t_ListOfOutputs *self)
              {
                return (PyTypeObject **) &(self->parameters);
              }
              static PyObject *wrap_Object(const ListOfOutputs&);
              static PyObject *wrap_jobject(const jobject&);
              static PyObject *wrap_Object(const ListOfOutputs&, PyTypeObject *);
              static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
