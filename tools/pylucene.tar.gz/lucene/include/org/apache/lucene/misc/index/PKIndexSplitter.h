#ifndef org_apache_lucene_misc_index_PKIndexSplitter_H
#define org_apache_lucene_misc_index_PKIndexSplitter_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace search {
        class Query;
      }
      namespace index {
        class Term;
        class IndexWriterConfig;
      }
      namespace store {
        class Directory;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace index {

          class PKIndexSplitter : public ::java::lang::Object {
           public:
            enum {
              mid_init$_b31e6d8fc325b194,
              mid_init$_0eac2aaabe703de9,
              mid_init$_1484a15e3c435225,
              mid_init$_0b43b32c330a7879,
              mid_split_a5783a25d44ba15b,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit PKIndexSplitter(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            PKIndexSplitter(const PKIndexSplitter& obj) : ::java::lang::Object(obj) {}

            PKIndexSplitter(const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::index::Term &);
            PKIndexSplitter(const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::search::Query &);
            PKIndexSplitter(const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::index::Term &, const ::org::apache::lucene::index::IndexWriterConfig &, const ::org::apache::lucene::index::IndexWriterConfig &);
            PKIndexSplitter(const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::store::Directory &, const ::org::apache::lucene::search::Query &, const ::org::apache::lucene::index::IndexWriterConfig &, const ::org::apache::lucene::index::IndexWriterConfig &);

            void split() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace index {
          extern PyType_Def PY_TYPE_DEF(PKIndexSplitter);
          extern PyTypeObject *PY_TYPE(PKIndexSplitter);

          class t_PKIndexSplitter {
          public:
            PyObject_HEAD
            PKIndexSplitter object;
            static PyObject *wrap_Object(const PKIndexSplitter&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
