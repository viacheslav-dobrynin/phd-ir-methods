#ifndef org_apache_lucene_misc_search_HumanReadableQuery_H
#define org_apache_lucene_misc_search_HumanReadableQuery_H

#include "org/apache/lucene/search/Query.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace search {
        class QueryVisitor;
        class IndexSearcher;
        class ScoreMode;
        class Weight;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace search {

          class HumanReadableQuery : public ::org::apache::lucene::search::Query {
           public:
            enum {
              mid_init$_df284e36ac7dccba,
              mid_createWeight_1ffda6c7942c608a,
              mid_equals_2a09f73f0549554f,
              mid_getDescription_cb1e3f35ce7b2bd1,
              mid_getWrappedQuery_1bbb14eb001e7ebc,
              mid_hashCode_f03edc6a210ac78c,
              mid_rewrite_934f770a09887431,
              mid_toString_4fd613927a288526,
              mid_visit_84cb151476e58e4d,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit HumanReadableQuery(jobject obj) : ::org::apache::lucene::search::Query(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            HumanReadableQuery(const HumanReadableQuery& obj) : ::org::apache::lucene::search::Query(obj) {}

            HumanReadableQuery(const ::org::apache::lucene::search::Query &, const ::java::lang::String &);

            ::org::apache::lucene::search::Weight createWeight(const ::org::apache::lucene::search::IndexSearcher &, const ::org::apache::lucene::search::ScoreMode &, jfloat) const;
            jboolean equals(const ::java::lang::Object &) const;
            ::java::lang::String getDescription() const;
            ::org::apache::lucene::search::Query getWrappedQuery() const;
            jint hashCode() const;
            ::org::apache::lucene::search::Query rewrite(const ::org::apache::lucene::search::IndexSearcher &) const;
            ::java::lang::String toString(const ::java::lang::String &) const;
            void visit(const ::org::apache::lucene::search::QueryVisitor &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace search {
          extern PyType_Def PY_TYPE_DEF(HumanReadableQuery);
          extern PyTypeObject *PY_TYPE(HumanReadableQuery);

          class t_HumanReadableQuery {
          public:
            PyObject_HEAD
            HumanReadableQuery object;
            static PyObject *wrap_Object(const HumanReadableQuery&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
