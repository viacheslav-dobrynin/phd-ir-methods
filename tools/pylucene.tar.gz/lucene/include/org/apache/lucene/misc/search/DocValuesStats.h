#ifndef org_apache_lucene_misc_search_DocValuesStats_H
#define org_apache_lucene_misc_search_DocValuesStats_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace search {

          class DocValuesStats : public ::java::lang::Object {
           public:
            enum {
              mid_count_f03edc6a210ac78c,
              mid_field_cb1e3f35ce7b2bd1,
              mid_max_1543ec1f1674e5aa,
              mid_min_1543ec1f1674e5aa,
              mid_missing_f03edc6a210ac78c,
              mid_init_132ce1d68d3c247d,
              mid_hasValue_12fe561dd4de11f3,
              mid_doAccumulate_8730ba9dfaf23a7b,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit DocValuesStats(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            DocValuesStats(const DocValuesStats& obj) : ::java::lang::Object(obj) {}

            jint count() const;
            ::java::lang::String field() const;
            ::java::lang::Object max$() const;
            ::java::lang::Object min$() const;
            jint missing() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace search {
          extern PyType_Def PY_TYPE_DEF(DocValuesStats);
          extern PyTypeObject *PY_TYPE(DocValuesStats);

          class t_DocValuesStats {
          public:
            PyObject_HEAD
            DocValuesStats object;
            PyTypeObject *parameters[1];
            static PyTypeObject **parameters_(t_DocValuesStats *self)
            {
              return (PyTypeObject **) &(self->parameters);
            }
            static PyObject *wrap_Object(const DocValuesStats&);
            static PyObject *wrap_jobject(const jobject&);
            static PyObject *wrap_Object(const DocValuesStats&, PyTypeObject *);
            static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
