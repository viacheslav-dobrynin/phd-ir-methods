#ifndef org_apache_lucene_misc_util_fst_UpToTwoPositiveIntOutputs_H
#define org_apache_lucene_misc_util_fst_UpToTwoPositiveIntOutputs_H

#include "org/apache/lucene/util/fst/Outputs.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace store {
        class DataInput;
        class DataOutput;
      }
      namespace misc {
        namespace util {
          namespace fst {
            class UpToTwoPositiveIntOutputs;
            class UpToTwoPositiveIntOutputs$TwoLongs;
          }
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
    class Long;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace util {
          namespace fst {

            class UpToTwoPositiveIntOutputs : public ::org::apache::lucene::util::fst::Outputs {
             public:
              enum {
                mid_add_c36cd8daf720e2b9,
                mid_common_fda500f6fd5cc21f,
                mid_get_b1c387bd114a700a,
                mid_get_ea00231fe0f0c648,
                mid_getNoOutput_1543ec1f1674e5aa,
                mid_getSingleton_0f1a5f09e85e5e8a,
                mid_merge_c36cd8daf720e2b9,
                mid_outputToString_ab94fa0faf1a0844,
                mid_ramBytesUsed_c221ddeb69ccaa0b,
                mid_read_fd7eaf63e45e9d70,
                mid_subtract_fda500f6fd5cc21f,
                mid_write_79bcd9f271c77a1f,
                max_mid
              };

              static ::java::lang::Class *class$;
              static jmethodID *mids$;
              static bool live$;
              static jclass initializeClass(bool);

              explicit UpToTwoPositiveIntOutputs(jobject obj) : ::org::apache::lucene::util::fst::Outputs(obj) {
                if (obj != NULL && mids$ == NULL)
                  env->getClass(initializeClass);
              }
              UpToTwoPositiveIntOutputs(const UpToTwoPositiveIntOutputs& obj) : ::org::apache::lucene::util::fst::Outputs(obj) {}

              ::java::lang::Object add(const ::java::lang::Object &, const ::java::lang::Object &) const;
              ::java::lang::Long common(const ::java::lang::Object &, const ::java::lang::Object &) const;
              ::java::lang::Long get(jlong) const;
              ::org::apache::lucene::misc::util::fst::UpToTwoPositiveIntOutputs$TwoLongs get(jlong, jlong) const;
              ::java::lang::Object getNoOutput() const;
              static UpToTwoPositiveIntOutputs getSingleton(jboolean);
              ::java::lang::Object merge(const ::java::lang::Object &, const ::java::lang::Object &) const;
              ::java::lang::String outputToString(const ::java::lang::Object &) const;
              jlong ramBytesUsed(const ::java::lang::Object &) const;
              ::java::lang::Object read(const ::org::apache::lucene::store::DataInput &) const;
              ::java::lang::Long subtract(const ::java::lang::Object &, const ::java::lang::Object &) const;
              void write(const ::java::lang::Object &, const ::org::apache::lucene::store::DataOutput &) const;
            };
          }
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace util {
          namespace fst {
            extern PyType_Def PY_TYPE_DEF(UpToTwoPositiveIntOutputs);
            extern PyTypeObject *PY_TYPE(UpToTwoPositiveIntOutputs);

            class t_UpToTwoPositiveIntOutputs {
            public:
              PyObject_HEAD
              UpToTwoPositiveIntOutputs object;
              PyTypeObject *parameters[1];
              static PyTypeObject **parameters_(t_UpToTwoPositiveIntOutputs *self)
              {
                return (PyTypeObject **) &(self->parameters);
              }
              static PyObject *wrap_Object(const UpToTwoPositiveIntOutputs&);
              static PyObject *wrap_jobject(const jobject&);
              static PyObject *wrap_Object(const UpToTwoPositiveIntOutputs&, PyTypeObject *);
              static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
              static void install(PyObject *module);
              static void initialize(PyObject *module);
            };
          }
        }
      }
    }
  }
}

#endif
