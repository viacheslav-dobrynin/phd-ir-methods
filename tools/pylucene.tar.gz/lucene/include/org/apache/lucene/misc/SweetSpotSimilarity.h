#ifndef org_apache_lucene_misc_SweetSpotSimilarity_H
#define org_apache_lucene_misc_SweetSpotSimilarity_H

#include "org/apache/lucene/search/similarities/ClassicSimilarity.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {

        class SweetSpotSimilarity : public ::org::apache::lucene::search::similarities::ClassicSimilarity {
         public:
          enum {
            mid_init$_a5783a25d44ba15b,
            mid_init$_a5b6a940fc16c6a1,
            mid_baselineTf_fa068b8266cb0550,
            mid_hyperbolicTf_fa068b8266cb0550,
            mid_lengthNorm_774c70860a3c670a,
            mid_setBaselineTfFactors_ba8bbab72fe9971d,
            mid_setHyperbolicTfFactors_bbdc08e002fc8154,
            mid_setLengthNormFactors_a4ce7c34dae1d695,
            mid_tf_fa068b8266cb0550,
            mid_toString_cb1e3f35ce7b2bd1,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit SweetSpotSimilarity(jobject obj) : ::org::apache::lucene::search::similarities::ClassicSimilarity(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          SweetSpotSimilarity(const SweetSpotSimilarity& obj) : ::org::apache::lucene::search::similarities::ClassicSimilarity(obj) {}

          SweetSpotSimilarity();
          SweetSpotSimilarity(jboolean);

          jfloat baselineTf(jfloat) const;
          jfloat hyperbolicTf(jfloat) const;
          jfloat lengthNorm(jint) const;
          void setBaselineTfFactors(jfloat, jfloat) const;
          void setHyperbolicTfFactors(jfloat, jfloat, jdouble, jfloat) const;
          void setLengthNormFactors(jint, jint, jfloat) const;
          jfloat tf(jfloat) const;
          ::java::lang::String toString() const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        extern PyType_Def PY_TYPE_DEF(SweetSpotSimilarity);
        extern PyTypeObject *PY_TYPE(SweetSpotSimilarity);

        class t_SweetSpotSimilarity {
        public:
          PyObject_HEAD
          SweetSpotSimilarity object;
          static PyObject *wrap_Object(const SweetSpotSimilarity&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
