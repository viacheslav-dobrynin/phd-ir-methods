#ifndef org_apache_lucene_misc_document_LazyDocument$LazyField_H
#define org_apache_lucene_misc_document_LazyDocument$LazyField_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace index {
        class IndexableFieldType;
        class IndexableField;
      }
      namespace analysis {
        class TokenStream;
        class Analyzer;
      }
      namespace document {
        class InvertableType;
        class StoredValue;
      }
      namespace util {
        class BytesRef;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Number;
  }
  namespace io {
    class Reader;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace document {

          class LazyDocument$LazyField : public ::java::lang::Object {
           public:
            enum {
              mid_binaryValue_21d166e7001d7305,
              mid_fieldType_91ea157a8aee69fd,
              mid_hasBeenLoaded_201fceb6e9f1d0c5,
              mid_invertableType_73d98d227f854a08,
              mid_name_cb1e3f35ce7b2bd1,
              mid_numericValue_c18f941c9a79eeb0,
              mid_readerValue_ba05cdf82db4bf25,
              mid_storedValue_695e4e83ef324785,
              mid_stringValue_cb1e3f35ce7b2bd1,
              mid_tokenStream_3e293d94541f86e0,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit LazyDocument$LazyField(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            LazyDocument$LazyField(const LazyDocument$LazyField& obj) : ::java::lang::Object(obj) {}

            ::org::apache::lucene::util::BytesRef binaryValue() const;
            ::org::apache::lucene::index::IndexableFieldType fieldType() const;
            jboolean hasBeenLoaded() const;
            ::org::apache::lucene::document::InvertableType invertableType() const;
            ::java::lang::String name() const;
            ::java::lang::Number numericValue() const;
            ::java::io::Reader readerValue() const;
            ::org::apache::lucene::document::StoredValue storedValue() const;
            ::java::lang::String stringValue() const;
            ::org::apache::lucene::analysis::TokenStream tokenStream(const ::org::apache::lucene::analysis::Analyzer &, const ::org::apache::lucene::analysis::TokenStream &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace document {
          extern PyType_Def PY_TYPE_DEF(LazyDocument$LazyField);
          extern PyTypeObject *PY_TYPE(LazyDocument$LazyField);

          class t_LazyDocument$LazyField {
          public:
            PyObject_HEAD
            LazyDocument$LazyField object;
            static PyObject *wrap_Object(const LazyDocument$LazyField&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
