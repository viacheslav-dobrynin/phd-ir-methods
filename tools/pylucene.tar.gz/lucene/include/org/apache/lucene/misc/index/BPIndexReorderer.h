#ifndef org_apache_lucene_misc_index_BPIndexReorderer_H
#define org_apache_lucene_misc_index_BPIndexReorderer_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    namespace concurrent {
      class Executor;
    }
    class Set;
  }
  namespace lang {
    class Class;
    class String;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace index {
        class CodecReader;
        class Sorter$DocMap;
      }
      namespace store {
        class Directory;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace index {

          class BPIndexReorderer : public ::java::lang::Object {
           public:
            enum {
              mid_init$_a5783a25d44ba15b,
              mid_computeDocMap_8459200783c7e72a,
              mid_reorder_8cae7fea4e35c542,
              mid_setFields_7e00acd17cceab22,
              mid_setMaxDocFreq_d35827da2088dce4,
              mid_setMaxIters_8730ba9dfaf23a7b,
              mid_setMinDocFreq_8730ba9dfaf23a7b,
              mid_setMinPartitionSize_8730ba9dfaf23a7b,
              mid_setRAMBudgetMB_44052de370ab2f98,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit BPIndexReorderer(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            BPIndexReorderer(const BPIndexReorderer& obj) : ::java::lang::Object(obj) {}

            static jint DEFAULT_MAX_ITERS;
            static jint DEFAULT_MIN_DOC_FREQ;
            static jint DEFAULT_MIN_PARTITION_SIZE;

            BPIndexReorderer();

            ::org::apache::lucene::index::Sorter$DocMap computeDocMap(const ::org::apache::lucene::index::CodecReader &, const ::org::apache::lucene::store::Directory &, const ::java::util::concurrent::Executor &) const;
            ::org::apache::lucene::index::CodecReader reorder(const ::org::apache::lucene::index::CodecReader &, const ::org::apache::lucene::store::Directory &, const ::java::util::concurrent::Executor &) const;
            void setFields(const ::java::util::Set &) const;
            void setMaxDocFreq(jfloat) const;
            void setMaxIters(jint) const;
            void setMinDocFreq(jint) const;
            void setMinPartitionSize(jint) const;
            void setRAMBudgetMB(jdouble) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace index {
          extern PyType_Def PY_TYPE_DEF(BPIndexReorderer);
          extern PyTypeObject *PY_TYPE(BPIndexReorderer);

          class t_BPIndexReorderer {
          public:
            PyObject_HEAD
            BPIndexReorderer object;
            static PyObject *wrap_Object(const BPIndexReorderer&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
