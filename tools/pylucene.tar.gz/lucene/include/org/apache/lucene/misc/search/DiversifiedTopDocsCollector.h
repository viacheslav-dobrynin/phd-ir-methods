#ifndef org_apache_lucene_misc_search_DiversifiedTopDocsCollector_H
#define org_apache_lucene_misc_search_DiversifiedTopDocsCollector_H

#include "org/apache/lucene/search/TopDocsCollector.h"

namespace java {
  namespace lang {
    class Class;
  }
  namespace io {
    class IOException;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace search {
        class ScoreMode;
        class LeafCollector;
      }
      namespace misc {
        namespace search {
          class DiversifiedTopDocsCollector$ScoreDocKey;
        }
      }
      namespace index {
        class LeafReaderContext;
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace search {

          class DiversifiedTopDocsCollector : public ::org::apache::lucene::search::TopDocsCollector {
           public:
            enum {
              mid_init$_948d154349f29e30,
              mid_getLeafCollector_f2155691319a2de3,
              mid_scoreMode_abc0790bdac49047,
              mid_insert_9f43e4ffdf58878a,
              mid_getKeys_36e9a70635c19bba,
              mid_newTopDocs_c5961761b967720e,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit DiversifiedTopDocsCollector(jobject obj) : ::org::apache::lucene::search::TopDocsCollector(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            DiversifiedTopDocsCollector(const DiversifiedTopDocsCollector& obj) : ::org::apache::lucene::search::TopDocsCollector(obj) {}

            DiversifiedTopDocsCollector(jint, jint);

            ::org::apache::lucene::search::LeafCollector getLeafCollector(const ::org::apache::lucene::index::LeafReaderContext &) const;
            ::org::apache::lucene::search::ScoreMode scoreMode() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace search {
          extern PyType_Def PY_TYPE_DEF(DiversifiedTopDocsCollector);
          extern PyTypeObject *PY_TYPE(DiversifiedTopDocsCollector);

          class t_DiversifiedTopDocsCollector {
          public:
            PyObject_HEAD
            DiversifiedTopDocsCollector object;
            PyTypeObject *parameters[1];
            static PyTypeObject **parameters_(t_DiversifiedTopDocsCollector *self)
            {
              return (PyTypeObject **) &(self->parameters);
            }
            static PyObject *wrap_Object(const DiversifiedTopDocsCollector&);
            static PyObject *wrap_jobject(const jobject&);
            static PyObject *wrap_Object(const DiversifiedTopDocsCollector&, PyTypeObject *);
            static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
