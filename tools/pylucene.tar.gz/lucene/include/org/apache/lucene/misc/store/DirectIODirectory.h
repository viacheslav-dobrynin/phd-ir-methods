#ifndef org_apache_lucene_misc_store_DirectIODirectory_H
#define org_apache_lucene_misc_store_DirectIODirectory_H

#include "org/apache/lucene/store/FilterDirectory.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace store {
        class IOContext;
        class IndexInput;
        class FSDirectory;
        class IndexOutput;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
  }
  namespace io {
    class IOException;
  }
  namespace nio {
    namespace file {
      class Path;
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace store {

          class DirectIODirectory : public ::org::apache::lucene::store::FilterDirectory {
           public:
            enum {
              mid_init$_2d82914c4963ef19,
              mid_init$_f6f6c5bf672998e4,
              mid_close_a5783a25d44ba15b,
              mid_createOutput_494fe2bc88236511,
              mid_getDirectory_bd4213659d0d079d,
              mid_openInput_477b374b4e8f362d,
              mid_ensureOpen_a5783a25d44ba15b,
              mid_useDirectIO_eeac48a662c8b9e5,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit DirectIODirectory(jobject obj) : ::org::apache::lucene::store::FilterDirectory(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            DirectIODirectory(const DirectIODirectory& obj) : ::org::apache::lucene::store::FilterDirectory(obj) {}

            static jint DEFAULT_MERGE_BUFFER_SIZE;
            static jlong DEFAULT_MIN_BYTES_DIRECT;

            DirectIODirectory(const ::org::apache::lucene::store::FSDirectory &);
            DirectIODirectory(const ::org::apache::lucene::store::FSDirectory &, jint, jlong);

            void close() const;
            ::org::apache::lucene::store::IndexOutput createOutput(const ::java::lang::String &, const ::org::apache::lucene::store::IOContext &) const;
            ::java::nio::file::Path getDirectory() const;
            ::org::apache::lucene::store::IndexInput openInput(const ::java::lang::String &, const ::org::apache::lucene::store::IOContext &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace misc {
        namespace store {
          extern PyType_Def PY_TYPE_DEF(DirectIODirectory);
          extern PyTypeObject *PY_TYPE(DirectIODirectory);

          class t_DirectIODirectory {
          public:
            PyObject_HEAD
            DirectIODirectory object;
            static PyObject *wrap_Object(const DirectIODirectory&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
