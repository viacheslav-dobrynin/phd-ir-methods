#ifndef org_apache_lucene_spatial3d_geom_XYZBounds_H
#define org_apache_lucene_spatial3d_geom_XYZBounds_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class PlanetModel;
          class Membership;
          class Plane;
          class Vector;
          class Bounds;
          class GeoPoint;
          class XYZBounds;
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Double;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {

          class XYZBounds : public ::java::lang::Object {
           public:
            enum {
              mid_init$_a5783a25d44ba15b,
              mid_addBounds_4a6393cc8cdbe408,
              mid_addHorizontalPlane_487b925ee25eeea8,
              mid_addIntersection_b5da2d0d35010fad,
              mid_addPlane_526d9c675e499215,
              mid_addPoint_2e3ece88ca3ab35b,
              mid_addVerticalPlane_487b925ee25eeea8,
              mid_addXValue_2e3ece88ca3ab35b,
              mid_addXValue_d5636892225f75db,
              mid_addYValue_2e3ece88ca3ab35b,
              mid_addYValue_d5636892225f75db,
              mid_addZValue_2e3ece88ca3ab35b,
              mid_addZValue_d5636892225f75db,
              mid_getMaximumX_2d492ca44b87bbea,
              mid_getMaximumY_2d492ca44b87bbea,
              mid_getMaximumZ_2d492ca44b87bbea,
              mid_getMinimumX_2d492ca44b87bbea,
              mid_getMinimumY_2d492ca44b87bbea,
              mid_getMinimumZ_2d492ca44b87bbea,
              mid_isLargestMaxX_99b1422653083cfd,
              mid_isLargestMaxY_99b1422653083cfd,
              mid_isLargestMaxZ_99b1422653083cfd,
              mid_isSmallestMinX_99b1422653083cfd,
              mid_isSmallestMinY_99b1422653083cfd,
              mid_isSmallestMinZ_99b1422653083cfd,
              mid_isWide_57d50f6a83317ebe,
              mid_isWithin_ce821273f709beb7,
              mid_isWithin_dfc1d22fff391bdd,
              mid_noBottomLatitudeBound_57d50f6a83317ebe,
              mid_noBound_c089abf6c53349ab,
              mid_noLongitudeBound_57d50f6a83317ebe,
              mid_noTopLatitudeBound_57d50f6a83317ebe,
              mid_overlaps_7e0950076a1e3a68,
              mid_toString_cb1e3f35ce7b2bd1,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit XYZBounds(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            XYZBounds(const XYZBounds& obj) : ::java::lang::Object(obj) {}

            XYZBounds();

            void addBounds(const XYZBounds &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addHorizontalPlane(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, const ::org::apache::lucene::spatial3d::geom::Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addIntersection(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::Plane &, const ::org::apache::lucene::spatial3d::geom::Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addPlane(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addPoint(const ::org::apache::lucene::spatial3d::geom::GeoPoint &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addVerticalPlane(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, const ::org::apache::lucene::spatial3d::geom::Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addXValue(const ::org::apache::lucene::spatial3d::geom::GeoPoint &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addXValue(jdouble) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addYValue(const ::org::apache::lucene::spatial3d::geom::GeoPoint &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addYValue(jdouble) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addZValue(const ::org::apache::lucene::spatial3d::geom::GeoPoint &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds addZValue(jdouble) const;
            ::java::lang::Double getMaximumX() const;
            ::java::lang::Double getMaximumY() const;
            ::java::lang::Double getMaximumZ() const;
            ::java::lang::Double getMinimumX() const;
            ::java::lang::Double getMinimumY() const;
            ::java::lang::Double getMinimumZ() const;
            jboolean isLargestMaxX(const ::org::apache::lucene::spatial3d::geom::PlanetModel &) const;
            jboolean isLargestMaxY(const ::org::apache::lucene::spatial3d::geom::PlanetModel &) const;
            jboolean isLargestMaxZ(const ::org::apache::lucene::spatial3d::geom::PlanetModel &) const;
            jboolean isSmallestMinX(const ::org::apache::lucene::spatial3d::geom::PlanetModel &) const;
            jboolean isSmallestMinY(const ::org::apache::lucene::spatial3d::geom::PlanetModel &) const;
            jboolean isSmallestMinZ(const ::org::apache::lucene::spatial3d::geom::PlanetModel &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds isWide() const;
            jboolean isWithin(const ::org::apache::lucene::spatial3d::geom::Vector &) const;
            jboolean isWithin(jdouble, jdouble, jdouble) const;
            ::org::apache::lucene::spatial3d::geom::Bounds noBottomLatitudeBound() const;
            ::org::apache::lucene::spatial3d::geom::Bounds noBound(const ::org::apache::lucene::spatial3d::geom::PlanetModel &) const;
            ::org::apache::lucene::spatial3d::geom::Bounds noLongitudeBound() const;
            ::org::apache::lucene::spatial3d::geom::Bounds noTopLatitudeBound() const;
            jboolean overlaps(const XYZBounds &) const;
            ::java::lang::String toString() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          extern PyType_Def PY_TYPE_DEF(XYZBounds);
          extern PyTypeObject *PY_TYPE(XYZBounds);

          class t_XYZBounds {
          public:
            PyObject_HEAD
            XYZBounds object;
            static PyObject *wrap_Object(const XYZBounds&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
