#ifndef org_apache_lucene_spatial3d_geom_GeoPolygonFactory_H
#define org_apache_lucene_spatial3d_geom_GeoPolygonFactory_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class PlanetModel;
          class GeoPolygonFactory$PolygonDescription;
          class GeoPolygon;
          class GeoPoint;
        }
      }
    }
  }
}
namespace java {
  namespace util {
    class List;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {

          class GeoPolygonFactory : public ::java::lang::Object {
           public:
            enum {
              mid_makeGeoConcavePolygon_62eca3ae06a822c2,
              mid_makeGeoConcavePolygon_d2e010d1f49ca9d6,
              mid_makeGeoConvexPolygon_62eca3ae06a822c2,
              mid_makeGeoConvexPolygon_d2e010d1f49ca9d6,
              mid_makeGeoPolygon_a92626306c5091fe,
              mid_makeGeoPolygon_62eca3ae06a822c2,
              mid_makeGeoPolygon_72128811b92e55f1,
              mid_makeGeoPolygon_d2e010d1f49ca9d6,
              mid_makeGeoPolygon_9852535922c747a4,
              mid_makeLargeGeoPolygon_62eca3ae06a822c2,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit GeoPolygonFactory(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            GeoPolygonFactory(const GeoPolygonFactory& obj) : ::java::lang::Object(obj) {}

            static ::org::apache::lucene::spatial3d::geom::GeoPolygon makeGeoConcavePolygon(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::util::List &);
            static ::org::apache::lucene::spatial3d::geom::GeoPolygon makeGeoConcavePolygon(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::util::List &, const ::java::util::List &);
            static ::org::apache::lucene::spatial3d::geom::GeoPolygon makeGeoConvexPolygon(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::util::List &);
            static ::org::apache::lucene::spatial3d::geom::GeoPolygon makeGeoConvexPolygon(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::util::List &, const ::java::util::List &);
            static ::org::apache::lucene::spatial3d::geom::GeoPolygon makeGeoPolygon(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::GeoPolygonFactory$PolygonDescription &);
            static ::org::apache::lucene::spatial3d::geom::GeoPolygon makeGeoPolygon(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::util::List &);
            static ::org::apache::lucene::spatial3d::geom::GeoPolygon makeGeoPolygon(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::GeoPolygonFactory$PolygonDescription &, jdouble);
            static ::org::apache::lucene::spatial3d::geom::GeoPolygon makeGeoPolygon(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::util::List &, const ::java::util::List &);
            static ::org::apache::lucene::spatial3d::geom::GeoPolygon makeGeoPolygon(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::util::List &, const ::java::util::List &, jdouble);
            static ::org::apache::lucene::spatial3d::geom::GeoPolygon makeLargeGeoPolygon(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::util::List &);
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          extern PyType_Def PY_TYPE_DEF(GeoPolygonFactory);
          extern PyTypeObject *PY_TYPE(GeoPolygonFactory);

          class t_GeoPolygonFactory {
          public:
            PyObject_HEAD
            GeoPolygonFactory object;
            static PyObject *wrap_Object(const GeoPolygonFactory&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
