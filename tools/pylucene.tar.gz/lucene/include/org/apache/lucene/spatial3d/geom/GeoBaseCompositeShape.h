#ifndef org_apache_lucene_spatial3d_geom_GeoBaseCompositeShape_H
#define org_apache_lucene_spatial3d_geom_GeoBaseCompositeShape_H

#include "org/apache/lucene/spatial3d/geom/BasePlanetObject.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class PlanetModel;
          class Membership;
          class GeoShape;
          class Plane;
          class Bounds;
          class Vector;
          class GeoPoint;
        }
      }
    }
  }
}
namespace java {
  namespace io {
    class OutputStream;
    class IOException;
    class InputStream;
  }
  namespace lang {
    class Class;
    class Object;
  }
  namespace util {
    class List;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {

          class GeoBaseCompositeShape : public ::org::apache::lucene::spatial3d::geom::BasePlanetObject {
           public:
            enum {
              mid_init$_c666c3ed71db3fa1,
              mid_init$_4d3f31e7233d016e,
              mid_addShape_d0ad010831c074e9,
              mid_equals_2a09f73f0549554f,
              mid_getBounds_24ac88e75daf92c6,
              mid_getEdgePoints_d5f1659ac4042328,
              mid_getShape_5836e25e161a5c1a,
              mid_getShapes_7b3206bb4e2462d2,
              mid_hashCode_f03edc6a210ac78c,
              mid_intersects_cd9ba3e89bc0b1af,
              mid_isWithin_ce821273f709beb7,
              mid_isWithin_dfc1d22fff391bdd,
              mid_size_f03edc6a210ac78c,
              mid_write_8fb87594300dbff6,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit GeoBaseCompositeShape(jobject obj) : ::org::apache::lucene::spatial3d::geom::BasePlanetObject(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            GeoBaseCompositeShape(const GeoBaseCompositeShape& obj) : ::org::apache::lucene::spatial3d::geom::BasePlanetObject(obj) {}

            GeoBaseCompositeShape(const ::org::apache::lucene::spatial3d::geom::PlanetModel &);
            GeoBaseCompositeShape(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::io::InputStream &, const ::java::lang::Class &);

            void addShape(const ::org::apache::lucene::spatial3d::geom::GeoShape &) const;
            jboolean equals(const ::java::lang::Object &) const;
            void getBounds(const ::org::apache::lucene::spatial3d::geom::Bounds &) const;
            JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > getEdgePoints() const;
            ::org::apache::lucene::spatial3d::geom::GeoShape getShape(jint) const;
            ::java::util::List getShapes() const;
            jint hashCode() const;
            jboolean intersects(const ::org::apache::lucene::spatial3d::geom::Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jboolean isWithin(const ::org::apache::lucene::spatial3d::geom::Vector &) const;
            jboolean isWithin(jdouble, jdouble, jdouble) const;
            jint size() const;
            void write(const ::java::io::OutputStream &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          extern PyType_Def PY_TYPE_DEF(GeoBaseCompositeShape);
          extern PyTypeObject *PY_TYPE(GeoBaseCompositeShape);

          class t_GeoBaseCompositeShape {
          public:
            PyObject_HEAD
            GeoBaseCompositeShape object;
            PyTypeObject *parameters[1];
            static PyTypeObject **parameters_(t_GeoBaseCompositeShape *self)
            {
              return (PyTypeObject **) &(self->parameters);
            }
            static PyObject *wrap_Object(const GeoBaseCompositeShape&);
            static PyObject *wrap_jobject(const jobject&);
            static PyObject *wrap_Object(const GeoBaseCompositeShape&, PyTypeObject *);
            static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
