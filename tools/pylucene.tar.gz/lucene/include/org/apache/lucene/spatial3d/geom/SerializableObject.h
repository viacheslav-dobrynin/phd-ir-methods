#ifndef org_apache_lucene_spatial3d_geom_SerializableObject_H
#define org_apache_lucene_spatial3d_geom_SerializableObject_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class PlanetModel;
          class SerializableObject;
          class PlanetObject;
          class GeoPolygon;
          class GeoPoint;
        }
      }
    }
  }
}
namespace java {
  namespace io {
    class OutputStream;
    class IOException;
    class InputStream;
  }
  namespace lang {
    class Class;
    class String;
    class ClassNotFoundException;
  }
  namespace util {
    class List;
    class BitSet;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {

          class SerializableObject : public ::java::lang::Object {
           public:
            enum {
              mid_readBitSet_9eb16c14d6855f2f,
              mid_readBoolean_e2f86f0c6ba88234,
              mid_readByteArray_5d15c3503da694c8,
              mid_readClass_541b787b499d5191,
              mid_readDouble_b8fca09d31ecefbb,
              mid_readHeterogeneousArray_0a6c01c3adde2019,
              mid_readHomogeneousArray_0a6c01c3adde2019,
              mid_readInt_77d9609241f72955,
              mid_readLong_da61ca52329a5f1a,
              mid_readObject_8a7b5bcc44fa609e,
              mid_readObject_7c8e07191d3e5984,
              mid_readObject_0586fd09b45c0c6b,
              mid_readObject_5bac1a7a3f152101,
              mid_readPlanetObject_8796da8106673a22,
              mid_readPointArray_02997b55d1ac28be,
              mid_readPolygonArray_0c2e5fa7dc2ec371,
              mid_readString_13c1a35804dd28e9,
              mid_write_8fb87594300dbff6,
              mid_writeBitSet_b79093d3e02951a6,
              mid_writeBoolean_b8ed6908372bc1da,
              mid_writeByteArray_f6d757c6b18674ea,
              mid_writeClass_9db38fbd4bd0691f,
              mid_writeDouble_33af1645984dccd0,
              mid_writeHeterogeneousArray_0393fb4892ef177c,
              mid_writeHeterogeneousArray_1cf21c4db6e67f9d,
              mid_writeHomogeneousArray_0393fb4892ef177c,
              mid_writeHomogeneousArray_1cf21c4db6e67f9d,
              mid_writeInt_067fffd124faf812,
              mid_writeLong_084221a7bf1ec290,
              mid_writeObject_1ad6fb9f57aedcee,
              mid_writePlanetObject_bf3a7642afe5903e,
              mid_writePointArray_2b834232d6e72e5e,
              mid_writePointArray_1cf21c4db6e67f9d,
              mid_writePolygonArray_e4fe288bfd121554,
              mid_writePolygonArray_1cf21c4db6e67f9d,
              mid_writeString_b6ad843bc42fd5a7,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit SerializableObject(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            SerializableObject(const SerializableObject& obj) : ::java::lang::Object(obj) {}

            static ::java::util::BitSet readBitSet(const ::java::io::InputStream &);
            static jboolean readBoolean(const ::java::io::InputStream &);
            static JArray< jbyte > readByteArray(const ::java::io::InputStream &);
            static ::java::lang::Class readClass(const ::java::io::InputStream &);
            static jdouble readDouble(const ::java::io::InputStream &);
            static JArray< SerializableObject > readHeterogeneousArray(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::io::InputStream &, const ::java::lang::Class &);
            static JArray< SerializableObject > readHomogeneousArray(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::io::InputStream &, const ::java::lang::Class &);
            static jint readInt(const ::java::io::InputStream &);
            static jlong readLong(const ::java::io::InputStream &);
            static SerializableObject readObject(const ::java::io::InputStream &);
            static SerializableObject readObject(const ::java::io::InputStream &, const ::java::lang::Class &);
            static SerializableObject readObject(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::io::InputStream &);
            static SerializableObject readObject(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::io::InputStream &, const ::java::lang::Class &);
            static ::org::apache::lucene::spatial3d::geom::PlanetObject readPlanetObject(const ::java::io::InputStream &);
            static JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > readPointArray(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::io::InputStream &);
            static JArray< ::org::apache::lucene::spatial3d::geom::GeoPolygon > readPolygonArray(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::io::InputStream &);
            static ::java::lang::String readString(const ::java::io::InputStream &);
            void write(const ::java::io::OutputStream &) const;
            static void writeBitSet(const ::java::io::OutputStream &, const ::java::util::BitSet &);
            static void writeBoolean(const ::java::io::OutputStream &, jboolean);
            static void writeByteArray(const ::java::io::OutputStream &, const JArray< jbyte > &);
            static void writeClass(const ::java::io::OutputStream &, const ::java::lang::Class &);
            static void writeDouble(const ::java::io::OutputStream &, jdouble);
            static void writeHeterogeneousArray(const ::java::io::OutputStream &, const JArray< SerializableObject > &);
            static void writeHeterogeneousArray(const ::java::io::OutputStream &, const ::java::util::List &);
            static void writeHomogeneousArray(const ::java::io::OutputStream &, const JArray< SerializableObject > &);
            static void writeHomogeneousArray(const ::java::io::OutputStream &, const ::java::util::List &);
            static void writeInt(const ::java::io::OutputStream &, jint);
            static void writeLong(const ::java::io::OutputStream &, jlong);
            static void writeObject(const ::java::io::OutputStream &, const SerializableObject &);
            static void writePlanetObject(const ::java::io::OutputStream &, const ::org::apache::lucene::spatial3d::geom::PlanetObject &);
            static void writePointArray(const ::java::io::OutputStream &, const JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > &);
            static void writePointArray(const ::java::io::OutputStream &, const ::java::util::List &);
            static void writePolygonArray(const ::java::io::OutputStream &, const JArray< ::org::apache::lucene::spatial3d::geom::GeoPolygon > &);
            static void writePolygonArray(const ::java::io::OutputStream &, const ::java::util::List &);
            static void writeString(const ::java::io::OutputStream &, const ::java::lang::String &);
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          extern PyType_Def PY_TYPE_DEF(SerializableObject);
          extern PyTypeObject *PY_TYPE(SerializableObject);

          class t_SerializableObject {
          public:
            PyObject_HEAD
            SerializableObject object;
            static PyObject *wrap_Object(const SerializableObject&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
