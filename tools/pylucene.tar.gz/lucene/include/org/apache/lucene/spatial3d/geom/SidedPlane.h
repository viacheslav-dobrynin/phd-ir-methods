#ifndef org_apache_lucene_spatial3d_geom_SidedPlane_H
#define org_apache_lucene_spatial3d_geom_SidedPlane_H

#include "org/apache/lucene/spatial3d/geom/Plane.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class PlanetModel;
          class Membership;
          class SidedPlane;
          class Vector;
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {

          class SidedPlane : public ::org::apache::lucene::spatial3d::geom::Plane {
           public:
            enum {
              mid_init$_07bc188bd358f0aa,
              mid_init$_58e6692c2c1d69da,
              mid_init$_be35b6e0396a9a74,
              mid_init$_14f700380cfd8fd9,
              mid_init$_8229561e3123e6eb,
              mid_init$_03138bde6266976d,
              mid_init$_acb373b3cbaef576,
              mid_init$_cc6bcc3b71f11cf4,
              mid_init$_e33434dc1d8b8377,
              mid_init$_4a9f90e7a657ef39,
              mid_constructNormalizedPerpendicularSidedPlane_cf7edec570fced69,
              mid_constructNormalizedThreePointSidedPlane_cf7edec570fced69,
              mid_constructSidedPlaneFromOnePoint_a8655eb0a08e4e30,
              mid_constructSidedPlaneFromTwoPoints_66d8ac5d8f9b7881,
              mid_equals_2a09f73f0549554f,
              mid_hashCode_f03edc6a210ac78c,
              mid_isWithin_dfc1d22fff391bdd,
              mid_strictlyWithin_ce821273f709beb7,
              mid_strictlyWithin_dfc1d22fff391bdd,
              mid_toString_cb1e3f35ce7b2bd1,
              max_mid
            };

            enum {
              fid_sigNum,
              max_fid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static jfieldID *fids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit SidedPlane(jobject obj) : ::org::apache::lucene::spatial3d::geom::Plane(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            SidedPlane(const SidedPlane& obj) : ::org::apache::lucene::spatial3d::geom::Plane(obj) {}

            jdouble _get_sigNum() const;

            SidedPlane(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            SidedPlane(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            SidedPlane(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble);
            SidedPlane(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &, jdouble);
            SidedPlane(const ::org::apache::lucene::spatial3d::geom::Vector &, jdouble, jdouble);
            SidedPlane(const ::org::apache::lucene::spatial3d::geom::Vector &, jboolean, const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            SidedPlane(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &, jdouble, jdouble, jdouble);
            SidedPlane(jdouble, jdouble, jdouble, const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            SidedPlane(jdouble, jdouble, jdouble, const ::org::apache::lucene::spatial3d::geom::Vector &, jdouble);
            SidedPlane(const ::org::apache::lucene::spatial3d::geom::Vector &, jdouble, jdouble, jdouble, jdouble);

            static SidedPlane constructNormalizedPerpendicularSidedPlane(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            static SidedPlane constructNormalizedThreePointSidedPlane(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            static SidedPlane constructSidedPlaneFromOnePoint(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Plane &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            static SidedPlane constructSidedPlaneFromTwoPoints(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            jboolean equals(const ::java::lang::Object &) const;
            jint hashCode() const;
            jboolean isWithin(jdouble, jdouble, jdouble) const;
            jboolean strictlyWithin(const ::org::apache::lucene::spatial3d::geom::Vector &) const;
            jboolean strictlyWithin(jdouble, jdouble, jdouble) const;
            ::java::lang::String toString() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          extern PyType_Def PY_TYPE_DEF(SidedPlane);
          extern PyTypeObject *PY_TYPE(SidedPlane);

          class t_SidedPlane {
          public:
            PyObject_HEAD
            SidedPlane object;
            static PyObject *wrap_Object(const SidedPlane&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
