#ifndef org_apache_lucene_spatial3d_geom_GeoDegenerateVerticalLine_H
#define org_apache_lucene_spatial3d_geom_GeoDegenerateVerticalLine_H

#include "org/apache/lucene/spatial3d/geom/GeoBaseBBox.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class PlanetModel;
          class Membership;
          class GeoBBox;
          class GeoShape;
          class Plane;
          class Bounds;
          class GeoPoint;
        }
      }
    }
  }
}
namespace java {
  namespace io {
    class OutputStream;
    class IOException;
    class InputStream;
  }
  namespace lang {
    class Class;
    class String;
    class Object;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {

          class GeoDegenerateVerticalLine : public ::org::apache::lucene::spatial3d::geom::GeoBaseBBox {
           public:
            enum {
              mid_init$_6753fce019f2ce62,
              mid_init$_c76e1927b1bcdc10,
              mid_equals_2a09f73f0549554f,
              mid_expand_72b98cb1978d212d,
              mid_getBounds_24ac88e75daf92c6,
              mid_getCenter_a71096bf51e24704,
              mid_getEdgePoints_d5f1659ac4042328,
              mid_getRadius_a6c1144f51bd8892,
              mid_getRelationship_0cb6d30bc67bcd78,
              mid_hashCode_f03edc6a210ac78c,
              mid_intersects_82d3c593f002b310,
              mid_intersects_cd9ba3e89bc0b1af,
              mid_isWithin_dfc1d22fff391bdd,
              mid_toString_cb1e3f35ce7b2bd1,
              mid_write_8fb87594300dbff6,
              mid_outsideDistance_9a7f9cee46a4c2e0,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit GeoDegenerateVerticalLine(jobject obj) : ::org::apache::lucene::spatial3d::geom::GeoBaseBBox(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            GeoDegenerateVerticalLine(const GeoDegenerateVerticalLine& obj) : ::org::apache::lucene::spatial3d::geom::GeoBaseBBox(obj) {}

            GeoDegenerateVerticalLine(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::io::InputStream &);
            GeoDegenerateVerticalLine(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble, jdouble);

            jboolean equals(const ::java::lang::Object &) const;
            ::org::apache::lucene::spatial3d::geom::GeoBBox expand(jdouble) const;
            void getBounds(const ::org::apache::lucene::spatial3d::geom::Bounds &) const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint getCenter() const;
            JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > getEdgePoints() const;
            jdouble getRadius() const;
            jint getRelationship(const ::org::apache::lucene::spatial3d::geom::GeoShape &) const;
            jint hashCode() const;
            jboolean intersects(const ::org::apache::lucene::spatial3d::geom::GeoShape &) const;
            jboolean intersects(const ::org::apache::lucene::spatial3d::geom::Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jboolean isWithin(jdouble, jdouble, jdouble) const;
            ::java::lang::String toString() const;
            void write(const ::java::io::OutputStream &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          extern PyType_Def PY_TYPE_DEF(GeoDegenerateVerticalLine);
          extern PyTypeObject *PY_TYPE(GeoDegenerateVerticalLine);

          class t_GeoDegenerateVerticalLine {
          public:
            PyObject_HEAD
            GeoDegenerateVerticalLine object;
            static PyObject *wrap_Object(const GeoDegenerateVerticalLine&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
