#ifndef org_apache_lucene_spatial3d_Geo3DPoint_H
#define org_apache_lucene_spatial3d_Geo3DPoint_H

#include "org/apache/lucene/document/Field.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class PlanetModel;
          class GeoShape;
        }
      }
      namespace geo {
        class Polygon;
      }
      namespace search {
        class Query;
      }
      namespace document {
        class FieldType;
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {

        class Geo3DPoint : public ::org::apache::lucene::document::Field {
         public:
          enum {
            mid_init$_7d84d6e5c4f466d8,
            mid_init$_b61b0770654d8222,
            mid_init$_542ed892c8a33e3a,
            mid_init$_0a941a7f21485e61,
            mid_decodeDimension_ab68f49f9312ff53,
            mid_encodeDimension_2f559871decb55a3,
            mid_newBoxQuery_8aaeef87c34cacf1,
            mid_newDistanceQuery_b8b7dba45f7355b9,
            mid_newLargePolygonQuery_bdce97f0a2454efd,
            mid_newPathQuery_0fc468c59d124da3,
            mid_newPolygonQuery_bdce97f0a2454efd,
            mid_newShapeQuery_f2eeeb3eb0b3aed1,
            mid_toString_cb1e3f35ce7b2bd1,
            max_mid
          };

          static ::java::lang::Class *class$;
          static jmethodID *mids$;
          static bool live$;
          static jclass initializeClass(bool);

          explicit Geo3DPoint(jobject obj) : ::org::apache::lucene::document::Field(obj) {
            if (obj != NULL && mids$ == NULL)
              env->getClass(initializeClass);
          }
          Geo3DPoint(const Geo3DPoint& obj) : ::org::apache::lucene::document::Field(obj) {}

          static ::org::apache::lucene::document::FieldType *TYPE;

          Geo3DPoint(const ::java::lang::String &, jdouble, jdouble);
          Geo3DPoint(const ::java::lang::String &, const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble);
          Geo3DPoint(const ::java::lang::String &, jdouble, jdouble, jdouble);
          Geo3DPoint(const ::java::lang::String &, const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble, jdouble);

          static jdouble decodeDimension(const JArray< jbyte > &, jint, const ::org::apache::lucene::spatial3d::geom::PlanetModel &);
          static void encodeDimension(jdouble, const JArray< jbyte > &, jint, const ::org::apache::lucene::spatial3d::geom::PlanetModel &);
          static ::org::apache::lucene::search::Query newBoxQuery(const ::java::lang::String &, const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble, jdouble, jdouble);
          static ::org::apache::lucene::search::Query newDistanceQuery(const ::java::lang::String &, const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble, jdouble);
          static ::org::apache::lucene::search::Query newLargePolygonQuery(const ::java::lang::String &, const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const JArray< ::org::apache::lucene::geo::Polygon > &);
          static ::org::apache::lucene::search::Query newPathQuery(const ::java::lang::String &, const JArray< jdouble > &, const JArray< jdouble > &, jdouble, const ::org::apache::lucene::spatial3d::geom::PlanetModel &);
          static ::org::apache::lucene::search::Query newPolygonQuery(const ::java::lang::String &, const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const JArray< ::org::apache::lucene::geo::Polygon > &);
          static ::org::apache::lucene::search::Query newShapeQuery(const ::java::lang::String &, const ::org::apache::lucene::spatial3d::geom::GeoShape &);
          ::java::lang::String toString() const;
        };
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        extern PyType_Def PY_TYPE_DEF(Geo3DPoint);
        extern PyTypeObject *PY_TYPE(Geo3DPoint);

        class t_Geo3DPoint {
        public:
          PyObject_HEAD
          Geo3DPoint object;
          static PyObject *wrap_Object(const Geo3DPoint&);
          static PyObject *wrap_jobject(const jobject&);
          static void install(PyObject *module);
          static void initialize(PyObject *module);
        };
      }
    }
  }
}

#endif
