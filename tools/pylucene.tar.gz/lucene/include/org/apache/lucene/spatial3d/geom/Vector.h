#ifndef org_apache_lucene_spatial3d_geom_Vector_H
#define org_apache_lucene_spatial3d_geom_Vector_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
  }
}
namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class Membership;
          class Vector;
        }
      }
    }
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {

          class Vector : public ::java::lang::Object {
           public:
            enum {
              mid_init$_07bc188bd358f0aa,
              mid_init$_e8712817fa781787,
              mid_init$_074638b265c37d14,
              mid_init$_25b2d8b35633e0cb,
              mid_crossProductEvaluateIsZero_7698d58b788187bc,
              mid_dotProduct_60f8f5749f731e2f,
              mid_dotProduct_7f127f3c08422cdd,
              mid_equals_2a09f73f0549554f,
              mid_hashCode_f03edc6a210ac78c,
              mid_isNumericallyIdentical_ce821273f709beb7,
              mid_isNumericallyIdentical_dfc1d22fff391bdd,
              mid_isParallel_ce821273f709beb7,
              mid_isParallel_dfc1d22fff391bdd,
              mid_isWithin_0a629076c7b8baa9,
              mid_linearDistance_60f8f5749f731e2f,
              mid_linearDistance_7f127f3c08422cdd,
              mid_linearDistanceSquared_60f8f5749f731e2f,
              mid_linearDistanceSquared_7f127f3c08422cdd,
              mid_magnitude_a6c1144f51bd8892,
              mid_magnitude_7f127f3c08422cdd,
              mid_normalDistance_60f8f5749f731e2f,
              mid_normalDistance_7f127f3c08422cdd,
              mid_normalDistanceSquared_60f8f5749f731e2f,
              mid_normalDistanceSquared_7f127f3c08422cdd,
              mid_normalize_6a55170d016cb4ee,
              mid_rotateXY_16757e95e5f25738,
              mid_rotateXY_39f501def8bc0e32,
              mid_rotateXZ_16757e95e5f25738,
              mid_rotateXZ_39f501def8bc0e32,
              mid_rotateZY_16757e95e5f25738,
              mid_rotateZY_39f501def8bc0e32,
              mid_toString_cb1e3f35ce7b2bd1,
              mid_translate_f066b70b300c35f8,
              max_mid
            };

            enum {
              fid_x,
              fid_y,
              fid_z,
              max_fid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static jfieldID *fids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit Vector(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            Vector(const Vector& obj) : ::java::lang::Object(obj) {}

            static jdouble MINIMUM_ANGULAR_RESOLUTION;
            static jdouble MINIMUM_RESOLUTION;
            static jdouble MINIMUM_RESOLUTION_CUBED;
            static jdouble MINIMUM_RESOLUTION_SQUARED;

            jdouble _get_x() const;
            jdouble _get_y() const;
            jdouble _get_z() const;

            Vector(const Vector &, const Vector &);
            Vector(jdouble, jdouble, jdouble);
            Vector(const Vector &, jdouble, jdouble, jdouble);
            Vector(jdouble, jdouble, jdouble, jdouble, jdouble, jdouble);

            static jboolean crossProductEvaluateIsZero(const Vector &, const Vector &, const Vector &);
            jdouble dotProduct(const Vector &) const;
            jdouble dotProduct(jdouble, jdouble, jdouble) const;
            jboolean equals(const ::java::lang::Object &) const;
            jint hashCode() const;
            jboolean isNumericallyIdentical(const Vector &) const;
            jboolean isNumericallyIdentical(jdouble, jdouble, jdouble) const;
            jboolean isParallel(const Vector &) const;
            jboolean isParallel(jdouble, jdouble, jdouble) const;
            jboolean isWithin(const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jdouble linearDistance(const Vector &) const;
            jdouble linearDistance(jdouble, jdouble, jdouble) const;
            jdouble linearDistanceSquared(const Vector &) const;
            jdouble linearDistanceSquared(jdouble, jdouble, jdouble) const;
            jdouble magnitude() const;
            static jdouble magnitude(jdouble, jdouble, jdouble);
            jdouble normalDistance(const Vector &) const;
            jdouble normalDistance(jdouble, jdouble, jdouble) const;
            jdouble normalDistanceSquared(const Vector &) const;
            jdouble normalDistanceSquared(jdouble, jdouble, jdouble) const;
            Vector normalize() const;
            Vector rotateXY(jdouble) const;
            Vector rotateXY(jdouble, jdouble) const;
            Vector rotateXZ(jdouble) const;
            Vector rotateXZ(jdouble, jdouble) const;
            Vector rotateZY(jdouble) const;
            Vector rotateZY(jdouble, jdouble) const;
            ::java::lang::String toString() const;
            Vector translate(jdouble, jdouble, jdouble) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          extern PyType_Def PY_TYPE_DEF(Vector);
          extern PyTypeObject *PY_TYPE(Vector);

          class t_Vector {
          public:
            PyObject_HEAD
            Vector object;
            static PyObject *wrap_Object(const Vector&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
