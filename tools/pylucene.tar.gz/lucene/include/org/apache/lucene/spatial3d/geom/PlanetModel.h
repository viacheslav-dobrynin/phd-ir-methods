#ifndef org_apache_lucene_spatial3d_geom_PlanetModel_H
#define org_apache_lucene_spatial3d_geom_PlanetModel_H

#include "java/lang/Object.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class PlanetModel;
          class SerializableObject;
          class Vector;
          class PlanetModel$DocValueEncoder;
          class GeoPoint;
        }
      }
    }
  }
}
namespace java {
  namespace io {
    class OutputStream;
    class IOException;
    class InputStream;
  }
  namespace lang {
    class Class;
    class String;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {

          class PlanetModel : public ::java::lang::Object {
           public:
            enum {
              mid_init$_0c01d19e107a92b8,
              mid_init$_f01cba7a0848da02,
              mid_bisection_623af64549900f98,
              mid_createSurfacePoint_7abad89fd31bb7dc,
              mid_createSurfacePoint_fcc3d958b1e5104a,
              mid_decodeValue_c08ef01829a1bee6,
              mid_encodeValue_43b58587b325d39c,
              mid_equals_2a09f73f0549554f,
              mid_getDocValueEncoder_5a2bfccf7023d2f5,
              mid_getMaximumMagnitude_a6c1144f51bd8892,
              mid_getMaximumXValue_a6c1144f51bd8892,
              mid_getMaximumYValue_a6c1144f51bd8892,
              mid_getMaximumZValue_a6c1144f51bd8892,
              mid_getMeanRadius_a6c1144f51bd8892,
              mid_getMinimumMagnitude_a6c1144f51bd8892,
              mid_getMinimumXValue_a6c1144f51bd8892,
              mid_getMinimumYValue_a6c1144f51bd8892,
              mid_getMinimumZValue_a6c1144f51bd8892,
              mid_hashCode_f03edc6a210ac78c,
              mid_isSphere_201fceb6e9f1d0c5,
              mid_pointOnSurface_ce821273f709beb7,
              mid_pointOnSurface_dfc1d22fff391bdd,
              mid_pointOutside_ce821273f709beb7,
              mid_pointOutside_dfc1d22fff391bdd,
              mid_surfaceDistance_c50b329cb1d19e42,
              mid_surfacePointOnBearing_8501bb86530b7d7f,
              mid_toString_cb1e3f35ce7b2bd1,
              mid_write_8fb87594300dbff6,
              max_mid
            };

            enum {
              fid_DECODE,
              fid_MAX_ENCODED_VALUE,
              fid_MAX_VALUE,
              fid_MAX_X_POLE,
              fid_MAX_Y_POLE,
              fid_MIN_ENCODED_VALUE,
              fid_MIN_X_POLE,
              fid_MIN_Y_POLE,
              fid_NORTH_POLE,
              fid_SOUTH_POLE,
              fid_a,
              fid_b,
              fid_docValueEncoder,
              fid_inverseScale,
              fid_inverseXYScaling,
              fid_inverseXYScalingSquared,
              fid_inverseZScaling,
              fid_inverseZScalingSquared,
              fid_meanRadius,
              fid_minimumPoleDistance,
              fid_scale,
              fid_scaledFlattening,
              fid_squareRatio,
              fid_xyScaling,
              fid_zScaling,
              max_fid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static jfieldID *fids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit PlanetModel(jobject obj) : ::java::lang::Object(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            PlanetModel(const PlanetModel& obj) : ::java::lang::Object(obj) {}

            static PlanetModel *CLARKE_1866;
            static PlanetModel *SPHERE;
            static PlanetModel *WGS84;

            jdouble _get_DECODE() const;
            jint _get_MAX_ENCODED_VALUE() const;
            jdouble _get_MAX_VALUE() const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint _get_MAX_X_POLE() const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint _get_MAX_Y_POLE() const;
            jint _get_MIN_ENCODED_VALUE() const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint _get_MIN_X_POLE() const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint _get_MIN_Y_POLE() const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint _get_NORTH_POLE() const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint _get_SOUTH_POLE() const;
            jdouble _get_a() const;
            jdouble _get_b() const;
            ::org::apache::lucene::spatial3d::geom::PlanetModel$DocValueEncoder _get_docValueEncoder() const;
            jdouble _get_inverseScale() const;
            jdouble _get_inverseXYScaling() const;
            jdouble _get_inverseXYScalingSquared() const;
            jdouble _get_inverseZScaling() const;
            jdouble _get_inverseZScalingSquared() const;
            jdouble _get_meanRadius() const;
            jdouble _get_minimumPoleDistance() const;
            jdouble _get_scale() const;
            jdouble _get_scaledFlattening() const;
            jdouble _get_squareRatio() const;
            jdouble _get_xyScaling() const;
            jdouble _get_zScaling() const;

            PlanetModel(const ::java::io::InputStream &);
            PlanetModel(jdouble, jdouble);

            ::org::apache::lucene::spatial3d::geom::GeoPoint bisection(const ::org::apache::lucene::spatial3d::geom::GeoPoint &, const ::org::apache::lucene::spatial3d::geom::GeoPoint &) const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint createSurfacePoint(const ::org::apache::lucene::spatial3d::geom::Vector &) const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint createSurfacePoint(jdouble, jdouble, jdouble) const;
            jdouble decodeValue(jint) const;
            jint encodeValue(jdouble) const;
            jboolean equals(const ::java::lang::Object &) const;
            ::org::apache::lucene::spatial3d::geom::PlanetModel$DocValueEncoder getDocValueEncoder() const;
            jdouble getMaximumMagnitude() const;
            jdouble getMaximumXValue() const;
            jdouble getMaximumYValue() const;
            jdouble getMaximumZValue() const;
            jdouble getMeanRadius() const;
            jdouble getMinimumMagnitude() const;
            jdouble getMinimumXValue() const;
            jdouble getMinimumYValue() const;
            jdouble getMinimumZValue() const;
            jint hashCode() const;
            jboolean isSphere() const;
            jboolean pointOnSurface(const ::org::apache::lucene::spatial3d::geom::Vector &) const;
            jboolean pointOnSurface(jdouble, jdouble, jdouble) const;
            jboolean pointOutside(const ::org::apache::lucene::spatial3d::geom::Vector &) const;
            jboolean pointOutside(jdouble, jdouble, jdouble) const;
            jdouble surfaceDistance(const ::org::apache::lucene::spatial3d::geom::GeoPoint &, const ::org::apache::lucene::spatial3d::geom::GeoPoint &) const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint surfacePointOnBearing(const ::org::apache::lucene::spatial3d::geom::GeoPoint &, jdouble, jdouble) const;
            ::java::lang::String toString() const;
            void write(const ::java::io::OutputStream &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          extern PyType_Def PY_TYPE_DEF(PlanetModel);
          extern PyTypeObject *PY_TYPE(PlanetModel);

          class t_PlanetModel {
          public:
            PyObject_HEAD
            PlanetModel object;
            static PyObject *wrap_Object(const PlanetModel&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
