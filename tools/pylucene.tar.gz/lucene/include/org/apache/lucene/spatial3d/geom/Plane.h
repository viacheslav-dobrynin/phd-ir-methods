#ifndef org_apache_lucene_spatial3d_geom_Plane_H
#define org_apache_lucene_spatial3d_geom_Plane_H

#include "org/apache/lucene/spatial3d/geom/Vector.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class PlanetModel;
          class Membership;
          class Plane;
          class GeoPoint;
          class XYZBounds;
          class LatLonBounds;
        }
      }
    }
  }
}
namespace java {
  namespace lang {
    class Class;
    class String;
    class Object;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {

          class Plane : public ::org::apache::lucene::spatial3d::geom::Vector {
           public:
            enum {
              mid_init$_2943f311992db383,
              mid_init$_07bc188bd358f0aa,
              mid_init$_8a5e8494eb56916c,
              mid_init$_1744c13e77f7ec0b,
              mid_init$_f01cba7a0848da02,
              mid_init$_074638b265c37d14,
              mid_init$_90d62ebcb15f2348,
              mid_arcDistance_758cace9ef168d7b,
              mid_arcDistance_d07e99806dd0ec5e,
              mid_arePointsCoplanar_01543e406c978492,
              mid_constructNormalizedXPlane_4eed2b3d86212857,
              mid_constructNormalizedXPlane_a1fba58c93037d89,
              mid_constructNormalizedYPlane_4eed2b3d86212857,
              mid_constructNormalizedYPlane_a1fba58c93037d89,
              mid_constructNormalizedZPlane_4eed2b3d86212857,
              mid_constructNormalizedZPlane_ff325857e6dafee5,
              mid_constructPerpendicularCenterPlaneOnePoint_17f43d196ffa23bc,
              mid_constructPerpendicularCenterPlaneTwoPoints_ecf11c3f9af6a55b,
              mid_crosses_9fff97be468e1d65,
              mid_equals_2a09f73f0549554f,
              mid_evaluate_60f8f5749f731e2f,
              mid_evaluate_7f127f3c08422cdd,
              mid_evaluateIsZero_ce821273f709beb7,
              mid_evaluateIsZero_dfc1d22fff391bdd,
              mid_findArcDistancePoints_cf82b8540f6dc3f7,
              mid_findCrossings_18fc6a14c50676df,
              mid_findIntersections_18fc6a14c50676df,
              mid_getSampleIntersectionPoint_c57253faaa9babb8,
              mid_hashCode_f03edc6a210ac78c,
              mid_interpolate_6354d110a4563bee,
              mid_intersects_9fff97be468e1d65,
              mid_isFunctionallyIdentical_7290b720c5768894,
              mid_isNumericallyIdentical_7290b720c5768894,
              mid_linearDistance_758cace9ef168d7b,
              mid_linearDistance_d07e99806dd0ec5e,
              mid_linearDistanceSquared_758cace9ef168d7b,
              mid_linearDistanceSquared_d07e99806dd0ec5e,
              mid_normalDistance_2dadd50d72926fa7,
              mid_normalDistance_e00039e17230aa23,
              mid_normalDistanceSquared_2dadd50d72926fa7,
              mid_normalDistanceSquared_e00039e17230aa23,
              mid_normalize_66266da4830f1934,
              mid_recordBounds_0c24558013539efb,
              mid_recordBounds_bd21f6e6891e455b,
              mid_recordBounds_0cf5433d7dce4791,
              mid_recordBounds_a36e83525d9d39de,
              mid_toString_cb1e3f35ce7b2bd1,
              mid_findIntersections_ebda4fe725cec330,
              mid_modify_2b6af3275a930002,
              mid_reverseModify_2d68fea26ae83ff8,
              mid_findCrossings_ebda4fe725cec330,
              mid_findIntersectionBounds_a7c1155862a80553,
              max_mid
            };

            enum {
              fid_D,
              max_fid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static jfieldID *fids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit Plane(jobject obj) : ::org::apache::lucene::spatial3d::geom::Vector(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            Plane(const Plane& obj) : ::org::apache::lucene::spatial3d::geom::Vector(obj) {}

            static JArray< ::org::apache::lucene::spatial3d::geom::Membership > *NO_BOUNDS;
            static JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > *NO_POINTS;
            static Plane *normalXPlane;
            static Plane *normalYPlane;
            static Plane *normalZPlane;

            jdouble _get_D() const;

            Plane(const Plane &, jboolean);
            Plane(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            Plane(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble);
            Plane(const ::org::apache::lucene::spatial3d::geom::Vector &, jdouble);
            Plane(jdouble, jdouble);
            Plane(const ::org::apache::lucene::spatial3d::geom::Vector &, jdouble, jdouble, jdouble);
            Plane(jdouble, jdouble, jdouble, jdouble);

            jdouble arcDistance(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::GeoPoint &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jdouble arcDistance(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble, jdouble, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            static jboolean arePointsCoplanar(const ::org::apache::lucene::spatial3d::geom::GeoPoint &, const ::org::apache::lucene::spatial3d::geom::GeoPoint &, const ::org::apache::lucene::spatial3d::geom::GeoPoint &);
            static Plane constructNormalizedXPlane(const JArray< ::org::apache::lucene::spatial3d::geom::Vector > &);
            static Plane constructNormalizedXPlane(jdouble, jdouble, jdouble);
            static Plane constructNormalizedYPlane(const JArray< ::org::apache::lucene::spatial3d::geom::Vector > &);
            static Plane constructNormalizedYPlane(jdouble, jdouble, jdouble);
            static Plane constructNormalizedZPlane(const JArray< ::org::apache::lucene::spatial3d::geom::Vector > &);
            static Plane constructNormalizedZPlane(jdouble, jdouble);
            static Plane constructPerpendicularCenterPlaneOnePoint(const Plane &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            static Plane constructPerpendicularCenterPlaneTwoPoints(const ::org::apache::lucene::spatial3d::geom::Vector &, const ::org::apache::lucene::spatial3d::geom::Vector &);
            jboolean crosses(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > &, const JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jboolean equals(const ::java::lang::Object &) const;
            jdouble evaluate(const ::org::apache::lucene::spatial3d::geom::Vector &) const;
            jdouble evaluate(jdouble, jdouble, jdouble) const;
            jboolean evaluateIsZero(const ::org::apache::lucene::spatial3d::geom::Vector &) const;
            jboolean evaluateIsZero(jdouble, jdouble, jdouble) const;
            JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > findArcDistancePoints(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, const ::org::apache::lucene::spatial3d::geom::GeoPoint &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > findCrossings(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > findIntersections(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            ::org::apache::lucene::spatial3d::geom::GeoPoint getSampleIntersectionPoint(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const Plane &) const;
            jint hashCode() const;
            JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > interpolate(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::GeoPoint &, const ::org::apache::lucene::spatial3d::geom::GeoPoint &, const JArray< jdouble > &) const;
            jboolean intersects(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > &, const JArray< ::org::apache::lucene::spatial3d::geom::GeoPoint > &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jboolean isFunctionallyIdentical(const Plane &) const;
            jboolean isNumericallyIdentical(const Plane &) const;
            jdouble linearDistance(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::GeoPoint &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jdouble linearDistance(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble, jdouble, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jdouble linearDistanceSquared(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::GeoPoint &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jdouble linearDistanceSquared(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble, jdouble, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jdouble normalDistance(const ::org::apache::lucene::spatial3d::geom::Vector &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jdouble normalDistance(jdouble, jdouble, jdouble, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jdouble normalDistanceSquared(const ::org::apache::lucene::spatial3d::geom::Vector &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            jdouble normalDistanceSquared(jdouble, jdouble, jdouble, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            Plane normalize() const;
            void recordBounds(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::LatLonBounds &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            void recordBounds(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::XYZBounds &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            void recordBounds(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::LatLonBounds &, const Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            void recordBounds(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::org::apache::lucene::spatial3d::geom::XYZBounds &, const Plane &, const JArray< ::org::apache::lucene::spatial3d::geom::Membership > &) const;
            ::java::lang::String toString() const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          extern PyType_Def PY_TYPE_DEF(Plane);
          extern PyTypeObject *PY_TYPE(Plane);

          class t_Plane {
          public:
            PyObject_HEAD
            Plane object;
            static PyObject *wrap_Object(const Plane&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
