#ifndef org_apache_lucene_spatial3d_geom_GeoPoint_H
#define org_apache_lucene_spatial3d_geom_GeoPoint_H

#include "org/apache/lucene/spatial3d/geom/Vector.h"

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          class PlanetModel;
          class SerializableObject;
          class GeoPoint;
        }
      }
    }
  }
}
namespace java {
  namespace io {
    class OutputStream;
    class IOException;
    class InputStream;
  }
  namespace lang {
    class Class;
    class String;
  }
}
template<class T> class JArray;

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {

          class GeoPoint : public ::org::apache::lucene::spatial3d::geom::Vector {
           public:
            enum {
              mid_init$_0c01d19e107a92b8,
              mid_init$_6753fce019f2ce62,
              mid_init$_b18676094e6a7dd1,
              mid_init$_e8712817fa781787,
              mid_init$_90d62ebcb15f2348,
              mid_init$_af1dd28f1125b830,
              mid_init$_aa11e67bb8890c4c,
              mid_init$_25b2d8b35633e0cb,
              mid_init$_d2f8ddbe880cc199,
              mid_arcDistance_60f8f5749f731e2f,
              mid_arcDistance_7f127f3c08422cdd,
              mid_getLatitude_a6c1144f51bd8892,
              mid_getLongitude_a6c1144f51bd8892,
              mid_isIdentical_f31023b5f8f589fe,
              mid_isIdentical_dfc1d22fff391bdd,
              mid_magnitude_a6c1144f51bd8892,
              mid_toString_cb1e3f35ce7b2bd1,
              mid_write_8fb87594300dbff6,
              max_mid
            };

            static ::java::lang::Class *class$;
            static jmethodID *mids$;
            static bool live$;
            static jclass initializeClass(bool);

            explicit GeoPoint(jobject obj) : ::org::apache::lucene::spatial3d::geom::Vector(obj) {
              if (obj != NULL && mids$ == NULL)
                env->getClass(initializeClass);
            }
            GeoPoint(const GeoPoint& obj) : ::org::apache::lucene::spatial3d::geom::Vector(obj) {}

            GeoPoint(const ::java::io::InputStream &);
            GeoPoint(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, const ::java::io::InputStream &);
            GeoPoint(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble);
            GeoPoint(jdouble, jdouble, jdouble);
            GeoPoint(jdouble, jdouble, jdouble, jdouble);
            GeoPoint(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble, jdouble, jdouble);
            GeoPoint(jdouble, jdouble, jdouble, jdouble, jdouble);
            GeoPoint(jdouble, jdouble, jdouble, jdouble, jdouble, jdouble);
            GeoPoint(const ::org::apache::lucene::spatial3d::geom::PlanetModel &, jdouble, jdouble, jdouble, jdouble, jdouble, jdouble);

            jdouble arcDistance(const ::org::apache::lucene::spatial3d::geom::Vector &) const;
            jdouble arcDistance(jdouble, jdouble, jdouble) const;
            jdouble getLatitude() const;
            jdouble getLongitude() const;
            jboolean isIdentical(const GeoPoint &) const;
            jboolean isIdentical(jdouble, jdouble, jdouble) const;
            jdouble magnitude() const;
            ::java::lang::String toString() const;
            void write(const ::java::io::OutputStream &) const;
          };
        }
      }
    }
  }
}

#include <Python.h>

namespace org {
  namespace apache {
    namespace lucene {
      namespace spatial3d {
        namespace geom {
          extern PyType_Def PY_TYPE_DEF(GeoPoint);
          extern PyTypeObject *PY_TYPE(GeoPoint);

          class t_GeoPoint {
          public:
            PyObject_HEAD
            GeoPoint object;
            static PyObject *wrap_Object(const GeoPoint&);
            static PyObject *wrap_jobject(const jobject&);
            static void install(PyObject *module);
            static void initialize(PyObject *module);
          };
        }
      }
    }
  }
}

#endif
