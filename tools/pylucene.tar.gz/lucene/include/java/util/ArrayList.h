#ifndef java_util_ArrayList_H
#define java_util_ArrayList_H

#include "java/util/AbstractList.h"

namespace java {
  namespace util {
    class Iterator;
    class Comparator;
    class ListIterator;
    namespace function {
      class Consumer;
      class UnaryOperator;
      class Predicate;
    }
    class List;
    class RandomAccess;
    class Spliterator;
    class Collection;
  }
  namespace lang {
    class Class;
    class Cloneable;
    class Object;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class ArrayList : public ::java::util::AbstractList {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_8730ba9dfaf23a7b,
        mid_init$_6225acc290c4d266,
        mid_add_2a09f73f0549554f,
        mid_add_5f2f5470fb8f6a0b,
        mid_addAll_7b89e2617455757c,
        mid_addAll_c75ddfad5d6428a2,
        mid_addFirst_e391a919b9e60fbb,
        mid_addLast_e391a919b9e60fbb,
        mid_clear_a5783a25d44ba15b,
        mid_clone_1543ec1f1674e5aa,
        mid_contains_2a09f73f0549554f,
        mid_ensureCapacity_8730ba9dfaf23a7b,
        mid_equals_2a09f73f0549554f,
        mid_forEach_857c265f607ccaa6,
        mid_get_1dce87679d904d14,
        mid_getFirst_1543ec1f1674e5aa,
        mid_getLast_1543ec1f1674e5aa,
        mid_hashCode_f03edc6a210ac78c,
        mid_indexOf_8734b42132ce8667,
        mid_isEmpty_201fceb6e9f1d0c5,
        mid_iterator_d58ed5f479280ab0,
        mid_lastIndexOf_8734b42132ce8667,
        mid_listIterator_e0a22399b6bb4af6,
        mid_listIterator_34439590583a9dad,
        mid_remove_1dce87679d904d14,
        mid_remove_2a09f73f0549554f,
        mid_removeAll_7b89e2617455757c,
        mid_removeFirst_1543ec1f1674e5aa,
        mid_removeIf_bc38e7d3fcf17e8f,
        mid_removeLast_1543ec1f1674e5aa,
        mid_replaceAll_d7a63356b46dde60,
        mid_retainAll_7b89e2617455757c,
        mid_set_2988283091a6a258,
        mid_size_f03edc6a210ac78c,
        mid_sort_20660e9f142d010d,
        mid_spliterator_c756d372a23560d4,
        mid_subList_0f33e52d73579509,
        mid_toArray_14b9ca3d477d4e16,
        mid_toArray_f23ec43bdb29bb2e,
        mid_trimToSize_a5783a25d44ba15b,
        mid_removeRange_948d154349f29e30,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit ArrayList(jobject obj) : ::java::util::AbstractList(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      ArrayList(const ArrayList& obj) : ::java::util::AbstractList(obj) {}

      ArrayList();
      ArrayList(jint);
      ArrayList(const ::java::util::Collection &);

      jboolean add(const ::java::lang::Object &) const;
      void add(jint, const ::java::lang::Object &) const;
      jboolean addAll(const ::java::util::Collection &) const;
      jboolean addAll(jint, const ::java::util::Collection &) const;
      void addFirst(const ::java::lang::Object &) const;
      void addLast(const ::java::lang::Object &) const;
      void clear() const;
      ::java::lang::Object clone() const;
      jboolean contains(const ::java::lang::Object &) const;
      void ensureCapacity(jint) const;
      jboolean equals(const ::java::lang::Object &) const;
      void forEach(const ::java::util::function::Consumer &) const;
      ::java::lang::Object get(jint) const;
      ::java::lang::Object getFirst() const;
      ::java::lang::Object getLast() const;
      jint hashCode() const;
      jint indexOf(const ::java::lang::Object &) const;
      jboolean isEmpty() const;
      ::java::util::Iterator iterator() const;
      jint lastIndexOf(const ::java::lang::Object &) const;
      ::java::util::ListIterator listIterator() const;
      ::java::util::ListIterator listIterator(jint) const;
      ::java::lang::Object remove(jint) const;
      jboolean remove(const ::java::lang::Object &) const;
      jboolean removeAll(const ::java::util::Collection &) const;
      ::java::lang::Object removeFirst() const;
      jboolean removeIf(const ::java::util::function::Predicate &) const;
      ::java::lang::Object removeLast() const;
      void replaceAll(const ::java::util::function::UnaryOperator &) const;
      jboolean retainAll(const ::java::util::Collection &) const;
      ::java::lang::Object set(jint, const ::java::lang::Object &) const;
      jint size() const;
      void sort(const ::java::util::Comparator &) const;
      ::java::util::Spliterator spliterator() const;
      ::java::util::List subList(jint, jint) const;
      JArray< ::java::lang::Object > toArray() const;
      JArray< ::java::lang::Object > toArray(const JArray< ::java::lang::Object > &) const;
      void trimToSize() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(ArrayList);
    extern PyTypeObject *PY_TYPE(ArrayList);

    class t_ArrayList {
    public:
      PyObject_HEAD
      ArrayList object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_ArrayList *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const ArrayList&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const ArrayList&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
