#ifndef java_util_Comparator_H
#define java_util_Comparator_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Comparator;
    namespace function {
      class ToDoubleFunction;
      class ToIntFunction;
      class Function;
      class ToLongFunction;
    }
  }
  namespace lang {
    class Comparable;
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class Comparator : public ::java::lang::Object {
     public:
      enum {
        mid_compare_7987741873b0ac5b,
        mid_comparing_0dee50b68f23252d,
        mid_comparing_7c0ede7bc455726c,
        mid_comparingDouble_e593d1273c604dfa,
        mid_comparingInt_33f2e5b64179d3c7,
        mid_comparingLong_f5802a5299712edb,
        mid_equals_2a09f73f0549554f,
        mid_naturalOrder_54213bfa5c9a50fd,
        mid_nullsFirst_9d548860eec69e16,
        mid_nullsLast_9d548860eec69e16,
        mid_reverseOrder_54213bfa5c9a50fd,
        mid_reversed_54213bfa5c9a50fd,
        mid_thenComparing_9d548860eec69e16,
        mid_thenComparing_0dee50b68f23252d,
        mid_thenComparing_7c0ede7bc455726c,
        mid_thenComparingDouble_e593d1273c604dfa,
        mid_thenComparingInt_33f2e5b64179d3c7,
        mid_thenComparingLong_f5802a5299712edb,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Comparator(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Comparator(const Comparator& obj) : ::java::lang::Object(obj) {}

      jint compare(const ::java::lang::Object &, const ::java::lang::Object &) const;
      static Comparator comparing(const ::java::util::function::Function &);
      static Comparator comparing(const ::java::util::function::Function &, const Comparator &);
      static Comparator comparingDouble(const ::java::util::function::ToDoubleFunction &);
      static Comparator comparingInt(const ::java::util::function::ToIntFunction &);
      static Comparator comparingLong(const ::java::util::function::ToLongFunction &);
      jboolean equals(const ::java::lang::Object &) const;
      static Comparator naturalOrder();
      static Comparator nullsFirst(const Comparator &);
      static Comparator nullsLast(const Comparator &);
      static Comparator reverseOrder();
      Comparator reversed() const;
      Comparator thenComparing(const Comparator &) const;
      Comparator thenComparing(const ::java::util::function::Function &) const;
      Comparator thenComparing(const ::java::util::function::Function &, const Comparator &) const;
      Comparator thenComparingDouble(const ::java::util::function::ToDoubleFunction &) const;
      Comparator thenComparingInt(const ::java::util::function::ToIntFunction &) const;
      Comparator thenComparingLong(const ::java::util::function::ToLongFunction &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(Comparator);
    extern PyTypeObject *PY_TYPE(Comparator);

    class t_Comparator {
    public:
      PyObject_HEAD
      Comparator object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_Comparator *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const Comparator&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const Comparator&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
