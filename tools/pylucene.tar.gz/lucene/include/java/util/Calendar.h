#ifndef java_util_Calendar_H
#define java_util_Calendar_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Date;
    class TimeZone;
    class Map;
    class Set;
    class Locale;
    class Calendar;
  }
  namespace lang {
    class Comparable;
    class Integer;
    class Class;
    class String;
    class Cloneable;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class Calendar : public ::java::lang::Object {
     public:
      enum {
        mid_add_948d154349f29e30,
        mid_after_2a09f73f0549554f,
        mid_before_2a09f73f0549554f,
        mid_clear_a5783a25d44ba15b,
        mid_clear_8730ba9dfaf23a7b,
        mid_clone_1543ec1f1674e5aa,
        mid_compareTo_5fe7f71d795a6362,
        mid_equals_2a09f73f0549554f,
        mid_get_ff66fe240ad72894,
        mid_getActualMaximum_ff66fe240ad72894,
        mid_getActualMinimum_ff66fe240ad72894,
        mid_getAvailableCalendarTypes_9cfd5750b6ef4685,
        mid_getAvailableLocales_731cc618dad45867,
        mid_getCalendarType_cb1e3f35ce7b2bd1,
        mid_getDisplayName_42475360bd8183d6,
        mid_getDisplayNames_2589c4d4057770f0,
        mid_getFirstDayOfWeek_f03edc6a210ac78c,
        mid_getGreatestMinimum_ff66fe240ad72894,
        mid_getInstance_1c82cc490d009ccd,
        mid_getInstance_e9bdb223f41bc19c,
        mid_getInstance_6710b7b6045a78d9,
        mid_getInstance_07eb5ba9e34b86d6,
        mid_getLeastMaximum_ff66fe240ad72894,
        mid_getMaximum_ff66fe240ad72894,
        mid_getMinimalDaysInFirstWeek_f03edc6a210ac78c,
        mid_getMinimum_ff66fe240ad72894,
        mid_getTime_f3700e53971d3bb6,
        mid_getTimeInMillis_d192af3db8896a5e,
        mid_getTimeZone_2390a80e62c8ee13,
        mid_getWeekYear_f03edc6a210ac78c,
        mid_getWeeksInWeekYear_f03edc6a210ac78c,
        mid_hashCode_f03edc6a210ac78c,
        mid_isLenient_201fceb6e9f1d0c5,
        mid_isSet_12fe561dd4de11f3,
        mid_isWeekDateSupported_201fceb6e9f1d0c5,
        mid_roll_526f6be0903fb66a,
        mid_roll_948d154349f29e30,
        mid_set_948d154349f29e30,
        mid_set_6d4ff2a5765e4d7a,
        mid_set_3ea80b2501d3c301,
        mid_set_c74788d0530c4124,
        mid_setFirstDayOfWeek_8730ba9dfaf23a7b,
        mid_setLenient_a5b6a940fc16c6a1,
        mid_setMinimalDaysInFirstWeek_8730ba9dfaf23a7b,
        mid_setTime_b8b6f113b31c41f5,
        mid_setTimeInMillis_270332bbfd4dc523,
        mid_setTimeZone_360e2577ada3581c,
        mid_setWeekDate_6d4ff2a5765e4d7a,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_computeFields_a5783a25d44ba15b,
        mid_complete_a5783a25d44ba15b,
        mid_internalGet_ff66fe240ad72894,
        mid_computeTime_a5783a25d44ba15b,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Calendar(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Calendar(const Calendar& obj) : ::java::lang::Object(obj) {}

      static jint ALL_STYLES;
      static jint AM;
      static jint AM_PM;
      static jint APRIL;
      static jint AUGUST;
      static jint DATE;
      static jint DAY_OF_MONTH;
      static jint DAY_OF_WEEK;
      static jint DAY_OF_WEEK_IN_MONTH;
      static jint DAY_OF_YEAR;
      static jint DECEMBER;
      static jint DST_OFFSET;
      static jint ERA;
      static jint FEBRUARY;
      static jint FIELD_COUNT;
      static jint FRIDAY;
      static jint HOUR;
      static jint HOUR_OF_DAY;
      static jint JANUARY;
      static jint JULY;
      static jint JUNE;
      static jint LONG;
      static jint LONG_FORMAT;
      static jint LONG_STANDALONE;
      static jint MARCH;
      static jint MAY;
      static jint MILLISECOND;
      static jint MINUTE;
      static jint MONDAY;
      static jint MONTH;
      static jint NARROW_FORMAT;
      static jint NARROW_STANDALONE;
      static jint NOVEMBER;
      static jint OCTOBER;
      static jint PM;
      static jint SATURDAY;
      static jint SECOND;
      static jint SEPTEMBER;
      static jint SHORT;
      static jint SHORT_FORMAT;
      static jint SHORT_STANDALONE;
      static jint SUNDAY;
      static jint THURSDAY;
      static jint TUESDAY;
      static jint UNDECIMBER;
      static jint WEDNESDAY;
      static jint WEEK_OF_MONTH;
      static jint WEEK_OF_YEAR;
      static jint YEAR;
      static jint ZONE_OFFSET;

      void add(jint, jint) const;
      jboolean after(const ::java::lang::Object &) const;
      jboolean before(const ::java::lang::Object &) const;
      void clear() const;
      void clear(jint) const;
      ::java::lang::Object clone() const;
      jint compareTo(const Calendar &) const;
      jboolean equals(const ::java::lang::Object &) const;
      jint get(jint) const;
      jint getActualMaximum(jint) const;
      jint getActualMinimum(jint) const;
      static ::java::util::Set getAvailableCalendarTypes();
      static JArray< ::java::util::Locale > getAvailableLocales();
      ::java::lang::String getCalendarType() const;
      ::java::lang::String getDisplayName(jint, jint, const ::java::util::Locale &) const;
      ::java::util::Map getDisplayNames(jint, jint, const ::java::util::Locale &) const;
      jint getFirstDayOfWeek() const;
      jint getGreatestMinimum(jint) const;
      static Calendar getInstance();
      static Calendar getInstance(const ::java::util::Locale &);
      static Calendar getInstance(const ::java::util::TimeZone &);
      static Calendar getInstance(const ::java::util::TimeZone &, const ::java::util::Locale &);
      jint getLeastMaximum(jint) const;
      jint getMaximum(jint) const;
      jint getMinimalDaysInFirstWeek() const;
      jint getMinimum(jint) const;
      ::java::util::Date getTime() const;
      jlong getTimeInMillis() const;
      ::java::util::TimeZone getTimeZone() const;
      jint getWeekYear() const;
      jint getWeeksInWeekYear() const;
      jint hashCode() const;
      jboolean isLenient() const;
      jboolean isSet(jint) const;
      jboolean isWeekDateSupported() const;
      void roll(jint, jboolean) const;
      void roll(jint, jint) const;
      void set(jint, jint) const;
      void set(jint, jint, jint) const;
      void set(jint, jint, jint, jint, jint) const;
      void set(jint, jint, jint, jint, jint, jint) const;
      void setFirstDayOfWeek(jint) const;
      void setLenient(jboolean) const;
      void setMinimalDaysInFirstWeek(jint) const;
      void setTime(const ::java::util::Date &) const;
      void setTimeInMillis(jlong) const;
      void setTimeZone(const ::java::util::TimeZone &) const;
      void setWeekDate(jint, jint, jint) const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(Calendar);
    extern PyTypeObject *PY_TYPE(Calendar);

    class t_Calendar {
    public:
      PyObject_HEAD
      Calendar object;
      static PyObject *wrap_Object(const Calendar&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
