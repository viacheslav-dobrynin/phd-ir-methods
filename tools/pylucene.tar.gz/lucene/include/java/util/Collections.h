#ifndef java_util_Collections_H
#define java_util_Collections_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Comparator;
    class SequencedSet;
    class SortedMap;
    class SequencedCollection;
    class SequencedMap;
    class Random;
    class List;
    class Collection;
    class Queue;
    class Iterator;
    class ArrayList;
    class Map;
    class Deque;
    class Enumeration;
    class ListIterator;
    class NavigableMap;
    class NavigableSet;
    class Set;
    class SortedSet;
  }
  namespace lang {
    class Class;
    class Comparable;
    class Boolean;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class Collections : public ::java::lang::Object {
     public:
      enum {
        mid_addAll_2f9f9b9e4f879c11,
        mid_asLifoQueue_8e05fea81a303999,
        mid_binarySearch_93d2d32127e678a3,
        mid_binarySearch_4a75d7eb82f03943,
        mid_checkedCollection_cb9755e86d9e446e,
        mid_checkedList_7230025055746aaa,
        mid_checkedMap_007d3a064c12035e,
        mid_checkedNavigableMap_bc87552e26c6590c,
        mid_checkedNavigableSet_47b6a5ac1d83aa59,
        mid_checkedQueue_a44e6c6eec4010fa,
        mid_checkedSet_ea6849cced2db2dd,
        mid_checkedSortedMap_56a32fac0783898e,
        mid_checkedSortedSet_ec78e93a0b0bec72,
        mid_copy_6cd447d35c0b5c73,
        mid_disjoint_16db12c3ed6c1d8b,
        mid_emptyEnumeration_1bd91a2eb94899f3,
        mid_emptyIterator_d58ed5f479280ab0,
        mid_emptyList_7b3206bb4e2462d2,
        mid_emptyListIterator_e0a22399b6bb4af6,
        mid_emptyMap_2ccd91d439ff7d1f,
        mid_emptyNavigableMap_bbfae36fce7fb5f7,
        mid_emptyNavigableSet_5a3105732aa6da73,
        mid_emptySet_9cfd5750b6ef4685,
        mid_emptySortedMap_af76364ef47a518d,
        mid_emptySortedSet_cd6da693b1fe6439,
        mid_enumeration_be72ecd1288cbc26,
        mid_fill_6e4e9afc276e9d87,
        mid_frequency_6c6cdefd40634a0a,
        mid_indexOfSubList_ba2da3fd9c8d209d,
        mid_lastIndexOfSubList_ba2da3fd9c8d209d,
        mid_list_bb388fe40c8a6b98,
        mid_max_1223ad28e6aa4bcd,
        mid_max_10d8ac1c00885350,
        mid_min_1223ad28e6aa4bcd,
        mid_min_10d8ac1c00885350,
        mid_nCopies_3f1777a66a67a5e6,
        mid_newSequencedSetFromMap_628bbabca8c183b1,
        mid_newSetFromMap_db107341ba6b03ba,
        mid_replaceAll_c34c4efa0f267e0a,
        mid_reverse_f67f24791a65dbbc,
        mid_reverseOrder_54213bfa5c9a50fd,
        mid_reverseOrder_9d548860eec69e16,
        mid_rotate_6069f38d6677e67e,
        mid_shuffle_f67f24791a65dbbc,
        mid_shuffle_07bb7a011409eab5,
        mid_singleton_a9609a0eb192d1f7,
        mid_singletonList_f4673ac0597255b6,
        mid_singletonMap_5fb037b553b18a48,
        mid_sort_f67f24791a65dbbc,
        mid_sort_c7bd3be8c935d7b3,
        mid_swap_71d0c81539db80ef,
        mid_synchronizedCollection_547e0100524b28e8,
        mid_synchronizedList_652189f915aa04ea,
        mid_synchronizedMap_1b2c08ce34c635bd,
        mid_synchronizedNavigableMap_36f20f412e72a3c6,
        mid_synchronizedNavigableSet_873f13ac2118b678,
        mid_synchronizedSet_4919fcecd06776ff,
        mid_synchronizedSortedMap_cf8fa2a158f95a1d,
        mid_synchronizedSortedSet_005989ee0956a59f,
        mid_unmodifiableCollection_547e0100524b28e8,
        mid_unmodifiableList_652189f915aa04ea,
        mid_unmodifiableMap_1b2c08ce34c635bd,
        mid_unmodifiableNavigableMap_36f20f412e72a3c6,
        mid_unmodifiableNavigableSet_873f13ac2118b678,
        mid_unmodifiableSequencedCollection_29eba522158b47f0,
        mid_unmodifiableSequencedMap_9f7430d83cc22f06,
        mid_unmodifiableSequencedSet_c972975792c61a51,
        mid_unmodifiableSet_4919fcecd06776ff,
        mid_unmodifiableSortedMap_cf8fa2a158f95a1d,
        mid_unmodifiableSortedSet_005989ee0956a59f,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Collections(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Collections(const Collections& obj) : ::java::lang::Object(obj) {}

      static ::java::util::List *EMPTY_LIST;
      static ::java::util::Map *EMPTY_MAP;
      static ::java::util::Set *EMPTY_SET;

      static jboolean addAll(const ::java::util::Collection &, const JArray< ::java::lang::Object > &);
      static ::java::util::Queue asLifoQueue(const ::java::util::Deque &);
      static jint binarySearch(const ::java::util::List &, const ::java::lang::Object &);
      static jint binarySearch(const ::java::util::List &, const ::java::lang::Object &, const ::java::util::Comparator &);
      static ::java::util::Collection checkedCollection(const ::java::util::Collection &, const ::java::lang::Class &);
      static ::java::util::List checkedList(const ::java::util::List &, const ::java::lang::Class &);
      static ::java::util::Map checkedMap(const ::java::util::Map &, const ::java::lang::Class &, const ::java::lang::Class &);
      static ::java::util::NavigableMap checkedNavigableMap(const ::java::util::NavigableMap &, const ::java::lang::Class &, const ::java::lang::Class &);
      static ::java::util::NavigableSet checkedNavigableSet(const ::java::util::NavigableSet &, const ::java::lang::Class &);
      static ::java::util::Queue checkedQueue(const ::java::util::Queue &, const ::java::lang::Class &);
      static ::java::util::Set checkedSet(const ::java::util::Set &, const ::java::lang::Class &);
      static ::java::util::SortedMap checkedSortedMap(const ::java::util::SortedMap &, const ::java::lang::Class &, const ::java::lang::Class &);
      static ::java::util::SortedSet checkedSortedSet(const ::java::util::SortedSet &, const ::java::lang::Class &);
      static void copy(const ::java::util::List &, const ::java::util::List &);
      static jboolean disjoint(const ::java::util::Collection &, const ::java::util::Collection &);
      static ::java::util::Enumeration emptyEnumeration();
      static ::java::util::Iterator emptyIterator();
      static ::java::util::List emptyList();
      static ::java::util::ListIterator emptyListIterator();
      static ::java::util::Map emptyMap();
      static ::java::util::NavigableMap emptyNavigableMap();
      static ::java::util::NavigableSet emptyNavigableSet();
      static ::java::util::Set emptySet();
      static ::java::util::SortedMap emptySortedMap();
      static ::java::util::SortedSet emptySortedSet();
      static ::java::util::Enumeration enumeration(const ::java::util::Collection &);
      static void fill(const ::java::util::List &, const ::java::lang::Object &);
      static jint frequency(const ::java::util::Collection &, const ::java::lang::Object &);
      static jint indexOfSubList(const ::java::util::List &, const ::java::util::List &);
      static jint lastIndexOfSubList(const ::java::util::List &, const ::java::util::List &);
      static ::java::util::ArrayList list(const ::java::util::Enumeration &);
      static ::java::lang::Object max$(const ::java::util::Collection &);
      static ::java::lang::Object max$(const ::java::util::Collection &, const ::java::util::Comparator &);
      static ::java::lang::Object min$(const ::java::util::Collection &);
      static ::java::lang::Object min$(const ::java::util::Collection &, const ::java::util::Comparator &);
      static ::java::util::List nCopies(jint, const ::java::lang::Object &);
      static ::java::util::SequencedSet newSequencedSetFromMap(const ::java::util::SequencedMap &);
      static ::java::util::Set newSetFromMap(const ::java::util::Map &);
      static jboolean replaceAll(const ::java::util::List &, const ::java::lang::Object &, const ::java::lang::Object &);
      static void reverse(const ::java::util::List &);
      static ::java::util::Comparator reverseOrder();
      static ::java::util::Comparator reverseOrder(const ::java::util::Comparator &);
      static void rotate(const ::java::util::List &, jint);
      static void shuffle(const ::java::util::List &);
      static void shuffle(const ::java::util::List &, const ::java::util::Random &);
      static ::java::util::Set singleton(const ::java::lang::Object &);
      static ::java::util::List singletonList(const ::java::lang::Object &);
      static ::java::util::Map singletonMap(const ::java::lang::Object &, const ::java::lang::Object &);
      static void sort(const ::java::util::List &);
      static void sort(const ::java::util::List &, const ::java::util::Comparator &);
      static void swap(const ::java::util::List &, jint, jint);
      static ::java::util::Collection synchronizedCollection(const ::java::util::Collection &);
      static ::java::util::List synchronizedList(const ::java::util::List &);
      static ::java::util::Map synchronizedMap(const ::java::util::Map &);
      static ::java::util::NavigableMap synchronizedNavigableMap(const ::java::util::NavigableMap &);
      static ::java::util::NavigableSet synchronizedNavigableSet(const ::java::util::NavigableSet &);
      static ::java::util::Set synchronizedSet(const ::java::util::Set &);
      static ::java::util::SortedMap synchronizedSortedMap(const ::java::util::SortedMap &);
      static ::java::util::SortedSet synchronizedSortedSet(const ::java::util::SortedSet &);
      static ::java::util::Collection unmodifiableCollection(const ::java::util::Collection &);
      static ::java::util::List unmodifiableList(const ::java::util::List &);
      static ::java::util::Map unmodifiableMap(const ::java::util::Map &);
      static ::java::util::NavigableMap unmodifiableNavigableMap(const ::java::util::NavigableMap &);
      static ::java::util::NavigableSet unmodifiableNavigableSet(const ::java::util::NavigableSet &);
      static ::java::util::SequencedCollection unmodifiableSequencedCollection(const ::java::util::SequencedCollection &);
      static ::java::util::SequencedMap unmodifiableSequencedMap(const ::java::util::SequencedMap &);
      static ::java::util::SequencedSet unmodifiableSequencedSet(const ::java::util::SequencedSet &);
      static ::java::util::Set unmodifiableSet(const ::java::util::Set &);
      static ::java::util::SortedMap unmodifiableSortedMap(const ::java::util::SortedMap &);
      static ::java::util::SortedSet unmodifiableSortedSet(const ::java::util::SortedSet &);
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(Collections);
    extern PyTypeObject *PY_TYPE(Collections);

    class t_Collections {
    public:
      PyObject_HEAD
      Collections object;
      static PyObject *wrap_Object(const Collections&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
