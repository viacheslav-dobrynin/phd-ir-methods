#ifndef java_util_SequencedMap_H
#define java_util_SequencedMap_H

#include "java/util/Map.h"

namespace java {
  namespace util {
    class SequencedSet;
    class SequencedCollection;
    class Map$Entry;
    class SequencedMap;
  }
  namespace lang {
    class Class;
    class Object;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class SequencedMap : public ::java::util::Map {
     public:
      enum {
        mid_firstEntry_a774e2aac5c2bfef,
        mid_lastEntry_a774e2aac5c2bfef,
        mid_pollFirstEntry_a774e2aac5c2bfef,
        mid_pollLastEntry_a774e2aac5c2bfef,
        mid_putFirst_c36cd8daf720e2b9,
        mid_putLast_c36cd8daf720e2b9,
        mid_reversed_055ed0809ec94d0a,
        mid_sequencedEntrySet_405a53aa5b5364ff,
        mid_sequencedKeySet_405a53aa5b5364ff,
        mid_sequencedValues_8fb3aa8e33618cad,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit SequencedMap(jobject obj) : ::java::util::Map(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      SequencedMap(const SequencedMap& obj) : ::java::util::Map(obj) {}

      ::java::util::Map$Entry firstEntry() const;
      ::java::util::Map$Entry lastEntry() const;
      ::java::util::Map$Entry pollFirstEntry() const;
      ::java::util::Map$Entry pollLastEntry() const;
      ::java::lang::Object putFirst(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::lang::Object putLast(const ::java::lang::Object &, const ::java::lang::Object &) const;
      SequencedMap reversed() const;
      ::java::util::SequencedSet sequencedEntrySet() const;
      ::java::util::SequencedSet sequencedKeySet() const;
      ::java::util::SequencedCollection sequencedValues() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(SequencedMap);
    extern PyTypeObject *PY_TYPE(SequencedMap);

    class t_SequencedMap {
    public:
      PyObject_HEAD
      SequencedMap object;
      PyTypeObject *parameters[2];
      static PyTypeObject **parameters_(t_SequencedMap *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const SequencedMap&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const SequencedMap&, PyTypeObject *, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
