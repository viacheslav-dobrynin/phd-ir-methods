#ifndef java_util_Date_H
#define java_util_Date_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Date;
  }
  namespace lang {
    class Comparable;
    class Class;
    class String;
    class Cloneable;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class Date : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_9b22ecdee06ea23c,
        mid_init$_270332bbfd4dc523,
        mid_init$_6d4ff2a5765e4d7a,
        mid_init$_3ea80b2501d3c301,
        mid_init$_c74788d0530c4124,
        mid_UTC_d943a1e72f381142,
        mid_after_a66284b3e9bde0ac,
        mid_before_a66284b3e9bde0ac,
        mid_clone_1543ec1f1674e5aa,
        mid_compareTo_b4eeafcac3531275,
        mid_equals_2a09f73f0549554f,
        mid_getDate_f03edc6a210ac78c,
        mid_getDay_f03edc6a210ac78c,
        mid_getHours_f03edc6a210ac78c,
        mid_getMinutes_f03edc6a210ac78c,
        mid_getMonth_f03edc6a210ac78c,
        mid_getSeconds_f03edc6a210ac78c,
        mid_getTime_d192af3db8896a5e,
        mid_getTimezoneOffset_f03edc6a210ac78c,
        mid_getYear_f03edc6a210ac78c,
        mid_hashCode_f03edc6a210ac78c,
        mid_parse_e62386a53b3682b5,
        mid_setDate_8730ba9dfaf23a7b,
        mid_setHours_8730ba9dfaf23a7b,
        mid_setMinutes_8730ba9dfaf23a7b,
        mid_setMonth_8730ba9dfaf23a7b,
        mid_setSeconds_8730ba9dfaf23a7b,
        mid_setTime_270332bbfd4dc523,
        mid_setYear_8730ba9dfaf23a7b,
        mid_toGMTString_cb1e3f35ce7b2bd1,
        mid_toLocaleString_cb1e3f35ce7b2bd1,
        mid_toString_cb1e3f35ce7b2bd1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Date(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Date(const Date& obj) : ::java::lang::Object(obj) {}

      Date();
      Date(const ::java::lang::String &);
      Date(jlong);
      Date(jint, jint, jint);
      Date(jint, jint, jint, jint, jint);
      Date(jint, jint, jint, jint, jint, jint);

      static jlong UTC(jint, jint, jint, jint, jint, jint);
      jboolean after(const Date &) const;
      jboolean before(const Date &) const;
      ::java::lang::Object clone() const;
      jint compareTo(const Date &) const;
      jboolean equals(const ::java::lang::Object &) const;
      jint getDate() const;
      jint getDay() const;
      jint getHours() const;
      jint getMinutes() const;
      jint getMonth() const;
      jint getSeconds() const;
      jlong getTime() const;
      jint getTimezoneOffset() const;
      jint getYear() const;
      jint hashCode() const;
      static jlong parse(const ::java::lang::String &);
      void setDate(jint) const;
      void setHours(jint) const;
      void setMinutes(jint) const;
      void setMonth(jint) const;
      void setSeconds(jint) const;
      void setTime(jlong) const;
      void setYear(jint) const;
      ::java::lang::String toGMTString() const;
      ::java::lang::String toLocaleString() const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(Date);
    extern PyTypeObject *PY_TYPE(Date);

    class t_Date {
    public:
      PyObject_HEAD
      Date object;
      static PyObject *wrap_Object(const Date&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
