#ifndef java_util_TimeZone_H
#define java_util_TimeZone_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Date;
    class TimeZone;
    class Locale;
  }
  namespace lang {
    class Class;
    class String;
    class Cloneable;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class TimeZone : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_clone_1543ec1f1674e5aa,
        mid_getAvailableIDs_c0724ba8b8f42824,
        mid_getAvailableIDs_e4c45a509d5692fb,
        mid_getDSTSavings_f03edc6a210ac78c,
        mid_getDefault_2390a80e62c8ee13,
        mid_getDisplayName_cb1e3f35ce7b2bd1,
        mid_getDisplayName_e3e73dfada614e4b,
        mid_getDisplayName_eeddd119c6d89873,
        mid_getDisplayName_96637d6d0ae95061,
        mid_getID_cb1e3f35ce7b2bd1,
        mid_getOffset_5d9f29daea117180,
        mid_getOffset_2efce4a7b4879bcc,
        mid_getRawOffset_f03edc6a210ac78c,
        mid_getTimeZone_976bd046fb1e1559,
        mid_hasSameRules_66bee5bcdf3917d5,
        mid_inDaylightTime_a66284b3e9bde0ac,
        mid_observesDaylightTime_201fceb6e9f1d0c5,
        mid_setDefault_360e2577ada3581c,
        mid_setID_9b22ecdee06ea23c,
        mid_setRawOffset_8730ba9dfaf23a7b,
        mid_useDaylightTime_201fceb6e9f1d0c5,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit TimeZone(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      TimeZone(const TimeZone& obj) : ::java::lang::Object(obj) {}

      static jint LONG;
      static jint SHORT;

      TimeZone();

      ::java::lang::Object clone() const;
      static JArray< ::java::lang::String > getAvailableIDs();
      static JArray< ::java::lang::String > getAvailableIDs(jint);
      jint getDSTSavings() const;
      static TimeZone getDefault();
      ::java::lang::String getDisplayName() const;
      ::java::lang::String getDisplayName(const ::java::util::Locale &) const;
      ::java::lang::String getDisplayName(jboolean, jint) const;
      ::java::lang::String getDisplayName(jboolean, jint, const ::java::util::Locale &) const;
      ::java::lang::String getID() const;
      jint getOffset(jlong) const;
      jint getOffset(jint, jint, jint, jint, jint, jint) const;
      jint getRawOffset() const;
      static TimeZone getTimeZone(const ::java::lang::String &);
      jboolean hasSameRules(const TimeZone &) const;
      jboolean inDaylightTime(const ::java::util::Date &) const;
      jboolean observesDaylightTime() const;
      static void setDefault(const TimeZone &);
      void setID(const ::java::lang::String &) const;
      void setRawOffset(jint) const;
      jboolean useDaylightTime() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(TimeZone);
    extern PyTypeObject *PY_TYPE(TimeZone);

    class t_TimeZone {
    public:
      PyObject_HEAD
      TimeZone object;
      static PyObject *wrap_Object(const TimeZone&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
