#ifndef java_util_HashMap_H
#define java_util_HashMap_H

#include "java/util/AbstractMap.h"

namespace java {
  namespace util {
    class Map$Entry;
    class Map;
    namespace function {
      class BiFunction;
      class BiConsumer;
      class Function;
    }
    class Set;
    class Collection;
    class HashMap;
  }
  namespace lang {
    class Class;
    class Cloneable;
    class Object;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class HashMap : public ::java::util::AbstractMap {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_8730ba9dfaf23a7b,
        mid_init$_5063440bb525b708,
        mid_init$_5e4d51bf720efbb5,
        mid_clear_a5783a25d44ba15b,
        mid_clone_1543ec1f1674e5aa,
        mid_compute_9ddc68cdde8953c9,
        mid_computeIfAbsent_a0dd6689cb926c9c,
        mid_computeIfPresent_9ddc68cdde8953c9,
        mid_containsKey_2a09f73f0549554f,
        mid_containsValue_2a09f73f0549554f,
        mid_entrySet_9cfd5750b6ef4685,
        mid_forEach_9615eed198547dc3,
        mid_get_c5b181c227f736f1,
        mid_getOrDefault_c36cd8daf720e2b9,
        mid_isEmpty_201fceb6e9f1d0c5,
        mid_keySet_9cfd5750b6ef4685,
        mid_merge_3581eab3ced00155,
        mid_newHashMap_eb22a353d4b46477,
        mid_put_c36cd8daf720e2b9,
        mid_putAll_5063440bb525b708,
        mid_putIfAbsent_c36cd8daf720e2b9,
        mid_remove_c5b181c227f736f1,
        mid_remove_2da6945294f52f16,
        mid_replace_c36cd8daf720e2b9,
        mid_replace_36f000641cbaeab5,
        mid_replaceAll_93e4227d3cd455ac,
        mid_size_f03edc6a210ac78c,
        mid_values_7ff6744e4f3958ed,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit HashMap(jobject obj) : ::java::util::AbstractMap(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      HashMap(const HashMap& obj) : ::java::util::AbstractMap(obj) {}

      HashMap();
      HashMap(jint);
      HashMap(const ::java::util::Map &);
      HashMap(jint, jfloat);

      void clear() const;
      ::java::lang::Object clone() const;
      ::java::lang::Object compute(const ::java::lang::Object &, const ::java::util::function::BiFunction &) const;
      ::java::lang::Object computeIfAbsent(const ::java::lang::Object &, const ::java::util::function::Function &) const;
      ::java::lang::Object computeIfPresent(const ::java::lang::Object &, const ::java::util::function::BiFunction &) const;
      jboolean containsKey(const ::java::lang::Object &) const;
      jboolean containsValue(const ::java::lang::Object &) const;
      ::java::util::Set entrySet() const;
      void forEach(const ::java::util::function::BiConsumer &) const;
      ::java::lang::Object get(const ::java::lang::Object &) const;
      ::java::lang::Object getOrDefault(const ::java::lang::Object &, const ::java::lang::Object &) const;
      jboolean isEmpty() const;
      ::java::util::Set keySet() const;
      ::java::lang::Object merge(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::util::function::BiFunction &) const;
      static HashMap newHashMap(jint);
      ::java::lang::Object put(const ::java::lang::Object &, const ::java::lang::Object &) const;
      void putAll(const ::java::util::Map &) const;
      ::java::lang::Object putIfAbsent(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::lang::Object remove(const ::java::lang::Object &) const;
      jboolean remove(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::lang::Object replace(const ::java::lang::Object &, const ::java::lang::Object &) const;
      jboolean replace(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &) const;
      void replaceAll(const ::java::util::function::BiFunction &) const;
      jint size() const;
      ::java::util::Collection values() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(HashMap);
    extern PyTypeObject *PY_TYPE(HashMap);

    class t_HashMap {
    public:
      PyObject_HEAD
      HashMap object;
      PyTypeObject *parameters[2];
      static PyTypeObject **parameters_(t_HashMap *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const HashMap&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const HashMap&, PyTypeObject *, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
