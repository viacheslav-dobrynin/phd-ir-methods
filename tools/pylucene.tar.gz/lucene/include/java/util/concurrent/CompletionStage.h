#ifndef java_util_concurrent_CompletionStage_H
#define java_util_concurrent_CompletionStage_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    namespace concurrent {
      class CompletableFuture;
      class CompletionStage;
      class Executor;
    }
    namespace function {
      class Consumer;
      class BiFunction;
      class BiConsumer;
      class Function;
    }
  }
  namespace lang {
    class Class;
    class Void;
    class Throwable;
    class Runnable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace concurrent {

      class CompletionStage : public ::java::lang::Object {
       public:
        enum {
          mid_acceptEither_dadbe13f0624dd24,
          mid_acceptEitherAsync_dadbe13f0624dd24,
          mid_acceptEitherAsync_6c86e99188909a67,
          mid_applyToEither_b9c1e42bd9d3351d,
          mid_applyToEitherAsync_b9c1e42bd9d3351d,
          mid_applyToEitherAsync_bbd179d5eb2637b6,
          mid_exceptionally_61d59b00a961daf0,
          mid_exceptionallyAsync_61d59b00a961daf0,
          mid_exceptionallyAsync_196eaecf5254dc57,
          mid_exceptionallyCompose_61d59b00a961daf0,
          mid_exceptionallyComposeAsync_61d59b00a961daf0,
          mid_exceptionallyComposeAsync_196eaecf5254dc57,
          mid_handle_3dfb7677f9f76c50,
          mid_handleAsync_3dfb7677f9f76c50,
          mid_handleAsync_4104713286af1d92,
          mid_runAfterBoth_798c7b7ac7f00b77,
          mid_runAfterBothAsync_798c7b7ac7f00b77,
          mid_runAfterBothAsync_0cea8e827ee52347,
          mid_runAfterEither_798c7b7ac7f00b77,
          mid_runAfterEitherAsync_798c7b7ac7f00b77,
          mid_runAfterEitherAsync_0cea8e827ee52347,
          mid_thenAccept_0a3657d9cd6c8252,
          mid_thenAcceptAsync_0a3657d9cd6c8252,
          mid_thenAcceptAsync_dd26cc3649dcbdde,
          mid_thenAcceptBoth_61059de072894d13,
          mid_thenAcceptBothAsync_61059de072894d13,
          mid_thenAcceptBothAsync_7ce5282fe75caa98,
          mid_thenApply_61d59b00a961daf0,
          mid_thenApplyAsync_61d59b00a961daf0,
          mid_thenApplyAsync_196eaecf5254dc57,
          mid_thenCombine_30925ada8d9cf175,
          mid_thenCombineAsync_30925ada8d9cf175,
          mid_thenCombineAsync_ef0978895e789fdb,
          mid_thenCompose_61d59b00a961daf0,
          mid_thenComposeAsync_61d59b00a961daf0,
          mid_thenComposeAsync_196eaecf5254dc57,
          mid_thenRun_48230d97b1ddfa8a,
          mid_thenRunAsync_48230d97b1ddfa8a,
          mid_thenRunAsync_52fdbe5a2c2c5472,
          mid_toCompletableFuture_35b8f0b05b1fea65,
          mid_whenComplete_112af9a0d6cd2efc,
          mid_whenCompleteAsync_112af9a0d6cd2efc,
          mid_whenCompleteAsync_da7089a676199be2,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit CompletionStage(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        CompletionStage(const CompletionStage& obj) : ::java::lang::Object(obj) {}

        CompletionStage acceptEither(const CompletionStage &, const ::java::util::function::Consumer &) const;
        CompletionStage acceptEitherAsync(const CompletionStage &, const ::java::util::function::Consumer &) const;
        CompletionStage acceptEitherAsync(const CompletionStage &, const ::java::util::function::Consumer &, const ::java::util::concurrent::Executor &) const;
        CompletionStage applyToEither(const CompletionStage &, const ::java::util::function::Function &) const;
        CompletionStage applyToEitherAsync(const CompletionStage &, const ::java::util::function::Function &) const;
        CompletionStage applyToEitherAsync(const CompletionStage &, const ::java::util::function::Function &, const ::java::util::concurrent::Executor &) const;
        CompletionStage exceptionally(const ::java::util::function::Function &) const;
        CompletionStage exceptionallyAsync(const ::java::util::function::Function &) const;
        CompletionStage exceptionallyAsync(const ::java::util::function::Function &, const ::java::util::concurrent::Executor &) const;
        CompletionStage exceptionallyCompose(const ::java::util::function::Function &) const;
        CompletionStage exceptionallyComposeAsync(const ::java::util::function::Function &) const;
        CompletionStage exceptionallyComposeAsync(const ::java::util::function::Function &, const ::java::util::concurrent::Executor &) const;
        CompletionStage handle(const ::java::util::function::BiFunction &) const;
        CompletionStage handleAsync(const ::java::util::function::BiFunction &) const;
        CompletionStage handleAsync(const ::java::util::function::BiFunction &, const ::java::util::concurrent::Executor &) const;
        CompletionStage runAfterBoth(const CompletionStage &, const ::java::lang::Runnable &) const;
        CompletionStage runAfterBothAsync(const CompletionStage &, const ::java::lang::Runnable &) const;
        CompletionStage runAfterBothAsync(const CompletionStage &, const ::java::lang::Runnable &, const ::java::util::concurrent::Executor &) const;
        CompletionStage runAfterEither(const CompletionStage &, const ::java::lang::Runnable &) const;
        CompletionStage runAfterEitherAsync(const CompletionStage &, const ::java::lang::Runnable &) const;
        CompletionStage runAfterEitherAsync(const CompletionStage &, const ::java::lang::Runnable &, const ::java::util::concurrent::Executor &) const;
        CompletionStage thenAccept(const ::java::util::function::Consumer &) const;
        CompletionStage thenAcceptAsync(const ::java::util::function::Consumer &) const;
        CompletionStage thenAcceptAsync(const ::java::util::function::Consumer &, const ::java::util::concurrent::Executor &) const;
        CompletionStage thenAcceptBoth(const CompletionStage &, const ::java::util::function::BiConsumer &) const;
        CompletionStage thenAcceptBothAsync(const CompletionStage &, const ::java::util::function::BiConsumer &) const;
        CompletionStage thenAcceptBothAsync(const CompletionStage &, const ::java::util::function::BiConsumer &, const ::java::util::concurrent::Executor &) const;
        CompletionStage thenApply(const ::java::util::function::Function &) const;
        CompletionStage thenApplyAsync(const ::java::util::function::Function &) const;
        CompletionStage thenApplyAsync(const ::java::util::function::Function &, const ::java::util::concurrent::Executor &) const;
        CompletionStage thenCombine(const CompletionStage &, const ::java::util::function::BiFunction &) const;
        CompletionStage thenCombineAsync(const CompletionStage &, const ::java::util::function::BiFunction &) const;
        CompletionStage thenCombineAsync(const CompletionStage &, const ::java::util::function::BiFunction &, const ::java::util::concurrent::Executor &) const;
        CompletionStage thenCompose(const ::java::util::function::Function &) const;
        CompletionStage thenComposeAsync(const ::java::util::function::Function &) const;
        CompletionStage thenComposeAsync(const ::java::util::function::Function &, const ::java::util::concurrent::Executor &) const;
        CompletionStage thenRun(const ::java::lang::Runnable &) const;
        CompletionStage thenRunAsync(const ::java::lang::Runnable &) const;
        CompletionStage thenRunAsync(const ::java::lang::Runnable &, const ::java::util::concurrent::Executor &) const;
        ::java::util::concurrent::CompletableFuture toCompletableFuture() const;
        CompletionStage whenComplete(const ::java::util::function::BiConsumer &) const;
        CompletionStage whenCompleteAsync(const ::java::util::function::BiConsumer &) const;
        CompletionStage whenCompleteAsync(const ::java::util::function::BiConsumer &, const ::java::util::concurrent::Executor &) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace concurrent {
      extern PyType_Def PY_TYPE_DEF(CompletionStage);
      extern PyTypeObject *PY_TYPE(CompletionStage);

      class t_CompletionStage {
      public:
        PyObject_HEAD
        CompletionStage object;
        PyTypeObject *parameters[1];
        static PyTypeObject **parameters_(t_CompletionStage *self)
        {
          return (PyTypeObject **) &(self->parameters);
        }
        static PyObject *wrap_Object(const CompletionStage&);
        static PyObject *wrap_jobject(const jobject&);
        static PyObject *wrap_Object(const CompletionStage&, PyTypeObject *);
        static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
