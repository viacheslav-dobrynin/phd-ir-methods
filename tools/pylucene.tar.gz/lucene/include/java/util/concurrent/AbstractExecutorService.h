#ifndef java_util_concurrent_AbstractExecutorService_H
#define java_util_concurrent_AbstractExecutorService_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Runnable;
    class Class;
    class InterruptedException;
  }
  namespace util {
    class List;
    namespace concurrent {
      class Future;
      class ExecutionException;
      class TimeUnit;
      class TimeoutException;
      class ExecutorService;
      class Callable;
    }
    class Collection;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace concurrent {

      class AbstractExecutorService : public ::java::lang::Object {
       public:
        enum {
          mid_init$_a5783a25d44ba15b,
          mid_invokeAll_7025b738636d69d8,
          mid_invokeAll_3ae399661a717e4f,
          mid_invokeAny_1223ad28e6aa4bcd,
          mid_invokeAny_67e82565ac6d1b06,
          mid_submit_da56e6d809fc0c72,
          mid_submit_71c76b32d51308c7,
          mid_submit_0caab88652797cf6,
          mid_newTaskFor_aa4d8641ad24e8ef,
          mid_newTaskFor_5fa2411edda02e3c,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit AbstractExecutorService(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        AbstractExecutorService(const AbstractExecutorService& obj) : ::java::lang::Object(obj) {}

        AbstractExecutorService();

        ::java::util::List invokeAll(const ::java::util::Collection &) const;
        ::java::util::List invokeAll(const ::java::util::Collection &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::lang::Object invokeAny(const ::java::util::Collection &) const;
        ::java::lang::Object invokeAny(const ::java::util::Collection &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::util::concurrent::Future submit(const ::java::lang::Runnable &) const;
        ::java::util::concurrent::Future submit(const ::java::util::concurrent::Callable &) const;
        ::java::util::concurrent::Future submit(const ::java::lang::Runnable &, const ::java::lang::Object &) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace concurrent {
      extern PyType_Def PY_TYPE_DEF(AbstractExecutorService);
      extern PyTypeObject *PY_TYPE(AbstractExecutorService);

      class t_AbstractExecutorService {
      public:
        PyObject_HEAD
        AbstractExecutorService object;
        static PyObject *wrap_Object(const AbstractExecutorService&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
