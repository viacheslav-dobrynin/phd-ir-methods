#ifndef java_util_concurrent_CompletableFuture_H
#define java_util_concurrent_CompletableFuture_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    namespace concurrent {
      class CompletableFuture;
      class TimeUnit;
      class CompletionStage;
      class Executor;
      class Future;
      class TimeoutException;
      class ExecutionException;
      class Future$State;
    }
    namespace function {
      class BiConsumer;
      class Supplier;
      class Function;
      class Consumer;
      class BiFunction;
    }
  }
  namespace lang {
    class Throwable;
    class Class;
    class String;
    class InterruptedException;
    class Void;
    class Runnable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace concurrent {

      class CompletableFuture : public ::java::lang::Object {
       public:
        enum {
          mid_init$_a5783a25d44ba15b,
          mid_acceptEither_9df4ed4e3e37505d,
          mid_acceptEitherAsync_9df4ed4e3e37505d,
          mid_acceptEitherAsync_de3acbdf914cb6cb,
          mid_allOf_e70863bf2016855e,
          mid_anyOf_e70863bf2016855e,
          mid_applyToEither_8b39c4f6e455cedc,
          mid_applyToEitherAsync_8b39c4f6e455cedc,
          mid_applyToEitherAsync_d147014eba203639,
          mid_cancel_babb0003dbd8064f,
          mid_complete_2a09f73f0549554f,
          mid_completeAsync_cca58e05c008db50,
          mid_completeAsync_046adc61175e1d37,
          mid_completeExceptionally_67033dc1ad3730ef,
          mid_completeOnTimeout_581c5795b2213b60,
          mid_completedFuture_661806d3ac44a749,
          mid_completedStage_ee0f9172035608a3,
          mid_copy_35b8f0b05b1fea65,
          mid_defaultExecutor_0892a99f2a3a12ba,
          mid_delayedExecutor_4cc846aa279061b6,
          mid_delayedExecutor_5f27da541999eb2b,
          mid_exceptionNow_f02b1c3defd1579e,
          mid_exceptionally_c9a747bb1bad7618,
          mid_exceptionallyAsync_c9a747bb1bad7618,
          mid_exceptionallyAsync_2fac52e16ae66ab8,
          mid_exceptionallyCompose_c9a747bb1bad7618,
          mid_exceptionallyComposeAsync_c9a747bb1bad7618,
          mid_exceptionallyComposeAsync_2fac52e16ae66ab8,
          mid_failedFuture_afc0a95270b7110c,
          mid_failedStage_55d50d192a220b25,
          mid_get_1543ec1f1674e5aa,
          mid_get_c280b622ac89a9fd,
          mid_getNow_c5b181c227f736f1,
          mid_getNumberOfDependents_f03edc6a210ac78c,
          mid_handle_1a226aca67a7f1c0,
          mid_handleAsync_1a226aca67a7f1c0,
          mid_handleAsync_ea7567cf8c2935f3,
          mid_isCancelled_201fceb6e9f1d0c5,
          mid_isCompletedExceptionally_201fceb6e9f1d0c5,
          mid_isDone_201fceb6e9f1d0c5,
          mid_join_1543ec1f1674e5aa,
          mid_minimalCompletionStage_624b520416ff251b,
          mid_newIncompleteFuture_35b8f0b05b1fea65,
          mid_obtrudeException_2c40686ddffa78ff,
          mid_obtrudeValue_e391a919b9e60fbb,
          mid_orTimeout_607c40f799117a39,
          mid_resultNow_1543ec1f1674e5aa,
          mid_runAfterBoth_2b3b04c5a04e4610,
          mid_runAfterBothAsync_2b3b04c5a04e4610,
          mid_runAfterBothAsync_ad14b1e36e52536a,
          mid_runAfterEither_2b3b04c5a04e4610,
          mid_runAfterEitherAsync_2b3b04c5a04e4610,
          mid_runAfterEitherAsync_ad14b1e36e52536a,
          mid_runAsync_e57b89ab34f222a4,
          mid_runAsync_57bdae0be441d6aa,
          mid_state_aa82d2227da03eba,
          mid_supplyAsync_cca58e05c008db50,
          mid_supplyAsync_046adc61175e1d37,
          mid_thenAccept_95c50a5a63f8bcbd,
          mid_thenAcceptAsync_95c50a5a63f8bcbd,
          mid_thenAcceptAsync_27b20330fdfc152b,
          mid_thenAcceptBoth_c699188d4e0e08ee,
          mid_thenAcceptBothAsync_c699188d4e0e08ee,
          mid_thenAcceptBothAsync_2e372e1668a5d231,
          mid_thenApply_c9a747bb1bad7618,
          mid_thenApplyAsync_c9a747bb1bad7618,
          mid_thenApplyAsync_2fac52e16ae66ab8,
          mid_thenCombine_31bba7a8b8a6e5ef,
          mid_thenCombineAsync_31bba7a8b8a6e5ef,
          mid_thenCombineAsync_3518fdaabb248a1c,
          mid_thenCompose_c9a747bb1bad7618,
          mid_thenComposeAsync_c9a747bb1bad7618,
          mid_thenComposeAsync_2fac52e16ae66ab8,
          mid_thenRun_e57b89ab34f222a4,
          mid_thenRunAsync_e57b89ab34f222a4,
          mid_thenRunAsync_57bdae0be441d6aa,
          mid_toCompletableFuture_35b8f0b05b1fea65,
          mid_toString_cb1e3f35ce7b2bd1,
          mid_whenComplete_401fba8c1d13cee0,
          mid_whenCompleteAsync_401fba8c1d13cee0,
          mid_whenCompleteAsync_c19010233603472f,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit CompletableFuture(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        CompletableFuture(const CompletableFuture& obj) : ::java::lang::Object(obj) {}

        CompletableFuture();

        CompletableFuture acceptEither(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::Consumer &) const;
        CompletableFuture acceptEitherAsync(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::Consumer &) const;
        CompletableFuture acceptEitherAsync(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::Consumer &, const ::java::util::concurrent::Executor &) const;
        static CompletableFuture allOf(const JArray< CompletableFuture > &);
        static CompletableFuture anyOf(const JArray< CompletableFuture > &);
        CompletableFuture applyToEither(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::Function &) const;
        CompletableFuture applyToEitherAsync(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::Function &) const;
        CompletableFuture applyToEitherAsync(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::Function &, const ::java::util::concurrent::Executor &) const;
        jboolean cancel(jboolean) const;
        jboolean complete(const ::java::lang::Object &) const;
        CompletableFuture completeAsync(const ::java::util::function::Supplier &) const;
        CompletableFuture completeAsync(const ::java::util::function::Supplier &, const ::java::util::concurrent::Executor &) const;
        jboolean completeExceptionally(const ::java::lang::Throwable &) const;
        CompletableFuture completeOnTimeout(const ::java::lang::Object &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        static CompletableFuture completedFuture(const ::java::lang::Object &);
        static ::java::util::concurrent::CompletionStage completedStage(const ::java::lang::Object &);
        CompletableFuture copy() const;
        ::java::util::concurrent::Executor defaultExecutor() const;
        static ::java::util::concurrent::Executor delayedExecutor(jlong, const ::java::util::concurrent::TimeUnit &);
        static ::java::util::concurrent::Executor delayedExecutor(jlong, const ::java::util::concurrent::TimeUnit &, const ::java::util::concurrent::Executor &);
        ::java::lang::Throwable exceptionNow() const;
        CompletableFuture exceptionally(const ::java::util::function::Function &) const;
        CompletableFuture exceptionallyAsync(const ::java::util::function::Function &) const;
        CompletableFuture exceptionallyAsync(const ::java::util::function::Function &, const ::java::util::concurrent::Executor &) const;
        CompletableFuture exceptionallyCompose(const ::java::util::function::Function &) const;
        CompletableFuture exceptionallyComposeAsync(const ::java::util::function::Function &) const;
        CompletableFuture exceptionallyComposeAsync(const ::java::util::function::Function &, const ::java::util::concurrent::Executor &) const;
        static CompletableFuture failedFuture(const ::java::lang::Throwable &);
        static ::java::util::concurrent::CompletionStage failedStage(const ::java::lang::Throwable &);
        ::java::lang::Object get() const;
        ::java::lang::Object get(jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::lang::Object getNow(const ::java::lang::Object &) const;
        jint getNumberOfDependents() const;
        CompletableFuture handle(const ::java::util::function::BiFunction &) const;
        CompletableFuture handleAsync(const ::java::util::function::BiFunction &) const;
        CompletableFuture handleAsync(const ::java::util::function::BiFunction &, const ::java::util::concurrent::Executor &) const;
        jboolean isCancelled() const;
        jboolean isCompletedExceptionally() const;
        jboolean isDone() const;
        ::java::lang::Object join() const;
        ::java::util::concurrent::CompletionStage minimalCompletionStage() const;
        CompletableFuture newIncompleteFuture() const;
        void obtrudeException(const ::java::lang::Throwable &) const;
        void obtrudeValue(const ::java::lang::Object &) const;
        CompletableFuture orTimeout(jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::lang::Object resultNow() const;
        CompletableFuture runAfterBoth(const ::java::util::concurrent::CompletionStage &, const ::java::lang::Runnable &) const;
        CompletableFuture runAfterBothAsync(const ::java::util::concurrent::CompletionStage &, const ::java::lang::Runnable &) const;
        CompletableFuture runAfterBothAsync(const ::java::util::concurrent::CompletionStage &, const ::java::lang::Runnable &, const ::java::util::concurrent::Executor &) const;
        CompletableFuture runAfterEither(const ::java::util::concurrent::CompletionStage &, const ::java::lang::Runnable &) const;
        CompletableFuture runAfterEitherAsync(const ::java::util::concurrent::CompletionStage &, const ::java::lang::Runnable &) const;
        CompletableFuture runAfterEitherAsync(const ::java::util::concurrent::CompletionStage &, const ::java::lang::Runnable &, const ::java::util::concurrent::Executor &) const;
        static CompletableFuture runAsync(const ::java::lang::Runnable &);
        static CompletableFuture runAsync(const ::java::lang::Runnable &, const ::java::util::concurrent::Executor &);
        ::java::util::concurrent::Future$State state() const;
        static CompletableFuture supplyAsync(const ::java::util::function::Supplier &);
        static CompletableFuture supplyAsync(const ::java::util::function::Supplier &, const ::java::util::concurrent::Executor &);
        CompletableFuture thenAccept(const ::java::util::function::Consumer &) const;
        CompletableFuture thenAcceptAsync(const ::java::util::function::Consumer &) const;
        CompletableFuture thenAcceptAsync(const ::java::util::function::Consumer &, const ::java::util::concurrent::Executor &) const;
        CompletableFuture thenAcceptBoth(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::BiConsumer &) const;
        CompletableFuture thenAcceptBothAsync(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::BiConsumer &) const;
        CompletableFuture thenAcceptBothAsync(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::BiConsumer &, const ::java::util::concurrent::Executor &) const;
        CompletableFuture thenApply(const ::java::util::function::Function &) const;
        CompletableFuture thenApplyAsync(const ::java::util::function::Function &) const;
        CompletableFuture thenApplyAsync(const ::java::util::function::Function &, const ::java::util::concurrent::Executor &) const;
        CompletableFuture thenCombine(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::BiFunction &) const;
        CompletableFuture thenCombineAsync(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::BiFunction &) const;
        CompletableFuture thenCombineAsync(const ::java::util::concurrent::CompletionStage &, const ::java::util::function::BiFunction &, const ::java::util::concurrent::Executor &) const;
        CompletableFuture thenCompose(const ::java::util::function::Function &) const;
        CompletableFuture thenComposeAsync(const ::java::util::function::Function &) const;
        CompletableFuture thenComposeAsync(const ::java::util::function::Function &, const ::java::util::concurrent::Executor &) const;
        CompletableFuture thenRun(const ::java::lang::Runnable &) const;
        CompletableFuture thenRunAsync(const ::java::lang::Runnable &) const;
        CompletableFuture thenRunAsync(const ::java::lang::Runnable &, const ::java::util::concurrent::Executor &) const;
        CompletableFuture toCompletableFuture() const;
        ::java::lang::String toString() const;
        CompletableFuture whenComplete(const ::java::util::function::BiConsumer &) const;
        CompletableFuture whenCompleteAsync(const ::java::util::function::BiConsumer &) const;
        CompletableFuture whenCompleteAsync(const ::java::util::function::BiConsumer &, const ::java::util::concurrent::Executor &) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace concurrent {
      extern PyType_Def PY_TYPE_DEF(CompletableFuture);
      extern PyTypeObject *PY_TYPE(CompletableFuture);

      class t_CompletableFuture {
      public:
        PyObject_HEAD
        CompletableFuture object;
        PyTypeObject *parameters[1];
        static PyTypeObject **parameters_(t_CompletableFuture *self)
        {
          return (PyTypeObject **) &(self->parameters);
        }
        static PyObject *wrap_Object(const CompletableFuture&);
        static PyObject *wrap_jobject(const jobject&);
        static PyObject *wrap_Object(const CompletableFuture&, PyTypeObject *);
        static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
