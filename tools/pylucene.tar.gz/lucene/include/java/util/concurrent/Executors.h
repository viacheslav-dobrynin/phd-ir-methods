#ifndef java_util_concurrent_Executors_H
#define java_util_concurrent_Executors_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Runnable;
    class Class;
  }
  namespace util {
    namespace concurrent {
      class ThreadFactory;
      class ScheduledExecutorService;
      class ExecutorService;
      class Callable;
    }
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace concurrent {

      class Executors : public ::java::lang::Object {
       public:
        enum {
          mid_callable_59ffdff219f4fc6d,
          mid_callable_e98b874670c5bd00,
          mid_defaultThreadFactory_3cc367e4fd0607c1,
          mid_newCachedThreadPool_5a100588aac2b8fd,
          mid_newCachedThreadPool_798f42656da439c9,
          mid_newFixedThreadPool_daf50cb5f98c457c,
          mid_newFixedThreadPool_f4b24a6f28edd1de,
          mid_newScheduledThreadPool_5a382bf3d4c93428,
          mid_newScheduledThreadPool_dcd8ad2237b29233,
          mid_newSingleThreadExecutor_5a100588aac2b8fd,
          mid_newSingleThreadExecutor_798f42656da439c9,
          mid_newSingleThreadScheduledExecutor_36cf2fb79bf479db,
          mid_newSingleThreadScheduledExecutor_4e1706069692134a,
          mid_newThreadPerTaskExecutor_798f42656da439c9,
          mid_newVirtualThreadPerTaskExecutor_5a100588aac2b8fd,
          mid_newWorkStealingPool_5a100588aac2b8fd,
          mid_newWorkStealingPool_daf50cb5f98c457c,
          mid_privilegedCallable_30190a3e16aff898,
          mid_privilegedCallableUsingCurrentClassLoader_30190a3e16aff898,
          mid_privilegedThreadFactory_3cc367e4fd0607c1,
          mid_unconfigurableExecutorService_1f09f7e9e2d23baa,
          mid_unconfigurableScheduledExecutorService_b3a9540698eeb650,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit Executors(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        Executors(const Executors& obj) : ::java::lang::Object(obj) {}

        static ::java::util::concurrent::Callable callable(const ::java::lang::Runnable &);
        static ::java::util::concurrent::Callable callable(const ::java::lang::Runnable &, const ::java::lang::Object &);
        static ::java::util::concurrent::ThreadFactory defaultThreadFactory();
        static ::java::util::concurrent::ExecutorService newCachedThreadPool();
        static ::java::util::concurrent::ExecutorService newCachedThreadPool(const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ExecutorService newFixedThreadPool(jint);
        static ::java::util::concurrent::ExecutorService newFixedThreadPool(jint, const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ScheduledExecutorService newScheduledThreadPool(jint);
        static ::java::util::concurrent::ScheduledExecutorService newScheduledThreadPool(jint, const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ExecutorService newSingleThreadExecutor();
        static ::java::util::concurrent::ExecutorService newSingleThreadExecutor(const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ScheduledExecutorService newSingleThreadScheduledExecutor();
        static ::java::util::concurrent::ScheduledExecutorService newSingleThreadScheduledExecutor(const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ExecutorService newThreadPerTaskExecutor(const ::java::util::concurrent::ThreadFactory &);
        static ::java::util::concurrent::ExecutorService newVirtualThreadPerTaskExecutor();
        static ::java::util::concurrent::ExecutorService newWorkStealingPool();
        static ::java::util::concurrent::ExecutorService newWorkStealingPool(jint);
        static ::java::util::concurrent::Callable privilegedCallable(const ::java::util::concurrent::Callable &);
        static ::java::util::concurrent::Callable privilegedCallableUsingCurrentClassLoader(const ::java::util::concurrent::Callable &);
        static ::java::util::concurrent::ThreadFactory privilegedThreadFactory();
        static ::java::util::concurrent::ExecutorService unconfigurableExecutorService(const ::java::util::concurrent::ExecutorService &);
        static ::java::util::concurrent::ScheduledExecutorService unconfigurableScheduledExecutorService(const ::java::util::concurrent::ScheduledExecutorService &);
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace concurrent {
      extern PyType_Def PY_TYPE_DEF(Executors);
      extern PyTypeObject *PY_TYPE(Executors);

      class t_Executors {
      public:
        PyObject_HEAD
        Executors object;
        static PyObject *wrap_Object(const Executors&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
