#ifndef java_util_concurrent_ExecutorService_H
#define java_util_concurrent_ExecutorService_H

#include "java/util/concurrent/Executor.h"

namespace java {
  namespace lang {
    class AutoCloseable;
    class Class;
    class Object;
    class InterruptedException;
    class Runnable;
  }
  namespace util {
    class List;
    namespace concurrent {
      class Future;
      class ExecutionException;
      class TimeUnit;
      class TimeoutException;
      class Callable;
    }
    class Collection;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace concurrent {

      class ExecutorService : public ::java::util::concurrent::Executor {
       public:
        enum {
          mid_awaitTermination_b926844730e4bbc5,
          mid_close_a5783a25d44ba15b,
          mid_invokeAll_7025b738636d69d8,
          mid_invokeAll_3ae399661a717e4f,
          mid_invokeAny_1223ad28e6aa4bcd,
          mid_invokeAny_67e82565ac6d1b06,
          mid_isShutdown_201fceb6e9f1d0c5,
          mid_isTerminated_201fceb6e9f1d0c5,
          mid_shutdown_a5783a25d44ba15b,
          mid_shutdownNow_7b3206bb4e2462d2,
          mid_submit_da56e6d809fc0c72,
          mid_submit_71c76b32d51308c7,
          mid_submit_0caab88652797cf6,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit ExecutorService(jobject obj) : ::java::util::concurrent::Executor(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        ExecutorService(const ExecutorService& obj) : ::java::util::concurrent::Executor(obj) {}

        jboolean awaitTermination(jlong, const ::java::util::concurrent::TimeUnit &) const;
        void close() const;
        ::java::util::List invokeAll(const ::java::util::Collection &) const;
        ::java::util::List invokeAll(const ::java::util::Collection &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        ::java::lang::Object invokeAny(const ::java::util::Collection &) const;
        ::java::lang::Object invokeAny(const ::java::util::Collection &, jlong, const ::java::util::concurrent::TimeUnit &) const;
        jboolean isShutdown() const;
        jboolean isTerminated() const;
        void shutdown() const;
        ::java::util::List shutdownNow() const;
        ::java::util::concurrent::Future submit(const ::java::lang::Runnable &) const;
        ::java::util::concurrent::Future submit(const ::java::util::concurrent::Callable &) const;
        ::java::util::concurrent::Future submit(const ::java::lang::Runnable &, const ::java::lang::Object &) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace concurrent {
      extern PyType_Def PY_TYPE_DEF(ExecutorService);
      extern PyTypeObject *PY_TYPE(ExecutorService);

      class t_ExecutorService {
      public:
        PyObject_HEAD
        ExecutorService object;
        static PyObject *wrap_Object(const ExecutorService&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
