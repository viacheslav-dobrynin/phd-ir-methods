#ifndef java_util_regex_MatchResult_H
#define java_util_regex_MatchResult_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Integer;
    class Class;
  }
  namespace util {
    class Map;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace regex {

      class MatchResult : public ::java::lang::Object {
       public:
        enum {
          mid_end_f03edc6a210ac78c,
          mid_end_164529de03d21944,
          mid_end_ff66fe240ad72894,
          mid_group_cb1e3f35ce7b2bd1,
          mid_group_4fd613927a288526,
          mid_group_aebd86204175b724,
          mid_groupCount_f03edc6a210ac78c,
          mid_hasMatch_201fceb6e9f1d0c5,
          mid_namedGroups_2ccd91d439ff7d1f,
          mid_start_f03edc6a210ac78c,
          mid_start_164529de03d21944,
          mid_start_ff66fe240ad72894,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit MatchResult(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        MatchResult(const MatchResult& obj) : ::java::lang::Object(obj) {}

        jint end() const;
        jint end(const ::java::lang::String &) const;
        jint end(jint) const;
        ::java::lang::String group() const;
        ::java::lang::String group(const ::java::lang::String &) const;
        ::java::lang::String group(jint) const;
        jint groupCount() const;
        jboolean hasMatch() const;
        ::java::util::Map namedGroups() const;
        jint start() const;
        jint start(const ::java::lang::String &) const;
        jint start(jint) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace regex {
      extern PyType_Def PY_TYPE_DEF(MatchResult);
      extern PyTypeObject *PY_TYPE(MatchResult);

      class t_MatchResult {
      public:
        PyObject_HEAD
        MatchResult object;
        static PyObject *wrap_Object(const MatchResult&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
