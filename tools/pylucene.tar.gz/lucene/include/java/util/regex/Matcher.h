#ifndef java_util_regex_Matcher_H
#define java_util_regex_Matcher_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    namespace regex {
      class Pattern;
      class MatchResult;
      class Matcher;
    }
    class Map;
    namespace function {
      class Function;
    }
  }
  namespace lang {
    class Integer;
    class Class;
    class String;
    class CharSequence;
    class StringBuilder;
    class StringBuffer;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace regex {

      class Matcher : public ::java::lang::Object {
       public:
        enum {
          mid_appendReplacement_08d0e0022ac31392,
          mid_appendReplacement_fc99d53bb338273b,
          mid_appendTail_8c5af213ff271496,
          mid_appendTail_56ddeb2ab066e725,
          mid_end_f03edc6a210ac78c,
          mid_end_164529de03d21944,
          mid_end_ff66fe240ad72894,
          mid_find_201fceb6e9f1d0c5,
          mid_find_12fe561dd4de11f3,
          mid_group_cb1e3f35ce7b2bd1,
          mid_group_4fd613927a288526,
          mid_group_aebd86204175b724,
          mid_groupCount_f03edc6a210ac78c,
          mid_hasAnchoringBounds_201fceb6e9f1d0c5,
          mid_hasMatch_201fceb6e9f1d0c5,
          mid_hasTransparentBounds_201fceb6e9f1d0c5,
          mid_hitEnd_201fceb6e9f1d0c5,
          mid_lookingAt_201fceb6e9f1d0c5,
          mid_matches_201fceb6e9f1d0c5,
          mid_namedGroups_2ccd91d439ff7d1f,
          mid_pattern_7bc158ecd95d82c1,
          mid_quoteReplacement_4fd613927a288526,
          mid_region_b82064a0dd907ba2,
          mid_regionEnd_f03edc6a210ac78c,
          mid_regionStart_f03edc6a210ac78c,
          mid_replaceAll_4fd613927a288526,
          mid_replaceAll_53283b175aa25677,
          mid_replaceFirst_4fd613927a288526,
          mid_replaceFirst_53283b175aa25677,
          mid_requireEnd_201fceb6e9f1d0c5,
          mid_reset_07619fbd38579451,
          mid_reset_cf139c27fafaea13,
          mid_start_f03edc6a210ac78c,
          mid_start_164529de03d21944,
          mid_start_ff66fe240ad72894,
          mid_toMatchResult_af4be608a0f572f4,
          mid_toString_cb1e3f35ce7b2bd1,
          mid_useAnchoringBounds_5a90e22a65ade45d,
          mid_usePattern_5a87995d9edf9072,
          mid_useTransparentBounds_5a90e22a65ade45d,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit Matcher(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        Matcher(const Matcher& obj) : ::java::lang::Object(obj) {}

        Matcher appendReplacement(const ::java::lang::StringBuffer &, const ::java::lang::String &) const;
        Matcher appendReplacement(const ::java::lang::StringBuilder &, const ::java::lang::String &) const;
        ::java::lang::StringBuffer appendTail(const ::java::lang::StringBuffer &) const;
        ::java::lang::StringBuilder appendTail(const ::java::lang::StringBuilder &) const;
        jint end() const;
        jint end(const ::java::lang::String &) const;
        jint end(jint) const;
        jboolean find() const;
        jboolean find(jint) const;
        ::java::lang::String group() const;
        ::java::lang::String group(const ::java::lang::String &) const;
        ::java::lang::String group(jint) const;
        jint groupCount() const;
        jboolean hasAnchoringBounds() const;
        jboolean hasMatch() const;
        jboolean hasTransparentBounds() const;
        jboolean hitEnd() const;
        jboolean lookingAt() const;
        jboolean matches() const;
        ::java::util::Map namedGroups() const;
        ::java::util::regex::Pattern pattern() const;
        static ::java::lang::String quoteReplacement(const ::java::lang::String &);
        Matcher region(jint, jint) const;
        jint regionEnd() const;
        jint regionStart() const;
        ::java::lang::String replaceAll(const ::java::lang::String &) const;
        ::java::lang::String replaceAll(const ::java::util::function::Function &) const;
        ::java::lang::String replaceFirst(const ::java::lang::String &) const;
        ::java::lang::String replaceFirst(const ::java::util::function::Function &) const;
        jboolean requireEnd() const;
        Matcher reset() const;
        Matcher reset(const ::java::lang::CharSequence &) const;
        jint start() const;
        jint start(const ::java::lang::String &) const;
        jint start(jint) const;
        ::java::util::regex::MatchResult toMatchResult() const;
        ::java::lang::String toString() const;
        Matcher useAnchoringBounds(jboolean) const;
        Matcher usePattern(const ::java::util::regex::Pattern &) const;
        Matcher useTransparentBounds(jboolean) const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace regex {
      extern PyType_Def PY_TYPE_DEF(Matcher);
      extern PyTypeObject *PY_TYPE(Matcher);

      class t_Matcher {
      public:
        PyObject_HEAD
        Matcher object;
        static PyObject *wrap_Object(const Matcher&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
