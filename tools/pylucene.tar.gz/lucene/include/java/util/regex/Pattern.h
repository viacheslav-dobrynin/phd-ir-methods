#ifndef java_util_regex_Pattern_H
#define java_util_regex_Pattern_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    namespace regex {
      class Pattern;
      class Matcher;
    }
    class Map;
    namespace function {
      class Predicate;
    }
  }
  namespace lang {
    class Integer;
    class Class;
    class String;
    class CharSequence;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {
    namespace regex {

      class Pattern : public ::java::lang::Object {
       public:
        enum {
          mid_asMatchPredicate_6c4d7a24b7a27f32,
          mid_asPredicate_6c4d7a24b7a27f32,
          mid_compile_d3d2ae8f5d0763f5,
          mid_compile_9aad1fa236d9a0ee,
          mid_flags_f03edc6a210ac78c,
          mid_matcher_cf139c27fafaea13,
          mid_matches_769a292e1995188a,
          mid_namedGroups_2ccd91d439ff7d1f,
          mid_pattern_cb1e3f35ce7b2bd1,
          mid_quote_4fd613927a288526,
          mid_split_f6198f9d48577c5d,
          mid_split_ad1a4eb807e0b447,
          mid_splitWithDelimiters_ad1a4eb807e0b447,
          mid_toString_cb1e3f35ce7b2bd1,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit Pattern(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        Pattern(const Pattern& obj) : ::java::lang::Object(obj) {}

        static jint CANON_EQ;
        static jint CASE_INSENSITIVE;
        static jint COMMENTS;
        static jint DOTALL;
        static jint LITERAL;
        static jint MULTILINE;
        static jint UNICODE_CASE;
        static jint UNICODE_CHARACTER_CLASS;
        static jint UNIX_LINES;

        ::java::util::function::Predicate asMatchPredicate() const;
        ::java::util::function::Predicate asPredicate() const;
        static Pattern compile(const ::java::lang::String &);
        static Pattern compile(const ::java::lang::String &, jint);
        jint flags() const;
        ::java::util::regex::Matcher matcher(const ::java::lang::CharSequence &) const;
        static jboolean matches(const ::java::lang::String &, const ::java::lang::CharSequence &);
        ::java::util::Map namedGroups() const;
        ::java::lang::String pattern() const;
        static ::java::lang::String quote(const ::java::lang::String &);
        JArray< ::java::lang::String > split(const ::java::lang::CharSequence &) const;
        JArray< ::java::lang::String > split(const ::java::lang::CharSequence &, jint) const;
        JArray< ::java::lang::String > splitWithDelimiters(const ::java::lang::CharSequence &, jint) const;
        ::java::lang::String toString() const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace util {
    namespace regex {
      extern PyType_Def PY_TYPE_DEF(Pattern);
      extern PyTypeObject *PY_TYPE(Pattern);

      class t_Pattern {
      public:
        PyObject_HEAD
        Pattern object;
        static PyObject *wrap_Object(const Pattern&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
