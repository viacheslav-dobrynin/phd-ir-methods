#ifndef java_util_BitSet_H
#define java_util_BitSet_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Cloneable;
  }
  namespace util {
    class BitSet;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class BitSet : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_8730ba9dfaf23a7b,
        mid_and_205824f2f1175215,
        mid_andNot_205824f2f1175215,
        mid_cardinality_f03edc6a210ac78c,
        mid_clear_a5783a25d44ba15b,
        mid_clear_8730ba9dfaf23a7b,
        mid_clear_948d154349f29e30,
        mid_clone_1543ec1f1674e5aa,
        mid_equals_2a09f73f0549554f,
        mid_flip_8730ba9dfaf23a7b,
        mid_flip_948d154349f29e30,
        mid_get_12fe561dd4de11f3,
        mid_get_0eef7823fb3d43ec,
        mid_hashCode_f03edc6a210ac78c,
        mid_intersects_3ab8a650ab0fdba9,
        mid_isEmpty_201fceb6e9f1d0c5,
        mid_length_f03edc6a210ac78c,
        mid_nextClearBit_ff66fe240ad72894,
        mid_nextSetBit_ff66fe240ad72894,
        mid_or_205824f2f1175215,
        mid_previousClearBit_ff66fe240ad72894,
        mid_previousSetBit_ff66fe240ad72894,
        mid_set_8730ba9dfaf23a7b,
        mid_set_526f6be0903fb66a,
        mid_set_948d154349f29e30,
        mid_set_d51ac35697e9bb39,
        mid_size_f03edc6a210ac78c,
        mid_toByteArray_9d49388b39cc642b,
        mid_toLongArray_94cc44030d5a7c18,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_valueOf_801a7358b31ff52c,
        mid_valueOf_2f463e935a77d616,
        mid_xor_205824f2f1175215,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit BitSet(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      BitSet(const BitSet& obj) : ::java::lang::Object(obj) {}

      BitSet();
      BitSet(jint);

      void and$(const BitSet &) const;
      void andNot(const BitSet &) const;
      jint cardinality() const;
      void clear() const;
      void clear(jint) const;
      void clear(jint, jint) const;
      ::java::lang::Object clone() const;
      jboolean equals(const ::java::lang::Object &) const;
      void flip(jint) const;
      void flip(jint, jint) const;
      jboolean get(jint) const;
      BitSet get(jint, jint) const;
      jint hashCode() const;
      jboolean intersects(const BitSet &) const;
      jboolean isEmpty() const;
      jint length() const;
      jint nextClearBit(jint) const;
      jint nextSetBit(jint) const;
      void or$(const BitSet &) const;
      jint previousClearBit(jint) const;
      jint previousSetBit(jint) const;
      void set(jint) const;
      void set(jint, jboolean) const;
      void set(jint, jint) const;
      void set(jint, jint, jboolean) const;
      jint size() const;
      JArray< jbyte > toByteArray() const;
      JArray< jlong > toLongArray() const;
      ::java::lang::String toString() const;
      static BitSet valueOf(const JArray< jbyte > &);
      static BitSet valueOf(const JArray< jlong > &);
      void xor$(const BitSet &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(BitSet);
    extern PyTypeObject *PY_TYPE(BitSet);

    class t_BitSet {
    public:
      PyObject_HEAD
      BitSet object;
      static PyObject *wrap_Object(const BitSet&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
