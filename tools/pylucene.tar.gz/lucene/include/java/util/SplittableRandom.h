#ifndef java_util_SplittableRandom_H
#define java_util_SplittableRandom_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class SplittableRandom;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class SplittableRandom : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_270332bbfd4dc523,
        mid_nextBytes_5cb5ede3b794e9e0,
        mid_nextInt_f03edc6a210ac78c,
        mid_nextLong_d192af3db8896a5e,
        mid_split_88919299b3741498,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit SplittableRandom(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      SplittableRandom(const SplittableRandom& obj) : ::java::lang::Object(obj) {}

      SplittableRandom();
      SplittableRandom(jlong);

      void nextBytes(const JArray< jbyte > &) const;
      jint nextInt() const;
      jlong nextLong() const;
      SplittableRandom split() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(SplittableRandom);
    extern PyTypeObject *PY_TYPE(SplittableRandom);

    class t_SplittableRandom {
    public:
      PyObject_HEAD
      SplittableRandom object;
      static PyObject *wrap_Object(const SplittableRandom&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
