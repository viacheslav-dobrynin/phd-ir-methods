#ifndef java_util_ResourceBundle_H
#define java_util_ResourceBundle_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Module;
    class ClassLoader;
  }
  namespace util {
    class Set;
    class ResourceBundle;
    class Locale;
    class ResourceBundle$Control;
    class Enumeration;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class ResourceBundle : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_clearCache_a5783a25d44ba15b,
        mid_clearCache_e29185c148c81f19,
        mid_containsKey_7585662e3a5cb869,
        mid_getBaseBundleName_cb1e3f35ce7b2bd1,
        mid_getBundle_a6a86c6c3eac97e0,
        mid_getBundle_69bef8f739d595e7,
        mid_getBundle_ebc17098ce7a4451,
        mid_getBundle_9dee7c54eef2a0f7,
        mid_getBundle_d04e1d128f29817e,
        mid_getBundle_62693275b738cc6f,
        mid_getBundle_4fb11d9f5ce826db,
        mid_getBundle_02678b32df8c415d,
        mid_getKeys_1bd91a2eb94899f3,
        mid_getLocale_86b662b0d29267f6,
        mid_getObject_374166fc5538a93c,
        mid_getString_4fd613927a288526,
        mid_getStringArray_57dcd2e1ad8b9098,
        mid_keySet_9cfd5750b6ef4685,
        mid_handleGetObject_374166fc5538a93c,
        mid_handleKeySet_9cfd5750b6ef4685,
        mid_setParent_ba0386260523f0bc,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit ResourceBundle(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      ResourceBundle(const ResourceBundle& obj) : ::java::lang::Object(obj) {}

      ResourceBundle();

      static void clearCache();
      static void clearCache(const ::java::lang::ClassLoader &);
      jboolean containsKey(const ::java::lang::String &) const;
      ::java::lang::String getBaseBundleName() const;
      static ResourceBundle getBundle(const ::java::lang::String &);
      static ResourceBundle getBundle(const ::java::lang::String &, const ::java::lang::Module &);
      static ResourceBundle getBundle(const ::java::lang::String &, const ::java::util::Locale &);
      static ResourceBundle getBundle(const ::java::lang::String &, const ::java::util::ResourceBundle$Control &);
      static ResourceBundle getBundle(const ::java::lang::String &, const ::java::util::Locale &, const ::java::lang::ClassLoader &);
      static ResourceBundle getBundle(const ::java::lang::String &, const ::java::util::Locale &, const ::java::lang::Module &);
      static ResourceBundle getBundle(const ::java::lang::String &, const ::java::util::Locale &, const ::java::util::ResourceBundle$Control &);
      static ResourceBundle getBundle(const ::java::lang::String &, const ::java::util::Locale &, const ::java::lang::ClassLoader &, const ::java::util::ResourceBundle$Control &);
      ::java::util::Enumeration getKeys() const;
      ::java::util::Locale getLocale() const;
      ::java::lang::Object getObject(const ::java::lang::String &) const;
      ::java::lang::String getString(const ::java::lang::String &) const;
      JArray< ::java::lang::String > getStringArray(const ::java::lang::String &) const;
      ::java::util::Set keySet() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(ResourceBundle);
    extern PyTypeObject *PY_TYPE(ResourceBundle);

    class t_ResourceBundle {
    public:
      PyObject_HEAD
      ResourceBundle object;
      static PyObject *wrap_Object(const ResourceBundle&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
