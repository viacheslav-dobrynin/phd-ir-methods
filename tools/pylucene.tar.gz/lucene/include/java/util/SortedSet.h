#ifndef java_util_SortedSet_H
#define java_util_SortedSet_H

#include "java/util/Set.h"

namespace java {
  namespace util {
    class Comparator;
    class SequencedSet;
    class Spliterator;
    class SortedSet;
  }
  namespace lang {
    class Class;
    class Object;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class SortedSet : public ::java::util::Set {
     public:
      enum {
        mid_addFirst_e391a919b9e60fbb,
        mid_addLast_e391a919b9e60fbb,
        mid_comparator_54213bfa5c9a50fd,
        mid_first_1543ec1f1674e5aa,
        mid_getFirst_1543ec1f1674e5aa,
        mid_getLast_1543ec1f1674e5aa,
        mid_headSet_3bd98ba6497a3e28,
        mid_last_1543ec1f1674e5aa,
        mid_removeFirst_1543ec1f1674e5aa,
        mid_removeLast_1543ec1f1674e5aa,
        mid_reversed_cd6da693b1fe6439,
        mid_spliterator_c756d372a23560d4,
        mid_subSet_3c28cd24d702000a,
        mid_tailSet_3bd98ba6497a3e28,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit SortedSet(jobject obj) : ::java::util::Set(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      SortedSet(const SortedSet& obj) : ::java::util::Set(obj) {}

      void addFirst(const ::java::lang::Object &) const;
      void addLast(const ::java::lang::Object &) const;
      ::java::util::Comparator comparator() const;
      ::java::lang::Object first() const;
      ::java::lang::Object getFirst() const;
      ::java::lang::Object getLast() const;
      SortedSet headSet(const ::java::lang::Object &) const;
      ::java::lang::Object last() const;
      ::java::lang::Object removeFirst() const;
      ::java::lang::Object removeLast() const;
      SortedSet reversed() const;
      ::java::util::Spliterator spliterator() const;
      SortedSet subSet(const ::java::lang::Object &, const ::java::lang::Object &) const;
      SortedSet tailSet(const ::java::lang::Object &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(SortedSet);
    extern PyTypeObject *PY_TYPE(SortedSet);

    class t_SortedSet {
    public:
      PyObject_HEAD
      SortedSet object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_SortedSet *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const SortedSet&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const SortedSet&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
