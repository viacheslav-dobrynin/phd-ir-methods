#ifndef java_util_List_H
#define java_util_List_H

#include "java/util/SequencedCollection.h"

namespace java {
  namespace util {
    class Iterator;
    class Comparator;
    class ListIterator;
    class List;
    class Spliterator;
    namespace function {
      class UnaryOperator;
    }
    class Collection;
  }
  namespace lang {
    class Class;
    class Object;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class List : public ::java::util::SequencedCollection {
     public:
      enum {
        mid_add_2a09f73f0549554f,
        mid_add_5f2f5470fb8f6a0b,
        mid_addAll_7b89e2617455757c,
        mid_addAll_c75ddfad5d6428a2,
        mid_addFirst_e391a919b9e60fbb,
        mid_addLast_e391a919b9e60fbb,
        mid_clear_a5783a25d44ba15b,
        mid_contains_2a09f73f0549554f,
        mid_containsAll_7b89e2617455757c,
        mid_copyOf_7025b738636d69d8,
        mid_equals_2a09f73f0549554f,
        mid_get_1dce87679d904d14,
        mid_getFirst_1543ec1f1674e5aa,
        mid_getLast_1543ec1f1674e5aa,
        mid_hashCode_f03edc6a210ac78c,
        mid_indexOf_8734b42132ce8667,
        mid_isEmpty_201fceb6e9f1d0c5,
        mid_iterator_d58ed5f479280ab0,
        mid_lastIndexOf_8734b42132ce8667,
        mid_listIterator_e0a22399b6bb4af6,
        mid_listIterator_34439590583a9dad,
        mid_of_7b3206bb4e2462d2,
        mid_of_692a4c70d12ba53e,
        mid_of_f4673ac0597255b6,
        mid_of_7887ad2e3c490c97,
        mid_of_a09b16bc3fa32020,
        mid_of_d88c4ff06f6ee55c,
        mid_of_40628b4eb0b16429,
        mid_of_97cb2aba6087ce91,
        mid_of_626fa36debefa892,
        mid_of_319a825eb891a00a,
        mid_of_0c30f9744bf896be,
        mid_of_33b3cd041183ad7c,
        mid_remove_1dce87679d904d14,
        mid_remove_2a09f73f0549554f,
        mid_removeAll_7b89e2617455757c,
        mid_removeFirst_1543ec1f1674e5aa,
        mid_removeLast_1543ec1f1674e5aa,
        mid_replaceAll_d7a63356b46dde60,
        mid_retainAll_7b89e2617455757c,
        mid_reversed_7b3206bb4e2462d2,
        mid_set_2988283091a6a258,
        mid_size_f03edc6a210ac78c,
        mid_sort_20660e9f142d010d,
        mid_spliterator_c756d372a23560d4,
        mid_subList_0f33e52d73579509,
        mid_toArray_14b9ca3d477d4e16,
        mid_toArray_f23ec43bdb29bb2e,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit List(jobject obj) : ::java::util::SequencedCollection(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      List(const List& obj) : ::java::util::SequencedCollection(obj) {}

      jboolean add(const ::java::lang::Object &) const;
      void add(jint, const ::java::lang::Object &) const;
      jboolean addAll(const ::java::util::Collection &) const;
      jboolean addAll(jint, const ::java::util::Collection &) const;
      void addFirst(const ::java::lang::Object &) const;
      void addLast(const ::java::lang::Object &) const;
      void clear() const;
      jboolean contains(const ::java::lang::Object &) const;
      jboolean containsAll(const ::java::util::Collection &) const;
      static List copyOf(const ::java::util::Collection &);
      jboolean equals(const ::java::lang::Object &) const;
      ::java::lang::Object get(jint) const;
      ::java::lang::Object getFirst() const;
      ::java::lang::Object getLast() const;
      jint hashCode() const;
      jint indexOf(const ::java::lang::Object &) const;
      jboolean isEmpty() const;
      ::java::util::Iterator iterator() const;
      jint lastIndexOf(const ::java::lang::Object &) const;
      ::java::util::ListIterator listIterator() const;
      ::java::util::ListIterator listIterator(jint) const;
      static List of();
      static List of(const JArray< ::java::lang::Object > &);
      static List of(const ::java::lang::Object &);
      static List of(const ::java::lang::Object &, const ::java::lang::Object &);
      static List of(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &);
      static List of(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &);
      static List of(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &);
      static List of(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &);
      static List of(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &);
      static List of(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &);
      static List of(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &);
      static List of(const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &, const ::java::lang::Object &);
      ::java::lang::Object remove(jint) const;
      jboolean remove(const ::java::lang::Object &) const;
      jboolean removeAll(const ::java::util::Collection &) const;
      ::java::lang::Object removeFirst() const;
      ::java::lang::Object removeLast() const;
      void replaceAll(const ::java::util::function::UnaryOperator &) const;
      jboolean retainAll(const ::java::util::Collection &) const;
      List reversed() const;
      ::java::lang::Object set(jint, const ::java::lang::Object &) const;
      jint size() const;
      void sort(const ::java::util::Comparator &) const;
      ::java::util::Spliterator spliterator() const;
      List subList(jint, jint) const;
      JArray< ::java::lang::Object > toArray() const;
      JArray< ::java::lang::Object > toArray(const JArray< ::java::lang::Object > &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(List);
    extern PyTypeObject *PY_TYPE(List);

    class t_List {
    public:
      PyObject_HEAD
      List object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_List *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const List&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const List&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
