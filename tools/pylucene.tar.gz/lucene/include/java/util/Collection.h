#ifndef java_util_Collection_H
#define java_util_Collection_H

#include "java/lang/Iterable.h"

namespace java {
  namespace util {
    class Iterator;
    class Spliterator;
    namespace function {
      class IntFunction;
      class Predicate;
    }
    class Collection;
  }
  namespace lang {
    class Class;
    class Object;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class Collection : public ::java::lang::Iterable {
     public:
      enum {
        mid_add_2a09f73f0549554f,
        mid_addAll_7b89e2617455757c,
        mid_clear_a5783a25d44ba15b,
        mid_contains_2a09f73f0549554f,
        mid_containsAll_7b89e2617455757c,
        mid_equals_2a09f73f0549554f,
        mid_hashCode_f03edc6a210ac78c,
        mid_isEmpty_201fceb6e9f1d0c5,
        mid_iterator_d58ed5f479280ab0,
        mid_remove_2a09f73f0549554f,
        mid_removeAll_7b89e2617455757c,
        mid_removeIf_bc38e7d3fcf17e8f,
        mid_retainAll_7b89e2617455757c,
        mid_size_f03edc6a210ac78c,
        mid_spliterator_c756d372a23560d4,
        mid_toArray_14b9ca3d477d4e16,
        mid_toArray_f23ec43bdb29bb2e,
        mid_toArray_de43c2638a3ee412,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Collection(jobject obj) : ::java::lang::Iterable(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Collection(const Collection& obj) : ::java::lang::Iterable(obj) {}

      jboolean add(const ::java::lang::Object &) const;
      jboolean addAll(const Collection &) const;
      void clear() const;
      jboolean contains(const ::java::lang::Object &) const;
      jboolean containsAll(const Collection &) const;
      jboolean equals(const ::java::lang::Object &) const;
      jint hashCode() const;
      jboolean isEmpty() const;
      ::java::util::Iterator iterator() const;
      jboolean remove(const ::java::lang::Object &) const;
      jboolean removeAll(const Collection &) const;
      jboolean removeIf(const ::java::util::function::Predicate &) const;
      jboolean retainAll(const Collection &) const;
      jint size() const;
      ::java::util::Spliterator spliterator() const;
      JArray< ::java::lang::Object > toArray() const;
      JArray< ::java::lang::Object > toArray(const JArray< ::java::lang::Object > &) const;
      JArray< ::java::lang::Object > toArray(const ::java::util::function::IntFunction &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(Collection);
    extern PyTypeObject *PY_TYPE(Collection);

    class t_Collection {
    public:
      PyObject_HEAD
      Collection object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_Collection *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const Collection&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const Collection&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
