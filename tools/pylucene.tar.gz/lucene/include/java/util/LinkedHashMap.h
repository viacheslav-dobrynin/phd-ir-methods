#ifndef java_util_LinkedHashMap_H
#define java_util_LinkedHashMap_H

#include "java/util/HashMap.h"

namespace java {
  namespace util {
    class SequencedSet;
    class Map$Entry;
    class SequencedCollection;
    class Map;
    namespace function {
      class BiFunction;
      class BiConsumer;
    }
    class Set;
    class LinkedHashMap;
    class Collection;
    class SequencedMap;
  }
  namespace lang {
    class Class;
    class Object;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class LinkedHashMap : public ::java::util::HashMap {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_8730ba9dfaf23a7b,
        mid_init$_5063440bb525b708,
        mid_init$_5e4d51bf720efbb5,
        mid_init$_472ea6777ae07d21,
        mid_clear_a5783a25d44ba15b,
        mid_containsValue_2a09f73f0549554f,
        mid_entrySet_9cfd5750b6ef4685,
        mid_forEach_9615eed198547dc3,
        mid_get_c5b181c227f736f1,
        mid_getOrDefault_c36cd8daf720e2b9,
        mid_keySet_9cfd5750b6ef4685,
        mid_newLinkedHashMap_76f71875d7912488,
        mid_putFirst_c36cd8daf720e2b9,
        mid_putLast_c36cd8daf720e2b9,
        mid_replaceAll_93e4227d3cd455ac,
        mid_reversed_055ed0809ec94d0a,
        mid_sequencedEntrySet_405a53aa5b5364ff,
        mid_sequencedKeySet_405a53aa5b5364ff,
        mid_sequencedValues_8fb3aa8e33618cad,
        mid_values_7ff6744e4f3958ed,
        mid_removeEldestEntry_9db2eae72975de95,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit LinkedHashMap(jobject obj) : ::java::util::HashMap(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      LinkedHashMap(const LinkedHashMap& obj) : ::java::util::HashMap(obj) {}

      LinkedHashMap();
      LinkedHashMap(jint);
      LinkedHashMap(const ::java::util::Map &);
      LinkedHashMap(jint, jfloat);
      LinkedHashMap(jint, jfloat, jboolean);

      void clear() const;
      jboolean containsValue(const ::java::lang::Object &) const;
      ::java::util::Set entrySet() const;
      void forEach(const ::java::util::function::BiConsumer &) const;
      ::java::lang::Object get(const ::java::lang::Object &) const;
      ::java::lang::Object getOrDefault(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::util::Set keySet() const;
      static LinkedHashMap newLinkedHashMap(jint);
      ::java::lang::Object putFirst(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::lang::Object putLast(const ::java::lang::Object &, const ::java::lang::Object &) const;
      void replaceAll(const ::java::util::function::BiFunction &) const;
      ::java::util::SequencedMap reversed() const;
      ::java::util::SequencedSet sequencedEntrySet() const;
      ::java::util::SequencedSet sequencedKeySet() const;
      ::java::util::SequencedCollection sequencedValues() const;
      ::java::util::Collection values() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(LinkedHashMap);
    extern PyTypeObject *PY_TYPE(LinkedHashMap);

    class t_LinkedHashMap {
    public:
      PyObject_HEAD
      LinkedHashMap object;
      PyTypeObject *parameters[2];
      static PyTypeObject **parameters_(t_LinkedHashMap *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const LinkedHashMap&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const LinkedHashMap&, PyTypeObject *, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
