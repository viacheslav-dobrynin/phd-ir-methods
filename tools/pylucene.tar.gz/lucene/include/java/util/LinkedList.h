#ifndef java_util_LinkedList_H
#define java_util_LinkedList_H

#include "java/util/AbstractSequentialList.h"

namespace java {
  namespace util {
    class Iterator;
    class ListIterator;
    class Spliterator;
    class Deque;
    class Collection;
    class LinkedList;
  }
  namespace lang {
    class Class;
    class Cloneable;
    class Object;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class LinkedList : public ::java::util::AbstractSequentialList {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_6225acc290c4d266,
        mid_add_2a09f73f0549554f,
        mid_add_5f2f5470fb8f6a0b,
        mid_addAll_7b89e2617455757c,
        mid_addAll_c75ddfad5d6428a2,
        mid_addFirst_e391a919b9e60fbb,
        mid_addLast_e391a919b9e60fbb,
        mid_clear_a5783a25d44ba15b,
        mid_clone_1543ec1f1674e5aa,
        mid_contains_2a09f73f0549554f,
        mid_descendingIterator_d58ed5f479280ab0,
        mid_element_1543ec1f1674e5aa,
        mid_get_1dce87679d904d14,
        mid_getFirst_1543ec1f1674e5aa,
        mid_getLast_1543ec1f1674e5aa,
        mid_indexOf_8734b42132ce8667,
        mid_lastIndexOf_8734b42132ce8667,
        mid_listIterator_34439590583a9dad,
        mid_offer_2a09f73f0549554f,
        mid_offerFirst_2a09f73f0549554f,
        mid_offerLast_2a09f73f0549554f,
        mid_peek_1543ec1f1674e5aa,
        mid_peekFirst_1543ec1f1674e5aa,
        mid_peekLast_1543ec1f1674e5aa,
        mid_poll_1543ec1f1674e5aa,
        mid_pollFirst_1543ec1f1674e5aa,
        mid_pollLast_1543ec1f1674e5aa,
        mid_pop_1543ec1f1674e5aa,
        mid_push_e391a919b9e60fbb,
        mid_remove_1543ec1f1674e5aa,
        mid_remove_1dce87679d904d14,
        mid_remove_2a09f73f0549554f,
        mid_removeFirst_1543ec1f1674e5aa,
        mid_removeFirstOccurrence_2a09f73f0549554f,
        mid_removeLast_1543ec1f1674e5aa,
        mid_removeLastOccurrence_2a09f73f0549554f,
        mid_reversed_43175cf408a3dea1,
        mid_set_2988283091a6a258,
        mid_size_f03edc6a210ac78c,
        mid_spliterator_c756d372a23560d4,
        mid_toArray_14b9ca3d477d4e16,
        mid_toArray_f23ec43bdb29bb2e,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit LinkedList(jobject obj) : ::java::util::AbstractSequentialList(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      LinkedList(const LinkedList& obj) : ::java::util::AbstractSequentialList(obj) {}

      LinkedList();
      LinkedList(const ::java::util::Collection &);

      jboolean add(const ::java::lang::Object &) const;
      void add(jint, const ::java::lang::Object &) const;
      jboolean addAll(const ::java::util::Collection &) const;
      jboolean addAll(jint, const ::java::util::Collection &) const;
      void addFirst(const ::java::lang::Object &) const;
      void addLast(const ::java::lang::Object &) const;
      void clear() const;
      ::java::lang::Object clone() const;
      jboolean contains(const ::java::lang::Object &) const;
      ::java::util::Iterator descendingIterator() const;
      ::java::lang::Object element() const;
      ::java::lang::Object get(jint) const;
      ::java::lang::Object getFirst() const;
      ::java::lang::Object getLast() const;
      jint indexOf(const ::java::lang::Object &) const;
      jint lastIndexOf(const ::java::lang::Object &) const;
      ::java::util::ListIterator listIterator(jint) const;
      jboolean offer(const ::java::lang::Object &) const;
      jboolean offerFirst(const ::java::lang::Object &) const;
      jboolean offerLast(const ::java::lang::Object &) const;
      ::java::lang::Object peek() const;
      ::java::lang::Object peekFirst() const;
      ::java::lang::Object peekLast() const;
      ::java::lang::Object poll() const;
      ::java::lang::Object pollFirst() const;
      ::java::lang::Object pollLast() const;
      ::java::lang::Object pop() const;
      void push(const ::java::lang::Object &) const;
      ::java::lang::Object remove() const;
      ::java::lang::Object remove(jint) const;
      jboolean remove(const ::java::lang::Object &) const;
      ::java::lang::Object removeFirst() const;
      jboolean removeFirstOccurrence(const ::java::lang::Object &) const;
      ::java::lang::Object removeLast() const;
      jboolean removeLastOccurrence(const ::java::lang::Object &) const;
      LinkedList reversed() const;
      ::java::lang::Object set(jint, const ::java::lang::Object &) const;
      jint size() const;
      ::java::util::Spliterator spliterator() const;
      JArray< ::java::lang::Object > toArray() const;
      JArray< ::java::lang::Object > toArray(const JArray< ::java::lang::Object > &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(LinkedList);
    extern PyTypeObject *PY_TYPE(LinkedList);

    class t_LinkedList {
    public:
      PyObject_HEAD
      LinkedList object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_LinkedList *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const LinkedList&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const LinkedList&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
