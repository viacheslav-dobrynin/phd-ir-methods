#ifndef java_util_Optional_H
#define java_util_Optional_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    namespace function {
      class Supplier;
      class Consumer;
      class Predicate;
      class Function;
    }
    class Optional;
  }
  namespace lang {
    class Class;
    class String;
    class Throwable;
    class Runnable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class Optional : public ::java::lang::Object {
     public:
      enum {
        mid_empty_5dfa6fdc4ec946c6,
        mid_equals_2a09f73f0549554f,
        mid_filter_cf45486f37cdd8bf,
        mid_flatMap_e44a44e04d5005b8,
        mid_get_1543ec1f1674e5aa,
        mid_hashCode_f03edc6a210ac78c,
        mid_ifPresent_857c265f607ccaa6,
        mid_ifPresentOrElse_0baa540be2eed9ca,
        mid_isEmpty_201fceb6e9f1d0c5,
        mid_isPresent_201fceb6e9f1d0c5,
        mid_map_e44a44e04d5005b8,
        mid_of_8169c5a41bf1daef,
        mid_ofNullable_8169c5a41bf1daef,
        mid_or_813c219083e94124,
        mid_orElse_c5b181c227f736f1,
        mid_orElseGet_a231a6f0ac28b5ab,
        mid_orElseThrow_1543ec1f1674e5aa,
        mid_orElseThrow_a231a6f0ac28b5ab,
        mid_toString_cb1e3f35ce7b2bd1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Optional(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Optional(const Optional& obj) : ::java::lang::Object(obj) {}

      static Optional empty();
      jboolean equals(const ::java::lang::Object &) const;
      Optional filter(const ::java::util::function::Predicate &) const;
      Optional flatMap(const ::java::util::function::Function &) const;
      ::java::lang::Object get() const;
      jint hashCode() const;
      void ifPresent(const ::java::util::function::Consumer &) const;
      void ifPresentOrElse(const ::java::util::function::Consumer &, const ::java::lang::Runnable &) const;
      jboolean isEmpty() const;
      jboolean isPresent() const;
      Optional map(const ::java::util::function::Function &) const;
      static Optional of(const ::java::lang::Object &);
      static Optional ofNullable(const ::java::lang::Object &);
      Optional or$(const ::java::util::function::Supplier &) const;
      ::java::lang::Object orElse(const ::java::lang::Object &) const;
      ::java::lang::Object orElseGet(const ::java::util::function::Supplier &) const;
      ::java::lang::Object orElseThrow() const;
      ::java::lang::Object orElseThrow(const ::java::util::function::Supplier &) const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(Optional);
    extern PyTypeObject *PY_TYPE(Optional);

    class t_Optional {
    public:
      PyObject_HEAD
      Optional object;
      PyTypeObject *parameters[1];
      static PyTypeObject **parameters_(t_Optional *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const Optional&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const Optional&, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
