#ifndef java_util_Locale_H
#define java_util_Locale_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Locale$LanguageRange;
    class List;
    class Locale$Category;
    class Set;
    class Collection;
    class Locale;
    class Locale$IsoCountryCode;
    class MissingResourceException;
    class Locale$FilteringMode;
  }
  namespace lang {
    class Class;
    class String;
    class Cloneable;
    class Character;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class Locale : public ::java::lang::Object {
     public:
      enum {
        mid_init$_9b22ecdee06ea23c,
        mid_init$_56d5ffc79e73287a,
        mid_init$_ee1bb2629f545aa4,
        mid_caseFoldLanguageTag_4fd613927a288526,
        mid_clone_1543ec1f1674e5aa,
        mid_equals_2a09f73f0549554f,
        mid_filter_e4d224bbfef89695,
        mid_filter_948cdb751d3d84bf,
        mid_filterTags_e4d224bbfef89695,
        mid_filterTags_948cdb751d3d84bf,
        mid_forLanguageTag_508d182159761ab5,
        mid_getAvailableLocales_731cc618dad45867,
        mid_getCountry_cb1e3f35ce7b2bd1,
        mid_getDefault_86b662b0d29267f6,
        mid_getDefault_84e43fde588302fa,
        mid_getDisplayCountry_cb1e3f35ce7b2bd1,
        mid_getDisplayCountry_e3e73dfada614e4b,
        mid_getDisplayLanguage_cb1e3f35ce7b2bd1,
        mid_getDisplayLanguage_e3e73dfada614e4b,
        mid_getDisplayName_cb1e3f35ce7b2bd1,
        mid_getDisplayName_e3e73dfada614e4b,
        mid_getDisplayScript_cb1e3f35ce7b2bd1,
        mid_getDisplayScript_e3e73dfada614e4b,
        mid_getDisplayVariant_cb1e3f35ce7b2bd1,
        mid_getDisplayVariant_e3e73dfada614e4b,
        mid_getExtension_82edd1789d1cc009,
        mid_getExtensionKeys_9cfd5750b6ef4685,
        mid_getISO3Country_cb1e3f35ce7b2bd1,
        mid_getISO3Language_cb1e3f35ce7b2bd1,
        mid_getISOCountries_c0724ba8b8f42824,
        mid_getISOCountries_8ac0d3848e1782a4,
        mid_getISOLanguages_c0724ba8b8f42824,
        mid_getLanguage_cb1e3f35ce7b2bd1,
        mid_getScript_cb1e3f35ce7b2bd1,
        mid_getUnicodeLocaleAttributes_9cfd5750b6ef4685,
        mid_getUnicodeLocaleKeys_9cfd5750b6ef4685,
        mid_getUnicodeLocaleType_4fd613927a288526,
        mid_getVariant_cb1e3f35ce7b2bd1,
        mid_hasExtensions_201fceb6e9f1d0c5,
        mid_hashCode_f03edc6a210ac78c,
        mid_lookup_ed307ebda6971455,
        mid_lookupTag_246ed5a1c5088ada,
        mid_of_508d182159761ab5,
        mid_of_d28a9ce417b73111,
        mid_of_99ede1014c5a3ddc,
        mid_setDefault_1203e9be326b53f3,
        mid_setDefault_da84ce4285753017,
        mid_stripExtensions_86b662b0d29267f6,
        mid_toLanguageTag_cb1e3f35ce7b2bd1,
        mid_toString_cb1e3f35ce7b2bd1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Locale(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Locale(const Locale& obj) : ::java::lang::Object(obj) {}

      static Locale *CANADA;
      static Locale *CANADA_FRENCH;
      static Locale *CHINA;
      static Locale *CHINESE;
      static Locale *ENGLISH;
      static Locale *FRANCE;
      static Locale *FRENCH;
      static Locale *GERMAN;
      static Locale *GERMANY;
      static Locale *ITALIAN;
      static Locale *ITALY;
      static Locale *JAPAN;
      static Locale *JAPANESE;
      static Locale *KOREA;
      static Locale *KOREAN;
      static Locale *PRC;
      static jchar PRIVATE_USE_EXTENSION;
      static Locale *ROOT;
      static Locale *SIMPLIFIED_CHINESE;
      static Locale *TAIWAN;
      static Locale *TRADITIONAL_CHINESE;
      static Locale *UK;
      static jchar UNICODE_LOCALE_EXTENSION;
      static Locale *US;

      Locale(const ::java::lang::String &);
      Locale(const ::java::lang::String &, const ::java::lang::String &);
      Locale(const ::java::lang::String &, const ::java::lang::String &, const ::java::lang::String &);

      static ::java::lang::String caseFoldLanguageTag(const ::java::lang::String &);
      ::java::lang::Object clone() const;
      jboolean equals(const ::java::lang::Object &) const;
      static ::java::util::List filter(const ::java::util::List &, const ::java::util::Collection &);
      static ::java::util::List filter(const ::java::util::List &, const ::java::util::Collection &, const ::java::util::Locale$FilteringMode &);
      static ::java::util::List filterTags(const ::java::util::List &, const ::java::util::Collection &);
      static ::java::util::List filterTags(const ::java::util::List &, const ::java::util::Collection &, const ::java::util::Locale$FilteringMode &);
      static Locale forLanguageTag(const ::java::lang::String &);
      static JArray< Locale > getAvailableLocales();
      ::java::lang::String getCountry() const;
      static Locale getDefault();
      static Locale getDefault(const ::java::util::Locale$Category &);
      ::java::lang::String getDisplayCountry() const;
      ::java::lang::String getDisplayCountry(const Locale &) const;
      ::java::lang::String getDisplayLanguage() const;
      ::java::lang::String getDisplayLanguage(const Locale &) const;
      ::java::lang::String getDisplayName() const;
      ::java::lang::String getDisplayName(const Locale &) const;
      ::java::lang::String getDisplayScript() const;
      ::java::lang::String getDisplayScript(const Locale &) const;
      ::java::lang::String getDisplayVariant() const;
      ::java::lang::String getDisplayVariant(const Locale &) const;
      ::java::lang::String getExtension(jchar) const;
      ::java::util::Set getExtensionKeys() const;
      ::java::lang::String getISO3Country() const;
      ::java::lang::String getISO3Language() const;
      static JArray< ::java::lang::String > getISOCountries();
      static ::java::util::Set getISOCountries(const ::java::util::Locale$IsoCountryCode &);
      static JArray< ::java::lang::String > getISOLanguages();
      ::java::lang::String getLanguage() const;
      ::java::lang::String getScript() const;
      ::java::util::Set getUnicodeLocaleAttributes() const;
      ::java::util::Set getUnicodeLocaleKeys() const;
      ::java::lang::String getUnicodeLocaleType(const ::java::lang::String &) const;
      ::java::lang::String getVariant() const;
      jboolean hasExtensions() const;
      jint hashCode() const;
      static Locale lookup(const ::java::util::List &, const ::java::util::Collection &);
      static ::java::lang::String lookupTag(const ::java::util::List &, const ::java::util::Collection &);
      static Locale of(const ::java::lang::String &);
      static Locale of(const ::java::lang::String &, const ::java::lang::String &);
      static Locale of(const ::java::lang::String &, const ::java::lang::String &, const ::java::lang::String &);
      static void setDefault(const Locale &);
      static void setDefault(const ::java::util::Locale$Category &, const Locale &);
      Locale stripExtensions() const;
      ::java::lang::String toLanguageTag() const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(Locale);
    extern PyTypeObject *PY_TYPE(Locale);

    class t_Locale {
    public:
      PyObject_HEAD
      Locale object;
      static PyObject *wrap_Object(const Locale&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
