#ifndef java_util_Arrays_H
#define java_util_Arrays_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Comparator;
    class Spliterator$OfInt;
    class Spliterator$OfDouble;
    class List;
    namespace function {
      class IntToDoubleFunction;
      class LongBinaryOperator;
      class IntToLongFunction;
      class IntFunction;
      class IntUnaryOperator;
      class BinaryOperator;
      class DoubleBinaryOperator;
      class IntBinaryOperator;
    }
    class Spliterator;
    class Spliterator$OfLong;
  }
  namespace lang {
    class Comparable;
    class Class;
    class String;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class Arrays : public ::java::lang::Object {
     public:
      enum {
        mid_asList_692a4c70d12ba53e,
        mid_binarySearch_45fac5c1118d0f89,
        mid_binarySearch_ee38d084aac45d47,
        mid_binarySearch_b5a6cd3ca655e7d6,
        mid_binarySearch_1144c7e8afda6300,
        mid_binarySearch_8d355b2a7f36208f,
        mid_binarySearch_9487be57928f313a,
        mid_binarySearch_cc5700750da356df,
        mid_binarySearch_c7d09843f9883064,
        mid_binarySearch_dac9e24960d58d3a,
        mid_binarySearch_57192cfa3e11e211,
        mid_binarySearch_c7d79297c4fd47aa,
        mid_binarySearch_61ff9337e6c6d3c7,
        mid_binarySearch_a853e8e4f78253fb,
        mid_binarySearch_2df43fe5a9c14e82,
        mid_binarySearch_cc1f3ebe1388950d,
        mid_binarySearch_53b37a0fcc2f7bc7,
        mid_binarySearch_8833e8fe75102b08,
        mid_binarySearch_e89578ecd6a16b18,
        mid_compare_5dc8722edf2b8e1c,
        mid_compare_aba69519f903fadd,
        mid_compare_becae87b27419c8f,
        mid_compare_4af42dce0c97cffa,
        mid_compare_a7a566ddbd4db145,
        mid_compare_19ffd1fc40a342fd,
        mid_compare_92fe5a4a8f7ae6a1,
        mid_compare_a9e8e8cd26e703e5,
        mid_compare_5318b70968347149,
        mid_compare_dd82f7cdcd7083bc,
        mid_compare_cd29fb7adfa455bf,
        mid_compare_d61802d3b57b90e2,
        mid_compare_9f9535170b73adea,
        mid_compare_03628000c84c8ee8,
        mid_compare_aa90580a026b2fa9,
        mid_compare_a31204272eb18fd0,
        mid_compare_68100b1f8f027d5f,
        mid_compare_8b91e77650d20061,
        mid_compare_6929c9f853094719,
        mid_compare_e251a83ac1d87cc3,
        mid_compareUnsigned_5dc8722edf2b8e1c,
        mid_compareUnsigned_a7a566ddbd4db145,
        mid_compareUnsigned_19ffd1fc40a342fd,
        mid_compareUnsigned_a9e8e8cd26e703e5,
        mid_compareUnsigned_cd29fb7adfa455bf,
        mid_compareUnsigned_aa90580a026b2fa9,
        mid_compareUnsigned_a31204272eb18fd0,
        mid_compareUnsigned_8b91e77650d20061,
        mid_copyOf_dda9c69a31e3ef67,
        mid_copyOf_ee06fbce0a61c630,
        mid_copyOf_9413c5e21782fab0,
        mid_copyOf_712e0efe7c4c3c4b,
        mid_copyOf_21870e3592dabd4b,
        mid_copyOf_ea0b14bc177181a4,
        mid_copyOf_ba524946e55a02c8,
        mid_copyOf_178eb8e7cad2dbe5,
        mid_copyOf_d7d15d715be947a3,
        mid_copyOf_6fe3ed81fa1f3822,
        mid_copyOfRange_43f1c1c2c3c19252,
        mid_copyOfRange_be045d6d36a921c1,
        mid_copyOfRange_46901a8fb92cf43e,
        mid_copyOfRange_5f4b08b1350f29b8,
        mid_copyOfRange_83e78024cfdae592,
        mid_copyOfRange_c65f71301ff37aa0,
        mid_copyOfRange_7233d0164e6a8933,
        mid_copyOfRange_edbdca36afe45b07,
        mid_copyOfRange_89cd78a8fb28e309,
        mid_copyOfRange_e2b1d1fc62f647a7,
        mid_deepEquals_c31738200fa2f836,
        mid_deepHashCode_eee4c1885e66ba78,
        mid_deepToString_fd086fa2107bd22c,
        mid_equals_0bf406232d174066,
        mid_equals_5cfc3c89f8812807,
        mid_equals_7aeddcc87d955d25,
        mid_equals_ac962fdeea8a41db,
        mid_equals_f1dc1918d53a9f37,
        mid_equals_6bb9c60ffff93342,
        mid_equals_c31738200fa2f836,
        mid_equals_32ab67f34d80b41a,
        mid_equals_592571e1c41cac52,
        mid_equals_b5b79390e6d1d13a,
        mid_equals_df6164578aa63033,
        mid_equals_c038cdd9d9a2cb32,
        mid_equals_fa21d5a4351e2542,
        mid_equals_c85e11cb281430cf,
        mid_equals_a4877243026ada7d,
        mid_equals_a3a38a76701e374f,
        mid_equals_8d89138bdbb670c4,
        mid_equals_fcc8980130d10bee,
        mid_equals_4976caebd056dc5f,
        mid_equals_0fda81a793401712,
        mid_fill_4fc93a6306046867,
        mid_fill_0282aba4eb94bbdf,
        mid_fill_3cf2205b0da22c60,
        mid_fill_4039786a5d3eeece,
        mid_fill_4fd8f943ed92fc78,
        mid_fill_3a0d6187dd745865,
        mid_fill_182fb580075bd480,
        mid_fill_704b5fae01e773b5,
        mid_fill_68486c59547ce30c,
        mid_fill_5f1bc8f101847d6c,
        mid_fill_12bb27459eee73ef,
        mid_fill_ef06af26d5ce216c,
        mid_fill_601148b59392f616,
        mid_fill_ea92352decca6d5d,
        mid_fill_0df7e607fa1b9262,
        mid_fill_0b0bdbfaf6b1d1a1,
        mid_fill_8cd176898a8aa4f3,
        mid_fill_4d3ee3d25ab172a4,
        mid_hashCode_68e5ded3d63ae943,
        mid_hashCode_226232aa28a05f69,
        mid_hashCode_fa9c15467f867585,
        mid_hashCode_4e6bbec8522a9ca7,
        mid_hashCode_52bcf81b91074c61,
        mid_hashCode_994efaf4f98da330,
        mid_hashCode_eee4c1885e66ba78,
        mid_hashCode_99a77c0f2a4e8148,
        mid_hashCode_9704f3470c4f648c,
        mid_mismatch_5dc8722edf2b8e1c,
        mid_mismatch_aba69519f903fadd,
        mid_mismatch_becae87b27419c8f,
        mid_mismatch_4af42dce0c97cffa,
        mid_mismatch_a7a566ddbd4db145,
        mid_mismatch_19ffd1fc40a342fd,
        mid_mismatch_56544b1724656816,
        mid_mismatch_a9e8e8cd26e703e5,
        mid_mismatch_5318b70968347149,
        mid_mismatch_dd82f7cdcd7083bc,
        mid_mismatch_cd29fb7adfa455bf,
        mid_mismatch_d61802d3b57b90e2,
        mid_mismatch_9f9535170b73adea,
        mid_mismatch_03628000c84c8ee8,
        mid_mismatch_aa90580a026b2fa9,
        mid_mismatch_a31204272eb18fd0,
        mid_mismatch_a15b21603a02cea9,
        mid_mismatch_8b91e77650d20061,
        mid_mismatch_6929c9f853094719,
        mid_mismatch_e251a83ac1d87cc3,
        mid_parallelPrefix_18947e9e9b97f607,
        mid_parallelPrefix_84a64c1d78c25cb9,
        mid_parallelPrefix_f81bc1f6488dc31c,
        mid_parallelPrefix_be4e0caeb5997870,
        mid_parallelPrefix_fa370d0b77d89557,
        mid_parallelPrefix_81e89f13d2b1a786,
        mid_parallelPrefix_73beaa18a22165e6,
        mid_parallelPrefix_d299cb55a65a549f,
        mid_parallelSetAll_474419896a7f7263,
        mid_parallelSetAll_040e3d578130d540,
        mid_parallelSetAll_83f6af829fb18644,
        mid_parallelSetAll_45f7717c0682edb6,
        mid_parallelSort_5cb5ede3b794e9e0,
        mid_parallelSort_ce2f97877c2b0911,
        mid_parallelSort_6c4e9976a5191896,
        mid_parallelSort_e00cace00df2e686,
        mid_parallelSort_5d0e92f1f301a114,
        mid_parallelSort_6d8d71ad6b7abe73,
        mid_parallelSort_cba6ca1a96aef518,
        mid_parallelSort_45d0667412f4c09f,
        mid_parallelSort_18c85b304a44a8a6,
        mid_parallelSort_c2a753a75ddc609c,
        mid_parallelSort_4640b6b0a50abfea,
        mid_parallelSort_4ad392aad387e26b,
        mid_parallelSort_e1b6472522c665fc,
        mid_parallelSort_de88236c88dbfb1b,
        mid_parallelSort_b5882de23d7c31f1,
        mid_parallelSort_4399d17b0d407f65,
        mid_parallelSort_9d4fe743535c32d2,
        mid_parallelSort_9d50933bfa3a0f58,
        mid_setAll_040e3d578130d540,
        mid_setAll_83f6af829fb18644,
        mid_setAll_45f7717c0682edb6,
        mid_setAll_474419896a7f7263,
        mid_sort_5cb5ede3b794e9e0,
        mid_sort_ce2f97877c2b0911,
        mid_sort_6c4e9976a5191896,
        mid_sort_e00cace00df2e686,
        mid_sort_5d0e92f1f301a114,
        mid_sort_6d8d71ad6b7abe73,
        mid_sort_3d63d0117afdb897,
        mid_sort_45d0667412f4c09f,
        mid_sort_18c85b304a44a8a6,
        mid_sort_c2a753a75ddc609c,
        mid_sort_4640b6b0a50abfea,
        mid_sort_4ad392aad387e26b,
        mid_sort_e1b6472522c665fc,
        mid_sort_de88236c88dbfb1b,
        mid_sort_b5882de23d7c31f1,
        mid_sort_40b377b978888c64,
        mid_sort_9d4fe743535c32d2,
        mid_sort_9d50933bfa3a0f58,
        mid_spliterator_01c8471e1fa1e5f8,
        mid_spliterator_aba3b4717c814437,
        mid_spliterator_1333279a37cb12eb,
        mid_spliterator_eb14252d132c8af6,
        mid_spliterator_a381690f2bd1ad75,
        mid_spliterator_c8bbdb240dd62384,
        mid_spliterator_3b8c065f7b990c01,
        mid_spliterator_413647da601f4a8e,
        mid_toString_c18fa800310d5eb1,
        mid_toString_8771d71efbfe1c9c,
        mid_toString_a77b64e8979e1c2f,
        mid_toString_a3c1cbe498bde94a,
        mid_toString_306640fd19a8da1a,
        mid_toString_e7f80ae79da192aa,
        mid_toString_fd086fa2107bd22c,
        mid_toString_ae3fd5de343c5805,
        mid_toString_ffd0331ea0958549,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Arrays(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Arrays(const Arrays& obj) : ::java::lang::Object(obj) {}

      static ::java::util::List asList(const JArray< ::java::lang::Object > &);
      static jint binarySearch(const JArray< jbyte > &, jbyte);
      static jint binarySearch(const JArray< jchar > &, jchar);
      static jint binarySearch(const JArray< jdouble > &, jdouble);
      static jint binarySearch(const JArray< jfloat > &, jfloat);
      static jint binarySearch(const JArray< jint > &, jint);
      static jint binarySearch(const JArray< jlong > &, jlong);
      static jint binarySearch(const JArray< ::java::lang::Object > &, const ::java::lang::Object &);
      static jint binarySearch(const JArray< jshort > &, jshort);
      static jint binarySearch(const JArray< ::java::lang::Object > &, const ::java::lang::Object &, const ::java::util::Comparator &);
      static jint binarySearch(const JArray< jbyte > &, jint, jint, jbyte);
      static jint binarySearch(const JArray< jchar > &, jint, jint, jchar);
      static jint binarySearch(const JArray< jdouble > &, jint, jint, jdouble);
      static jint binarySearch(const JArray< jfloat > &, jint, jint, jfloat);
      static jint binarySearch(const JArray< jint > &, jint, jint, jint);
      static jint binarySearch(const JArray< jlong > &, jint, jint, jlong);
      static jint binarySearch(const JArray< ::java::lang::Object > &, jint, jint, const ::java::lang::Object &);
      static jint binarySearch(const JArray< jshort > &, jint, jint, jshort);
      static jint binarySearch(const JArray< ::java::lang::Object > &, jint, jint, const ::java::lang::Object &, const ::java::util::Comparator &);
      static jint compare(const JArray< jbyte > &, const JArray< jbyte > &);
      static jint compare(const JArray< jchar > &, const JArray< jchar > &);
      static jint compare(const JArray< jdouble > &, const JArray< jdouble > &);
      static jint compare(const JArray< jfloat > &, const JArray< jfloat > &);
      static jint compare(const JArray< jint > &, const JArray< jint > &);
      static jint compare(const JArray< jlong > &, const JArray< jlong > &);
      static jint compare(const JArray< ::java::lang::Comparable > &, const JArray< ::java::lang::Comparable > &);
      static jint compare(const JArray< jshort > &, const JArray< jshort > &);
      static jint compare(const JArray< jboolean > &, const JArray< jboolean > &);
      static jint compare(const JArray< ::java::lang::Object > &, const JArray< ::java::lang::Object > &, const ::java::util::Comparator &);
      static jint compare(const JArray< jbyte > &, jint, jint, const JArray< jbyte > &, jint, jint);
      static jint compare(const JArray< jchar > &, jint, jint, const JArray< jchar > &, jint, jint);
      static jint compare(const JArray< jdouble > &, jint, jint, const JArray< jdouble > &, jint, jint);
      static jint compare(const JArray< jfloat > &, jint, jint, const JArray< jfloat > &, jint, jint);
      static jint compare(const JArray< jint > &, jint, jint, const JArray< jint > &, jint, jint);
      static jint compare(const JArray< jlong > &, jint, jint, const JArray< jlong > &, jint, jint);
      static jint compare(const JArray< ::java::lang::Comparable > &, jint, jint, const JArray< ::java::lang::Comparable > &, jint, jint);
      static jint compare(const JArray< jshort > &, jint, jint, const JArray< jshort > &, jint, jint);
      static jint compare(const JArray< jboolean > &, jint, jint, const JArray< jboolean > &, jint, jint);
      static jint compare(const JArray< ::java::lang::Object > &, jint, jint, const JArray< ::java::lang::Object > &, jint, jint, const ::java::util::Comparator &);
      static jint compareUnsigned(const JArray< jbyte > &, const JArray< jbyte > &);
      static jint compareUnsigned(const JArray< jint > &, const JArray< jint > &);
      static jint compareUnsigned(const JArray< jlong > &, const JArray< jlong > &);
      static jint compareUnsigned(const JArray< jshort > &, const JArray< jshort > &);
      static jint compareUnsigned(const JArray< jbyte > &, jint, jint, const JArray< jbyte > &, jint, jint);
      static jint compareUnsigned(const JArray< jint > &, jint, jint, const JArray< jint > &, jint, jint);
      static jint compareUnsigned(const JArray< jlong > &, jint, jint, const JArray< jlong > &, jint, jint);
      static jint compareUnsigned(const JArray< jshort > &, jint, jint, const JArray< jshort > &, jint, jint);
      static JArray< jbyte > copyOf(const JArray< jbyte > &, jint);
      static JArray< jchar > copyOf(const JArray< jchar > &, jint);
      static JArray< jdouble > copyOf(const JArray< jdouble > &, jint);
      static JArray< jfloat > copyOf(const JArray< jfloat > &, jint);
      static JArray< jint > copyOf(const JArray< jint > &, jint);
      static JArray< jlong > copyOf(const JArray< jlong > &, jint);
      static JArray< ::java::lang::Object > copyOf(const JArray< ::java::lang::Object > &, jint);
      static JArray< jshort > copyOf(const JArray< jshort > &, jint);
      static JArray< jboolean > copyOf(const JArray< jboolean > &, jint);
      static JArray< ::java::lang::Object > copyOf(const JArray< ::java::lang::Object > &, jint, const ::java::lang::Class &);
      static JArray< jbyte > copyOfRange(const JArray< jbyte > &, jint, jint);
      static JArray< jchar > copyOfRange(const JArray< jchar > &, jint, jint);
      static JArray< jdouble > copyOfRange(const JArray< jdouble > &, jint, jint);
      static JArray< jfloat > copyOfRange(const JArray< jfloat > &, jint, jint);
      static JArray< jint > copyOfRange(const JArray< jint > &, jint, jint);
      static JArray< jlong > copyOfRange(const JArray< jlong > &, jint, jint);
      static JArray< ::java::lang::Object > copyOfRange(const JArray< ::java::lang::Object > &, jint, jint);
      static JArray< jshort > copyOfRange(const JArray< jshort > &, jint, jint);
      static JArray< jboolean > copyOfRange(const JArray< jboolean > &, jint, jint);
      static JArray< ::java::lang::Object > copyOfRange(const JArray< ::java::lang::Object > &, jint, jint, const ::java::lang::Class &);
      static jboolean deepEquals(const JArray< ::java::lang::Object > &, const JArray< ::java::lang::Object > &);
      static jint deepHashCode(const JArray< ::java::lang::Object > &);
      static ::java::lang::String deepToString(const JArray< ::java::lang::Object > &);
      static jboolean equals(const JArray< jbyte > &, const JArray< jbyte > &);
      static jboolean equals(const JArray< jchar > &, const JArray< jchar > &);
      static jboolean equals(const JArray< jdouble > &, const JArray< jdouble > &);
      static jboolean equals(const JArray< jfloat > &, const JArray< jfloat > &);
      static jboolean equals(const JArray< jint > &, const JArray< jint > &);
      static jboolean equals(const JArray< jlong > &, const JArray< jlong > &);
      static jboolean equals(const JArray< ::java::lang::Object > &, const JArray< ::java::lang::Object > &);
      static jboolean equals(const JArray< jshort > &, const JArray< jshort > &);
      static jboolean equals(const JArray< jboolean > &, const JArray< jboolean > &);
      static jboolean equals(const JArray< ::java::lang::Object > &, const JArray< ::java::lang::Object > &, const ::java::util::Comparator &);
      static jboolean equals(const JArray< jbyte > &, jint, jint, const JArray< jbyte > &, jint, jint);
      static jboolean equals(const JArray< jchar > &, jint, jint, const JArray< jchar > &, jint, jint);
      static jboolean equals(const JArray< jdouble > &, jint, jint, const JArray< jdouble > &, jint, jint);
      static jboolean equals(const JArray< jfloat > &, jint, jint, const JArray< jfloat > &, jint, jint);
      static jboolean equals(const JArray< jint > &, jint, jint, const JArray< jint > &, jint, jint);
      static jboolean equals(const JArray< jlong > &, jint, jint, const JArray< jlong > &, jint, jint);
      static jboolean equals(const JArray< ::java::lang::Object > &, jint, jint, const JArray< ::java::lang::Object > &, jint, jint);
      static jboolean equals(const JArray< jshort > &, jint, jint, const JArray< jshort > &, jint, jint);
      static jboolean equals(const JArray< jboolean > &, jint, jint, const JArray< jboolean > &, jint, jint);
      static jboolean equals(const JArray< ::java::lang::Object > &, jint, jint, const JArray< ::java::lang::Object > &, jint, jint, const ::java::util::Comparator &);
      static void fill(const JArray< jbyte > &, jbyte);
      static void fill(const JArray< jchar > &, jchar);
      static void fill(const JArray< jdouble > &, jdouble);
      static void fill(const JArray< jfloat > &, jfloat);
      static void fill(const JArray< jint > &, jint);
      static void fill(const JArray< jlong > &, jlong);
      static void fill(const JArray< ::java::lang::Object > &, const ::java::lang::Object &);
      static void fill(const JArray< jshort > &, jshort);
      static void fill(const JArray< jboolean > &, jboolean);
      static void fill(const JArray< jbyte > &, jint, jint, jbyte);
      static void fill(const JArray< jchar > &, jint, jint, jchar);
      static void fill(const JArray< jdouble > &, jint, jint, jdouble);
      static void fill(const JArray< jfloat > &, jint, jint, jfloat);
      static void fill(const JArray< jint > &, jint, jint, jint);
      static void fill(const JArray< ::java::lang::Object > &, jint, jint, const ::java::lang::Object &);
      static void fill(const JArray< jlong > &, jint, jint, jlong);
      static void fill(const JArray< jboolean > &, jint, jint, jboolean);
      static void fill(const JArray< jshort > &, jint, jint, jshort);
      static jint hashCode(const JArray< jbyte > &);
      static jint hashCode(const JArray< jchar > &);
      static jint hashCode(const JArray< jdouble > &);
      static jint hashCode(const JArray< jfloat > &);
      static jint hashCode(const JArray< jint > &);
      static jint hashCode(const JArray< jlong > &);
      static jint hashCode(const JArray< ::java::lang::Object > &);
      static jint hashCode(const JArray< jshort > &);
      static jint hashCode(const JArray< jboolean > &);
      static jint mismatch(const JArray< jbyte > &, const JArray< jbyte > &);
      static jint mismatch(const JArray< jchar > &, const JArray< jchar > &);
      static jint mismatch(const JArray< jdouble > &, const JArray< jdouble > &);
      static jint mismatch(const JArray< jfloat > &, const JArray< jfloat > &);
      static jint mismatch(const JArray< jint > &, const JArray< jint > &);
      static jint mismatch(const JArray< jlong > &, const JArray< jlong > &);
      static jint mismatch(const JArray< ::java::lang::Object > &, const JArray< ::java::lang::Object > &);
      static jint mismatch(const JArray< jshort > &, const JArray< jshort > &);
      static jint mismatch(const JArray< jboolean > &, const JArray< jboolean > &);
      static jint mismatch(const JArray< ::java::lang::Object > &, const JArray< ::java::lang::Object > &, const ::java::util::Comparator &);
      static jint mismatch(const JArray< jbyte > &, jint, jint, const JArray< jbyte > &, jint, jint);
      static jint mismatch(const JArray< jchar > &, jint, jint, const JArray< jchar > &, jint, jint);
      static jint mismatch(const JArray< jdouble > &, jint, jint, const JArray< jdouble > &, jint, jint);
      static jint mismatch(const JArray< jfloat > &, jint, jint, const JArray< jfloat > &, jint, jint);
      static jint mismatch(const JArray< jint > &, jint, jint, const JArray< jint > &, jint, jint);
      static jint mismatch(const JArray< jlong > &, jint, jint, const JArray< jlong > &, jint, jint);
      static jint mismatch(const JArray< ::java::lang::Object > &, jint, jint, const JArray< ::java::lang::Object > &, jint, jint);
      static jint mismatch(const JArray< jshort > &, jint, jint, const JArray< jshort > &, jint, jint);
      static jint mismatch(const JArray< jboolean > &, jint, jint, const JArray< jboolean > &, jint, jint);
      static jint mismatch(const JArray< ::java::lang::Object > &, jint, jint, const JArray< ::java::lang::Object > &, jint, jint, const ::java::util::Comparator &);
      static void parallelPrefix(const JArray< ::java::lang::Object > &, const ::java::util::function::BinaryOperator &);
      static void parallelPrefix(const JArray< jdouble > &, const ::java::util::function::DoubleBinaryOperator &);
      static void parallelPrefix(const JArray< jint > &, const ::java::util::function::IntBinaryOperator &);
      static void parallelPrefix(const JArray< jlong > &, const ::java::util::function::LongBinaryOperator &);
      static void parallelPrefix(const JArray< ::java::lang::Object > &, jint, jint, const ::java::util::function::BinaryOperator &);
      static void parallelPrefix(const JArray< jdouble > &, jint, jint, const ::java::util::function::DoubleBinaryOperator &);
      static void parallelPrefix(const JArray< jint > &, jint, jint, const ::java::util::function::IntBinaryOperator &);
      static void parallelPrefix(const JArray< jlong > &, jint, jint, const ::java::util::function::LongBinaryOperator &);
      static void parallelSetAll(const JArray< jint > &, const ::java::util::function::IntUnaryOperator &);
      static void parallelSetAll(const JArray< ::java::lang::Object > &, const ::java::util::function::IntFunction &);
      static void parallelSetAll(const JArray< jdouble > &, const ::java::util::function::IntToDoubleFunction &);
      static void parallelSetAll(const JArray< jlong > &, const ::java::util::function::IntToLongFunction &);
      static void parallelSort(const JArray< jbyte > &);
      static void parallelSort(const JArray< jchar > &);
      static void parallelSort(const JArray< jdouble > &);
      static void parallelSort(const JArray< jfloat > &);
      static void parallelSort(const JArray< jint > &);
      static void parallelSort(const JArray< jlong > &);
      static void parallelSort(const JArray< ::java::lang::Comparable > &);
      static void parallelSort(const JArray< jshort > &);
      static void parallelSort(const JArray< ::java::lang::Object > &, const ::java::util::Comparator &);
      static void parallelSort(const JArray< jbyte > &, jint, jint);
      static void parallelSort(const JArray< jchar > &, jint, jint);
      static void parallelSort(const JArray< jdouble > &, jint, jint);
      static void parallelSort(const JArray< jfloat > &, jint, jint);
      static void parallelSort(const JArray< jint > &, jint, jint);
      static void parallelSort(const JArray< jlong > &, jint, jint);
      static void parallelSort(const JArray< ::java::lang::Comparable > &, jint, jint);
      static void parallelSort(const JArray< jshort > &, jint, jint);
      static void parallelSort(const JArray< ::java::lang::Object > &, jint, jint, const ::java::util::Comparator &);
      static void setAll(const JArray< ::java::lang::Object > &, const ::java::util::function::IntFunction &);
      static void setAll(const JArray< jdouble > &, const ::java::util::function::IntToDoubleFunction &);
      static void setAll(const JArray< jlong > &, const ::java::util::function::IntToLongFunction &);
      static void setAll(const JArray< jint > &, const ::java::util::function::IntUnaryOperator &);
      static void sort(const JArray< jbyte > &);
      static void sort(const JArray< jchar > &);
      static void sort(const JArray< jdouble > &);
      static void sort(const JArray< jfloat > &);
      static void sort(const JArray< jint > &);
      static void sort(const JArray< jlong > &);
      static void sort(const JArray< ::java::lang::Object > &);
      static void sort(const JArray< jshort > &);
      static void sort(const JArray< ::java::lang::Object > &, const ::java::util::Comparator &);
      static void sort(const JArray< jbyte > &, jint, jint);
      static void sort(const JArray< jchar > &, jint, jint);
      static void sort(const JArray< jdouble > &, jint, jint);
      static void sort(const JArray< jfloat > &, jint, jint);
      static void sort(const JArray< jint > &, jint, jint);
      static void sort(const JArray< jlong > &, jint, jint);
      static void sort(const JArray< ::java::lang::Object > &, jint, jint);
      static void sort(const JArray< jshort > &, jint, jint);
      static void sort(const JArray< ::java::lang::Object > &, jint, jint, const ::java::util::Comparator &);
      static ::java::util::Spliterator$OfDouble spliterator(const JArray< jdouble > &);
      static ::java::util::Spliterator$OfInt spliterator(const JArray< jint > &);
      static ::java::util::Spliterator$OfLong spliterator(const JArray< jlong > &);
      static ::java::util::Spliterator spliterator(const JArray< ::java::lang::Object > &);
      static ::java::util::Spliterator$OfDouble spliterator(const JArray< jdouble > &, jint, jint);
      static ::java::util::Spliterator$OfInt spliterator(const JArray< jint > &, jint, jint);
      static ::java::util::Spliterator$OfLong spliterator(const JArray< jlong > &, jint, jint);
      static ::java::util::Spliterator spliterator(const JArray< ::java::lang::Object > &, jint, jint);
      static ::java::lang::String toString(const JArray< jbyte > &);
      static ::java::lang::String toString(const JArray< jchar > &);
      static ::java::lang::String toString(const JArray< jdouble > &);
      static ::java::lang::String toString(const JArray< jfloat > &);
      static ::java::lang::String toString(const JArray< jint > &);
      static ::java::lang::String toString(const JArray< jlong > &);
      static ::java::lang::String toString(const JArray< ::java::lang::Object > &);
      static ::java::lang::String toString(const JArray< jshort > &);
      static ::java::lang::String toString(const JArray< jboolean > &);
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(Arrays);
    extern PyTypeObject *PY_TYPE(Arrays);

    class t_Arrays {
    public:
      PyObject_HEAD
      Arrays object;
      static PyObject *wrap_Object(const Arrays&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
