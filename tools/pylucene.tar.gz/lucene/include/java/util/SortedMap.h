#ifndef java_util_SortedMap_H
#define java_util_SortedMap_H

#include "java/util/SequencedMap.h"

namespace java {
  namespace util {
    class Comparator;
    class SortedMap;
    class Map$Entry;
    class Set;
    class Collection;
  }
  namespace lang {
    class Class;
    class Object;
  }
}
template<class T> class JArray;

namespace java {
  namespace util {

    class SortedMap : public ::java::util::SequencedMap {
     public:
      enum {
        mid_comparator_54213bfa5c9a50fd,
        mid_entrySet_9cfd5750b6ef4685,
        mid_firstKey_1543ec1f1674e5aa,
        mid_headMap_8ee61cddf4d79299,
        mid_keySet_9cfd5750b6ef4685,
        mid_lastKey_1543ec1f1674e5aa,
        mid_putFirst_c36cd8daf720e2b9,
        mid_putLast_c36cd8daf720e2b9,
        mid_reversed_af76364ef47a518d,
        mid_subMap_635d847f6b37ed08,
        mid_tailMap_8ee61cddf4d79299,
        mid_values_7ff6744e4f3958ed,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit SortedMap(jobject obj) : ::java::util::SequencedMap(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      SortedMap(const SortedMap& obj) : ::java::util::SequencedMap(obj) {}

      ::java::util::Comparator comparator() const;
      ::java::util::Set entrySet() const;
      ::java::lang::Object firstKey() const;
      SortedMap headMap(const ::java::lang::Object &) const;
      ::java::util::Set keySet() const;
      ::java::lang::Object lastKey() const;
      ::java::lang::Object putFirst(const ::java::lang::Object &, const ::java::lang::Object &) const;
      ::java::lang::Object putLast(const ::java::lang::Object &, const ::java::lang::Object &) const;
      SortedMap reversed() const;
      SortedMap subMap(const ::java::lang::Object &, const ::java::lang::Object &) const;
      SortedMap tailMap(const ::java::lang::Object &) const;
      ::java::util::Collection values() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace util {
    extern PyType_Def PY_TYPE_DEF(SortedMap);
    extern PyTypeObject *PY_TYPE(SortedMap);

    class t_SortedMap {
    public:
      PyObject_HEAD
      SortedMap object;
      PyTypeObject *parameters[2];
      static PyTypeObject **parameters_(t_SortedMap *self)
      {
        return (PyTypeObject **) &(self->parameters);
      }
      static PyObject *wrap_Object(const SortedMap&);
      static PyObject *wrap_jobject(const jobject&);
      static PyObject *wrap_Object(const SortedMap&, PyTypeObject *, PyTypeObject *);
      static PyObject *wrap_jobject(const jobject&, PyTypeObject *, PyTypeObject *);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
