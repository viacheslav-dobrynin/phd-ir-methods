#ifndef java_text_Collator_H
#define java_text_Collator_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Comparator;
    class Locale;
  }
  namespace lang {
    class Class;
    class String;
    class Cloneable;
  }
  namespace text {
    class Collator;
  }
}
template<class T> class JArray;

namespace java {
  namespace text {

    class Collator : public ::java::lang::Object {
     public:
      enum {
        mid_clone_1543ec1f1674e5aa,
        mid_compare_7da24b6fa52e63c9,
        mid_compare_7987741873b0ac5b,
        mid_equals_2a09f73f0549554f,
        mid_equals_a9082f6bc936380b,
        mid_getAvailableLocales_731cc618dad45867,
        mid_getDecomposition_f03edc6a210ac78c,
        mid_getInstance_d4729791bfd0421e,
        mid_getInstance_636809f09dba77a0,
        mid_getStrength_f03edc6a210ac78c,
        mid_hashCode_f03edc6a210ac78c,
        mid_setDecomposition_8730ba9dfaf23a7b,
        mid_setStrength_8730ba9dfaf23a7b,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Collator(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Collator(const Collator& obj) : ::java::lang::Object(obj) {}

      static jint CANONICAL_DECOMPOSITION;
      static jint FULL_DECOMPOSITION;
      static jint IDENTICAL;
      static jint NO_DECOMPOSITION;
      static jint PRIMARY;
      static jint SECONDARY;
      static jint TERTIARY;

      ::java::lang::Object clone() const;
      jint compare(const ::java::lang::String &, const ::java::lang::String &) const;
      jint compare(const ::java::lang::Object &, const ::java::lang::Object &) const;
      jboolean equals(const ::java::lang::Object &) const;
      jboolean equals(const ::java::lang::String &, const ::java::lang::String &) const;
      static JArray< ::java::util::Locale > getAvailableLocales();
      jint getDecomposition() const;
      static Collator getInstance();
      static Collator getInstance(const ::java::util::Locale &);
      jint getStrength() const;
      jint hashCode() const;
      void setDecomposition(jint) const;
      void setStrength(jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace text {
    extern PyType_Def PY_TYPE_DEF(Collator);
    extern PyTypeObject *PY_TYPE(Collator);

    class t_Collator {
    public:
      PyObject_HEAD
      Collator object;
      static PyObject *wrap_Object(const Collator&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
