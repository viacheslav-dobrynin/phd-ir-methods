#ifndef java_text_BreakIterator_H
#define java_text_BreakIterator_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Cloneable;
  }
  namespace util {
    class Locale;
  }
  namespace text {
    class BreakIterator;
  }
}
template<class T> class JArray;

namespace java {
  namespace text {

    class BreakIterator : public ::java::lang::Object {
     public:
      enum {
        mid_clone_1543ec1f1674e5aa,
        mid_current_f03edc6a210ac78c,
        mid_first_f03edc6a210ac78c,
        mid_following_ff66fe240ad72894,
        mid_getAvailableLocales_731cc618dad45867,
        mid_getCharacterInstance_9a37e861b56c0e74,
        mid_getCharacterInstance_09fbeaad7b863842,
        mid_getLineInstance_9a37e861b56c0e74,
        mid_getLineInstance_09fbeaad7b863842,
        mid_getSentenceInstance_9a37e861b56c0e74,
        mid_getSentenceInstance_09fbeaad7b863842,
        mid_getWordInstance_9a37e861b56c0e74,
        mid_getWordInstance_09fbeaad7b863842,
        mid_isBoundary_12fe561dd4de11f3,
        mid_last_f03edc6a210ac78c,
        mid_next_f03edc6a210ac78c,
        mid_next_ff66fe240ad72894,
        mid_preceding_ff66fe240ad72894,
        mid_previous_f03edc6a210ac78c,
        mid_setText_9b22ecdee06ea23c,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit BreakIterator(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      BreakIterator(const BreakIterator& obj) : ::java::lang::Object(obj) {}

      static jint DONE;

      ::java::lang::Object clone() const;
      jint current() const;
      jint first() const;
      jint following(jint) const;
      static JArray< ::java::util::Locale > getAvailableLocales();
      static BreakIterator getCharacterInstance();
      static BreakIterator getCharacterInstance(const ::java::util::Locale &);
      static BreakIterator getLineInstance();
      static BreakIterator getLineInstance(const ::java::util::Locale &);
      static BreakIterator getSentenceInstance();
      static BreakIterator getSentenceInstance(const ::java::util::Locale &);
      static BreakIterator getWordInstance();
      static BreakIterator getWordInstance(const ::java::util::Locale &);
      jboolean isBoundary(jint) const;
      jint last() const;
      jint next() const;
      jint next(jint) const;
      jint preceding(jint) const;
      jint previous() const;
      void setText(const ::java::lang::String &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace text {
    extern PyType_Def PY_TYPE_DEF(BreakIterator);
    extern PyTypeObject *PY_TYPE(BreakIterator);

    class t_BreakIterator {
    public:
      PyObject_HEAD
      BreakIterator object;
      static PyObject *wrap_Object(const BreakIterator&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
