#ifndef java_text_NumberFormat_H
#define java_text_NumberFormat_H

#include "java/text/Format.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Number;
    class Object;
    class StringBuffer;
  }
  namespace util {
    class Currency;
    class Locale;
  }
  namespace text {
    class NumberFormat;
  }
}
template<class T> class JArray;

namespace java {
  namespace text {

    class NumberFormat : public ::java::text::Format {
     public:
      enum {
        mid_clone_1543ec1f1674e5aa,
        mid_equals_2a09f73f0549554f,
        mid_format_74f601c4b6f2da5a,
        mid_format_3bbdb48ea758edad,
        mid_getAvailableLocales_731cc618dad45867,
        mid_getCompactNumberInstance_b4e73ad642cad0cb,
        mid_getCurrency_372c03e34978d28c,
        mid_getCurrencyInstance_b4e73ad642cad0cb,
        mid_getCurrencyInstance_c05c06692ef84339,
        mid_getInstance_b4e73ad642cad0cb,
        mid_getInstance_c05c06692ef84339,
        mid_getIntegerInstance_b4e73ad642cad0cb,
        mid_getIntegerInstance_c05c06692ef84339,
        mid_getMaximumFractionDigits_f03edc6a210ac78c,
        mid_getMaximumIntegerDigits_f03edc6a210ac78c,
        mid_getMinimumFractionDigits_f03edc6a210ac78c,
        mid_getMinimumIntegerDigits_f03edc6a210ac78c,
        mid_getNumberInstance_b4e73ad642cad0cb,
        mid_getNumberInstance_c05c06692ef84339,
        mid_getPercentInstance_b4e73ad642cad0cb,
        mid_getPercentInstance_c05c06692ef84339,
        mid_hashCode_f03edc6a210ac78c,
        mid_isGroupingUsed_201fceb6e9f1d0c5,
        mid_isParseIntegerOnly_201fceb6e9f1d0c5,
        mid_parse_709540d39304afb9,
        mid_setCurrency_f2642dde2ae98dcf,
        mid_setGroupingUsed_a5b6a940fc16c6a1,
        mid_setMaximumFractionDigits_8730ba9dfaf23a7b,
        mid_setMaximumIntegerDigits_8730ba9dfaf23a7b,
        mid_setMinimumFractionDigits_8730ba9dfaf23a7b,
        mid_setMinimumIntegerDigits_8730ba9dfaf23a7b,
        mid_setParseIntegerOnly_a5b6a940fc16c6a1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit NumberFormat(jobject obj) : ::java::text::Format(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      NumberFormat(const NumberFormat& obj) : ::java::text::Format(obj) {}

      static jint FRACTION_FIELD;
      static jint INTEGER_FIELD;

      ::java::lang::Object clone() const;
      jboolean equals(const ::java::lang::Object &) const;
      ::java::lang::String format(jdouble) const;
      ::java::lang::String format(jlong) const;
      static JArray< ::java::util::Locale > getAvailableLocales();
      static NumberFormat getCompactNumberInstance();
      ::java::util::Currency getCurrency() const;
      static NumberFormat getCurrencyInstance();
      static NumberFormat getCurrencyInstance(const ::java::util::Locale &);
      static NumberFormat getInstance();
      static NumberFormat getInstance(const ::java::util::Locale &);
      static NumberFormat getIntegerInstance();
      static NumberFormat getIntegerInstance(const ::java::util::Locale &);
      jint getMaximumFractionDigits() const;
      jint getMaximumIntegerDigits() const;
      jint getMinimumFractionDigits() const;
      jint getMinimumIntegerDigits() const;
      static NumberFormat getNumberInstance();
      static NumberFormat getNumberInstance(const ::java::util::Locale &);
      static NumberFormat getPercentInstance();
      static NumberFormat getPercentInstance(const ::java::util::Locale &);
      jint hashCode() const;
      jboolean isGroupingUsed() const;
      jboolean isParseIntegerOnly() const;
      ::java::lang::Number parse(const ::java::lang::String &) const;
      void setCurrency(const ::java::util::Currency &) const;
      void setGroupingUsed(jboolean) const;
      void setMaximumFractionDigits(jint) const;
      void setMaximumIntegerDigits(jint) const;
      void setMinimumFractionDigits(jint) const;
      void setMinimumIntegerDigits(jint) const;
      void setParseIntegerOnly(jboolean) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace text {
    extern PyType_Def PY_TYPE_DEF(NumberFormat);
    extern PyTypeObject *PY_TYPE(NumberFormat);

    class t_NumberFormat {
    public:
      PyObject_HEAD
      NumberFormat object;
      static PyObject *wrap_Object(const NumberFormat&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
