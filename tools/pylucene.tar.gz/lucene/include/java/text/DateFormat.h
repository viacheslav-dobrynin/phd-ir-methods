#ifndef java_text_DateFormat_H
#define java_text_DateFormat_H

#include "java/text/Format.h"

namespace java {
  namespace util {
    class Date;
    class TimeZone;
    class Locale;
    class Calendar;
  }
  namespace lang {
    class Class;
    class String;
    class Object;
    class StringBuffer;
  }
  namespace text {
    class DateFormat;
    class NumberFormat;
  }
}
template<class T> class JArray;

namespace java {
  namespace text {

    class DateFormat : public ::java::text::Format {
     public:
      enum {
        mid_clone_1543ec1f1674e5aa,
        mid_equals_2a09f73f0549554f,
        mid_format_63c1d656181ec1f3,
        mid_getAvailableLocales_731cc618dad45867,
        mid_getCalendar_1c82cc490d009ccd,
        mid_getDateInstance_fbe57e1122a1faea,
        mid_getDateInstance_fef35224696b30b8,
        mid_getDateInstance_59d4b4bd1c1c34ea,
        mid_getDateTimeInstance_fbe57e1122a1faea,
        mid_getDateTimeInstance_600a234641347ea2,
        mid_getDateTimeInstance_e34298f33680117c,
        mid_getInstance_fbe57e1122a1faea,
        mid_getNumberFormat_b4e73ad642cad0cb,
        mid_getTimeInstance_fbe57e1122a1faea,
        mid_getTimeInstance_fef35224696b30b8,
        mid_getTimeInstance_59d4b4bd1c1c34ea,
        mid_getTimeZone_2390a80e62c8ee13,
        mid_hashCode_f03edc6a210ac78c,
        mid_isLenient_201fceb6e9f1d0c5,
        mid_parse_1de8c906129bee45,
        mid_setCalendar_f8521fc6e24a9e77,
        mid_setLenient_a5b6a940fc16c6a1,
        mid_setNumberFormat_a9ccbc4aa8f84384,
        mid_setTimeZone_360e2577ada3581c,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit DateFormat(jobject obj) : ::java::text::Format(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      DateFormat(const DateFormat& obj) : ::java::text::Format(obj) {}

      static jint AM_PM_FIELD;
      static jint DATE_FIELD;
      static jint DAY_OF_WEEK_FIELD;
      static jint DAY_OF_WEEK_IN_MONTH_FIELD;
      static jint DAY_OF_YEAR_FIELD;
      static jint DEFAULT;
      static jint ERA_FIELD;
      static jint FULL;
      static jint HOUR0_FIELD;
      static jint HOUR1_FIELD;
      static jint HOUR_OF_DAY0_FIELD;
      static jint HOUR_OF_DAY1_FIELD;
      static jint LONG;
      static jint MEDIUM;
      static jint MILLISECOND_FIELD;
      static jint MINUTE_FIELD;
      static jint MONTH_FIELD;
      static jint SECOND_FIELD;
      static jint SHORT;
      static jint TIMEZONE_FIELD;
      static jint WEEK_OF_MONTH_FIELD;
      static jint WEEK_OF_YEAR_FIELD;
      static jint YEAR_FIELD;

      ::java::lang::Object clone() const;
      jboolean equals(const ::java::lang::Object &) const;
      ::java::lang::String format(const ::java::util::Date &) const;
      static JArray< ::java::util::Locale > getAvailableLocales();
      ::java::util::Calendar getCalendar() const;
      static DateFormat getDateInstance();
      static DateFormat getDateInstance(jint);
      static DateFormat getDateInstance(jint, const ::java::util::Locale &);
      static DateFormat getDateTimeInstance();
      static DateFormat getDateTimeInstance(jint, jint);
      static DateFormat getDateTimeInstance(jint, jint, const ::java::util::Locale &);
      static DateFormat getInstance();
      ::java::text::NumberFormat getNumberFormat() const;
      static DateFormat getTimeInstance();
      static DateFormat getTimeInstance(jint);
      static DateFormat getTimeInstance(jint, const ::java::util::Locale &);
      ::java::util::TimeZone getTimeZone() const;
      jint hashCode() const;
      jboolean isLenient() const;
      ::java::util::Date parse(const ::java::lang::String &) const;
      void setCalendar(const ::java::util::Calendar &) const;
      void setLenient(jboolean) const;
      void setNumberFormat(const ::java::text::NumberFormat &) const;
      void setTimeZone(const ::java::util::TimeZone &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace text {
    extern PyType_Def PY_TYPE_DEF(DateFormat);
    extern PyTypeObject *PY_TYPE(DateFormat);

    class t_DateFormat {
    public:
      PyObject_HEAD
      DateFormat object;
      static PyObject *wrap_Object(const DateFormat&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
