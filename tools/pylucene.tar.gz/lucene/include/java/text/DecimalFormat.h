#ifndef java_text_DecimalFormat_H
#define java_text_DecimalFormat_H

#include "java/text/NumberFormat.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Number;
    class Object;
    class StringBuffer;
  }
  namespace util {
    class Currency;
  }
}
template<class T> class JArray;

namespace java {
  namespace text {

    class DecimalFormat : public ::java::text::NumberFormat {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_9b22ecdee06ea23c,
        mid_applyLocalizedPattern_9b22ecdee06ea23c,
        mid_applyPattern_9b22ecdee06ea23c,
        mid_clone_1543ec1f1674e5aa,
        mid_equals_2a09f73f0549554f,
        mid_getCurrency_372c03e34978d28c,
        mid_getGroupingSize_f03edc6a210ac78c,
        mid_getMaximumFractionDigits_f03edc6a210ac78c,
        mid_getMaximumIntegerDigits_f03edc6a210ac78c,
        mid_getMinimumFractionDigits_f03edc6a210ac78c,
        mid_getMinimumIntegerDigits_f03edc6a210ac78c,
        mid_getMultiplier_f03edc6a210ac78c,
        mid_getNegativePrefix_cb1e3f35ce7b2bd1,
        mid_getNegativeSuffix_cb1e3f35ce7b2bd1,
        mid_getPositivePrefix_cb1e3f35ce7b2bd1,
        mid_getPositiveSuffix_cb1e3f35ce7b2bd1,
        mid_hashCode_f03edc6a210ac78c,
        mid_isDecimalSeparatorAlwaysShown_201fceb6e9f1d0c5,
        mid_isParseBigDecimal_201fceb6e9f1d0c5,
        mid_setCurrency_f2642dde2ae98dcf,
        mid_setDecimalSeparatorAlwaysShown_a5b6a940fc16c6a1,
        mid_setGroupingSize_8730ba9dfaf23a7b,
        mid_setGroupingUsed_a5b6a940fc16c6a1,
        mid_setMaximumFractionDigits_8730ba9dfaf23a7b,
        mid_setMaximumIntegerDigits_8730ba9dfaf23a7b,
        mid_setMinimumFractionDigits_8730ba9dfaf23a7b,
        mid_setMinimumIntegerDigits_8730ba9dfaf23a7b,
        mid_setMultiplier_8730ba9dfaf23a7b,
        mid_setNegativePrefix_9b22ecdee06ea23c,
        mid_setNegativeSuffix_9b22ecdee06ea23c,
        mid_setParseBigDecimal_a5b6a940fc16c6a1,
        mid_setPositivePrefix_9b22ecdee06ea23c,
        mid_setPositiveSuffix_9b22ecdee06ea23c,
        mid_toLocalizedPattern_cb1e3f35ce7b2bd1,
        mid_toPattern_cb1e3f35ce7b2bd1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit DecimalFormat(jobject obj) : ::java::text::NumberFormat(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      DecimalFormat(const DecimalFormat& obj) : ::java::text::NumberFormat(obj) {}

      DecimalFormat();
      DecimalFormat(const ::java::lang::String &);

      void applyLocalizedPattern(const ::java::lang::String &) const;
      void applyPattern(const ::java::lang::String &) const;
      ::java::lang::Object clone() const;
      jboolean equals(const ::java::lang::Object &) const;
      ::java::util::Currency getCurrency() const;
      jint getGroupingSize() const;
      jint getMaximumFractionDigits() const;
      jint getMaximumIntegerDigits() const;
      jint getMinimumFractionDigits() const;
      jint getMinimumIntegerDigits() const;
      jint getMultiplier() const;
      ::java::lang::String getNegativePrefix() const;
      ::java::lang::String getNegativeSuffix() const;
      ::java::lang::String getPositivePrefix() const;
      ::java::lang::String getPositiveSuffix() const;
      jint hashCode() const;
      jboolean isDecimalSeparatorAlwaysShown() const;
      jboolean isParseBigDecimal() const;
      void setCurrency(const ::java::util::Currency &) const;
      void setDecimalSeparatorAlwaysShown(jboolean) const;
      void setGroupingSize(jint) const;
      void setGroupingUsed(jboolean) const;
      void setMaximumFractionDigits(jint) const;
      void setMaximumIntegerDigits(jint) const;
      void setMinimumFractionDigits(jint) const;
      void setMinimumIntegerDigits(jint) const;
      void setMultiplier(jint) const;
      void setNegativePrefix(const ::java::lang::String &) const;
      void setNegativeSuffix(const ::java::lang::String &) const;
      void setParseBigDecimal(jboolean) const;
      void setPositivePrefix(const ::java::lang::String &) const;
      void setPositiveSuffix(const ::java::lang::String &) const;
      ::java::lang::String toLocalizedPattern() const;
      ::java::lang::String toPattern() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace text {
    extern PyType_Def PY_TYPE_DEF(DecimalFormat);
    extern PyTypeObject *PY_TYPE(DecimalFormat);

    class t_DecimalFormat {
    public:
      PyObject_HEAD
      DecimalFormat object;
      static PyObject *wrap_Object(const DecimalFormat&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
