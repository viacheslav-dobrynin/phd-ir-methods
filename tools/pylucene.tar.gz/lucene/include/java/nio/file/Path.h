#ifndef java_nio_file_Path_H
#define java_nio_file_Path_H

#include "java/lang/Comparable.h"

namespace java {
  namespace util {
    class Iterator;
  }
  namespace nio {
    namespace file {
      class WatchEvent$Modifier;
      class Watchable;
      class WatchService;
      class FileSystem;
      class WatchKey;
      class Path;
      class LinkOption;
      class WatchEvent$Kind;
    }
  }
  namespace io {
    class File;
    class IOException;
  }
  namespace lang {
    class Iterable;
    class Class;
    class String;
    class Object;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class Path : public ::java::lang::Comparable {
       public:
        enum {
          mid_compareTo_bdea69a76f029018,
          mid_endsWith_7585662e3a5cb869,
          mid_endsWith_ca4608581a507acd,
          mid_equals_2a09f73f0549554f,
          mid_getFileName_bd4213659d0d079d,
          mid_getFileSystem_245784f509200a72,
          mid_getName_61570ca5a1d78387,
          mid_getNameCount_f03edc6a210ac78c,
          mid_getParent_bd4213659d0d079d,
          mid_getRoot_bd4213659d0d079d,
          mid_hashCode_f03edc6a210ac78c,
          mid_isAbsolute_201fceb6e9f1d0c5,
          mid_iterator_d58ed5f479280ab0,
          mid_normalize_bd4213659d0d079d,
          mid_of_43f8dfa47b5ba8e1,
          mid_register_cd003a03645cf0ef,
          mid_register_9884b51bec183706,
          mid_relativize_020217e8a7d8d1cd,
          mid_resolve_7613eacc5ad252bd,
          mid_resolve_020217e8a7d8d1cd,
          mid_resolveSibling_7613eacc5ad252bd,
          mid_resolveSibling_020217e8a7d8d1cd,
          mid_startsWith_7585662e3a5cb869,
          mid_startsWith_ca4608581a507acd,
          mid_subpath_3b13068a97f30c46,
          mid_toAbsolutePath_bd4213659d0d079d,
          mid_toFile_b557e19cb184383f,
          mid_toRealPath_0df1ea7cdb4a13a0,
          mid_toString_cb1e3f35ce7b2bd1,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit Path(jobject obj) : ::java::lang::Comparable(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        Path(const Path& obj) : ::java::lang::Comparable(obj) {}

        jint compareTo(const Path &) const;
        jboolean endsWith(const ::java::lang::String &) const;
        jboolean endsWith(const Path &) const;
        jboolean equals(const ::java::lang::Object &) const;
        Path getFileName() const;
        ::java::nio::file::FileSystem getFileSystem() const;
        Path getName(jint) const;
        jint getNameCount() const;
        Path getParent() const;
        Path getRoot() const;
        jint hashCode() const;
        jboolean isAbsolute() const;
        ::java::util::Iterator iterator() const;
        Path normalize() const;
        static Path of(const ::java::lang::String &, const JArray< ::java::lang::String > &);
        ::java::nio::file::WatchKey register$(const ::java::nio::file::WatchService &, const JArray< ::java::nio::file::WatchEvent$Kind > &) const;
        ::java::nio::file::WatchKey register$(const ::java::nio::file::WatchService &, const JArray< ::java::nio::file::WatchEvent$Kind > &, const JArray< ::java::nio::file::WatchEvent$Modifier > &) const;
        Path relativize(const Path &) const;
        Path resolve(const ::java::lang::String &) const;
        Path resolve(const Path &) const;
        Path resolveSibling(const ::java::lang::String &) const;
        Path resolveSibling(const Path &) const;
        jboolean startsWith(const ::java::lang::String &) const;
        jboolean startsWith(const Path &) const;
        Path subpath(jint, jint) const;
        Path toAbsolutePath() const;
        ::java::io::File toFile() const;
        Path toRealPath(const JArray< ::java::nio::file::LinkOption > &) const;
        ::java::lang::String toString() const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      extern PyType_Def PY_TYPE_DEF(Path);
      extern PyTypeObject *PY_TYPE(Path);

      class t_Path {
      public:
        PyObject_HEAD
        Path object;
        static PyObject *wrap_Object(const Path&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
