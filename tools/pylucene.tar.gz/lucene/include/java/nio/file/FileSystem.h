#ifndef java_nio_file_FileSystem_H
#define java_nio_file_FileSystem_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Iterable;
    class Class;
    class String;
  }
  namespace nio {
    namespace file {
      class WatchService;
      class Path;
      class PathMatcher;
      class FileStore;
    }
  }
  namespace util {
    class Set;
  }
  namespace io {
    class IOException;
    class Closeable;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class FileSystem : public ::java::lang::Object {
       public:
        enum {
          mid_close_a5783a25d44ba15b,
          mid_getFileStores_11d5ff4dd41a57b7,
          mid_getPath_43f8dfa47b5ba8e1,
          mid_getPathMatcher_d802433e886f0dfa,
          mid_getRootDirectories_11d5ff4dd41a57b7,
          mid_getSeparator_cb1e3f35ce7b2bd1,
          mid_isOpen_201fceb6e9f1d0c5,
          mid_isReadOnly_201fceb6e9f1d0c5,
          mid_newWatchService_6bbd3ec6ccaf7dcd,
          mid_supportedFileAttributeViews_9cfd5750b6ef4685,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit FileSystem(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        FileSystem(const FileSystem& obj) : ::java::lang::Object(obj) {}

        void close() const;
        ::java::lang::Iterable getFileStores() const;
        ::java::nio::file::Path getPath(const ::java::lang::String &, const JArray< ::java::lang::String > &) const;
        ::java::nio::file::PathMatcher getPathMatcher(const ::java::lang::String &) const;
        ::java::lang::Iterable getRootDirectories() const;
        ::java::lang::String getSeparator() const;
        jboolean isOpen() const;
        jboolean isReadOnly() const;
        ::java::nio::file::WatchService newWatchService() const;
        ::java::util::Set supportedFileAttributeViews() const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      extern PyType_Def PY_TYPE_DEF(FileSystem);
      extern PyTypeObject *PY_TYPE(FileSystem);

      class t_FileSystem {
      public:
        PyObject_HEAD
        FileSystem object;
        static PyObject *wrap_Object(const FileSystem&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
