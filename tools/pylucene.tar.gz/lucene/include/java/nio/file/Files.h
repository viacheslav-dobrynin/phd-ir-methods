#ifndef java_nio_file_Files_H
#define java_nio_file_Files_H

#include "java/lang/Object.h"

namespace java {
  namespace nio {
    namespace file {
      class DirectoryStream$Filter;
      class FileVisitOption;
      class FileVisitor;
      class LinkOption;
      class CopyOption;
      class Path;
      class OpenOption;
      class DirectoryStream;
      class FileStore;
    }
  }
  namespace io {
    class BufferedWriter;
    class OutputStream;
    class InputStream;
    class IOException;
    class BufferedReader;
  }
  namespace lang {
    class Class;
    class String;
    class Iterable;
    class CharSequence;
  }
  namespace util {
    class List;
    class Map;
    class Set;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class Files : public ::java::lang::Object {
       public:
        enum {
          mid_copy_2846e90bdb4353c5,
          mid_copy_4c1d25f70bccd0f8,
          mid_copy_b17e51dfe8d0bbb9,
          mid_createLink_c18d5b49641aa664,
          mid_delete_ab573029d133d065,
          mid_deleteIfExists_ca4608581a507acd,
          mid_exists_ad283180998787e1,
          mid_getAttribute_44262c910e51b4eb,
          mid_getFileStore_6ade0b091b3ca992,
          mid_isDirectory_ad283180998787e1,
          mid_isExecutable_ca4608581a507acd,
          mid_isHidden_ca4608581a507acd,
          mid_isReadable_ca4608581a507acd,
          mid_isRegularFile_ad283180998787e1,
          mid_isSameFile_fd840fcfa4041c3e,
          mid_isSymbolicLink_ca4608581a507acd,
          mid_isWritable_ca4608581a507acd,
          mid_mismatch_f32e9533e41959c2,
          mid_move_b17e51dfe8d0bbb9,
          mid_newBufferedReader_8beeafdb2fb2733a,
          mid_newBufferedWriter_8069318b5346fef5,
          mid_newDirectoryStream_ce5c7d297cb479a9,
          mid_newDirectoryStream_68590f7a6c709c25,
          mid_newDirectoryStream_d74dbe1833b92673,
          mid_newInputStream_3e4dca14f3227f1d,
          mid_newOutputStream_d71f4ccc074b05e8,
          mid_notExists_ad283180998787e1,
          mid_probeContentType_89fa8cc750c027a6,
          mid_readAllBytes_4c56e5f5ba29522d,
          mid_readAllLines_1826dd244796ac52,
          mid_readAttributes_94cf2859e2434749,
          mid_readString_89fa8cc750c027a6,
          mid_readSymbolicLink_020217e8a7d8d1cd,
          mid_setAttribute_7f57fee62de89cff,
          mid_size_469a40d43cf2e77c,
          mid_walkFileTree_11dcdb0dc8126162,
          mid_walkFileTree_6d4e9f6e9b8abd10,
          mid_write_14ac3edeca932a32,
          mid_write_33aa5f977f123204,
          mid_writeString_3ddcb2d9e372547b,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit Files(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        Files(const Files& obj) : ::java::lang::Object(obj) {}

        static jlong copy(const ::java::nio::file::Path &, const ::java::io::OutputStream &);
        static jlong copy(const ::java::io::InputStream &, const ::java::nio::file::Path &, const JArray< ::java::nio::file::CopyOption > &);
        static ::java::nio::file::Path copy(const ::java::nio::file::Path &, const ::java::nio::file::Path &, const JArray< ::java::nio::file::CopyOption > &);
        static ::java::nio::file::Path createLink(const ::java::nio::file::Path &, const ::java::nio::file::Path &);
        static void delete$(const ::java::nio::file::Path &);
        static jboolean deleteIfExists(const ::java::nio::file::Path &);
        static jboolean exists(const ::java::nio::file::Path &, const JArray< ::java::nio::file::LinkOption > &);
        static ::java::lang::Object getAttribute(const ::java::nio::file::Path &, const ::java::lang::String &, const JArray< ::java::nio::file::LinkOption > &);
        static ::java::nio::file::FileStore getFileStore(const ::java::nio::file::Path &);
        static jboolean isDirectory(const ::java::nio::file::Path &, const JArray< ::java::nio::file::LinkOption > &);
        static jboolean isExecutable(const ::java::nio::file::Path &);
        static jboolean isHidden(const ::java::nio::file::Path &);
        static jboolean isReadable(const ::java::nio::file::Path &);
        static jboolean isRegularFile(const ::java::nio::file::Path &, const JArray< ::java::nio::file::LinkOption > &);
        static jboolean isSameFile(const ::java::nio::file::Path &, const ::java::nio::file::Path &);
        static jboolean isSymbolicLink(const ::java::nio::file::Path &);
        static jboolean isWritable(const ::java::nio::file::Path &);
        static jlong mismatch(const ::java::nio::file::Path &, const ::java::nio::file::Path &);
        static ::java::nio::file::Path move(const ::java::nio::file::Path &, const ::java::nio::file::Path &, const JArray< ::java::nio::file::CopyOption > &);
        static ::java::io::BufferedReader newBufferedReader(const ::java::nio::file::Path &);
        static ::java::io::BufferedWriter newBufferedWriter(const ::java::nio::file::Path &, const JArray< ::java::nio::file::OpenOption > &);
        static ::java::nio::file::DirectoryStream newDirectoryStream(const ::java::nio::file::Path &);
        static ::java::nio::file::DirectoryStream newDirectoryStream(const ::java::nio::file::Path &, const ::java::lang::String &);
        static ::java::nio::file::DirectoryStream newDirectoryStream(const ::java::nio::file::Path &, const ::java::nio::file::DirectoryStream$Filter &);
        static ::java::io::InputStream newInputStream(const ::java::nio::file::Path &, const JArray< ::java::nio::file::OpenOption > &);
        static ::java::io::OutputStream newOutputStream(const ::java::nio::file::Path &, const JArray< ::java::nio::file::OpenOption > &);
        static jboolean notExists(const ::java::nio::file::Path &, const JArray< ::java::nio::file::LinkOption > &);
        static ::java::lang::String probeContentType(const ::java::nio::file::Path &);
        static JArray< jbyte > readAllBytes(const ::java::nio::file::Path &);
        static ::java::util::List readAllLines(const ::java::nio::file::Path &);
        static ::java::util::Map readAttributes(const ::java::nio::file::Path &, const ::java::lang::String &, const JArray< ::java::nio::file::LinkOption > &);
        static ::java::lang::String readString(const ::java::nio::file::Path &);
        static ::java::nio::file::Path readSymbolicLink(const ::java::nio::file::Path &);
        static ::java::nio::file::Path setAttribute(const ::java::nio::file::Path &, const ::java::lang::String &, const ::java::lang::Object &, const JArray< ::java::nio::file::LinkOption > &);
        static jlong size(const ::java::nio::file::Path &);
        static ::java::nio::file::Path walkFileTree(const ::java::nio::file::Path &, const ::java::nio::file::FileVisitor &);
        static ::java::nio::file::Path walkFileTree(const ::java::nio::file::Path &, const ::java::util::Set &, jint, const ::java::nio::file::FileVisitor &);
        static ::java::nio::file::Path write(const ::java::nio::file::Path &, const JArray< jbyte > &, const JArray< ::java::nio::file::OpenOption > &);
        static ::java::nio::file::Path write(const ::java::nio::file::Path &, const ::java::lang::Iterable &, const JArray< ::java::nio::file::OpenOption > &);
        static ::java::nio::file::Path writeString(const ::java::nio::file::Path &, const ::java::lang::CharSequence &, const JArray< ::java::nio::file::OpenOption > &);
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      extern PyType_Def PY_TYPE_DEF(Files);
      extern PyTypeObject *PY_TYPE(Files);

      class t_Files {
      public:
        PyObject_HEAD
        Files object;
        static PyObject *wrap_Object(const Files&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
