#ifndef java_nio_file_FileStore_H
#define java_nio_file_FileStore_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class FileStore : public ::java::lang::Object {
       public:
        enum {
          mid_getAttribute_374166fc5538a93c,
          mid_getBlockSize_d192af3db8896a5e,
          mid_getTotalSpace_d192af3db8896a5e,
          mid_getUnallocatedSpace_d192af3db8896a5e,
          mid_getUsableSpace_d192af3db8896a5e,
          mid_isReadOnly_201fceb6e9f1d0c5,
          mid_name_cb1e3f35ce7b2bd1,
          mid_supportsFileAttributeView_7585662e3a5cb869,
          mid_type_cb1e3f35ce7b2bd1,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit FileStore(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        FileStore(const FileStore& obj) : ::java::lang::Object(obj) {}

        ::java::lang::Object getAttribute(const ::java::lang::String &) const;
        jlong getBlockSize() const;
        jlong getTotalSpace() const;
        jlong getUnallocatedSpace() const;
        jlong getUsableSpace() const;
        jboolean isReadOnly() const;
        ::java::lang::String name() const;
        jboolean supportsFileAttributeView(const ::java::lang::String &) const;
        ::java::lang::String type() const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      extern PyType_Def PY_TYPE_DEF(FileStore);
      extern PyTypeObject *PY_TYPE(FileStore);

      class t_FileStore {
      public:
        PyObject_HEAD
        FileStore object;
        static PyObject *wrap_Object(const FileStore&);
        static PyObject *wrap_jobject(const jobject&);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
