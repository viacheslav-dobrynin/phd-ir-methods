#ifndef java_nio_file_WatchEvent_H
#define java_nio_file_WatchEvent_H

#include "java/lang/Object.h"

namespace java {
  namespace nio {
    namespace file {
      class WatchEvent$Kind;
    }
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace nio {
    namespace file {

      class WatchEvent : public ::java::lang::Object {
       public:
        enum {
          mid_context_1543ec1f1674e5aa,
          mid_count_f03edc6a210ac78c,
          mid_kind_65844cd0aa653e8a,
          max_mid
        };

        static ::java::lang::Class *class$;
        static jmethodID *mids$;
        static bool live$;
        static jclass initializeClass(bool);

        explicit WatchEvent(jobject obj) : ::java::lang::Object(obj) {
          if (obj != NULL && mids$ == NULL)
            env->getClass(initializeClass);
        }
        WatchEvent(const WatchEvent& obj) : ::java::lang::Object(obj) {}

        ::java::lang::Object context() const;
        jint count() const;
        ::java::nio::file::WatchEvent$Kind kind() const;
      };
    }
  }
}

#include <Python.h>

namespace java {
  namespace nio {
    namespace file {
      extern PyType_Def PY_TYPE_DEF(WatchEvent);
      extern PyTypeObject *PY_TYPE(WatchEvent);

      class t_WatchEvent {
      public:
        PyObject_HEAD
        WatchEvent object;
        PyTypeObject *parameters[1];
        static PyTypeObject **parameters_(t_WatchEvent *self)
        {
          return (PyTypeObject **) &(self->parameters);
        }
        static PyObject *wrap_Object(const WatchEvent&);
        static PyObject *wrap_jobject(const jobject&);
        static PyObject *wrap_Object(const WatchEvent&, PyTypeObject *);
        static PyObject *wrap_jobject(const jobject&, PyTypeObject *);
        static void install(PyObject *module);
        static void initialize(PyObject *module);
      };
    }
  }
}

#endif
