#ifndef java_io_PrintWriter_H
#define java_io_PrintWriter_H

#include "java/io/Writer.h"

namespace java {
  namespace io {
    class OutputStream;
    class UnsupportedEncodingException;
    class PrintWriter;
    class FileNotFoundException;
    class File;
  }
  namespace lang {
    class Class;
    class String;
    class Object;
    class CharSequence;
  }
  namespace util {
    class Locale;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class PrintWriter : public ::java::io::Writer {
     public:
      enum {
        mid_init$_e5acd9fd0b5c2db4,
        mid_init$_8fb87594300dbff6,
        mid_init$_492bde69d2f2f8d4,
        mid_init$_9b22ecdee06ea23c,
        mid_init$_ee89b727d2da3a1e,
        mid_init$_56d5ffc79e73287a,
        mid_init$_b8ed6908372bc1da,
        mid_init$_ac456d19ec1753af,
        mid_append_0a8843ec231796d6,
        mid_append_13a85d9db0d047da,
        mid_append_bb58e2a333da9ab4,
        mid_checkError_201fceb6e9f1d0c5,
        mid_close_a5783a25d44ba15b,
        mid_flush_a5783a25d44ba15b,
        mid_format_d6774d57a7dab7c5,
        mid_format_d861bb7c205ac4fa,
        mid_print_ce2f97877c2b0911,
        mid_print_9b22ecdee06ea23c,
        mid_print_a5b6a940fc16c6a1,
        mid_print_e1cbe4391c5d21d7,
        mid_print_44052de370ab2f98,
        mid_print_d35827da2088dce4,
        mid_print_8730ba9dfaf23a7b,
        mid_print_e391a919b9e60fbb,
        mid_print_270332bbfd4dc523,
        mid_printf_d6774d57a7dab7c5,
        mid_printf_d861bb7c205ac4fa,
        mid_println_a5783a25d44ba15b,
        mid_println_ce2f97877c2b0911,
        mid_println_9b22ecdee06ea23c,
        mid_println_a5b6a940fc16c6a1,
        mid_println_e1cbe4391c5d21d7,
        mid_println_44052de370ab2f98,
        mid_println_d35827da2088dce4,
        mid_println_8730ba9dfaf23a7b,
        mid_println_e391a919b9e60fbb,
        mid_println_270332bbfd4dc523,
        mid_write_ce2f97877c2b0911,
        mid_write_9b22ecdee06ea23c,
        mid_write_8730ba9dfaf23a7b,
        mid_write_4640b6b0a50abfea,
        mid_write_c2bf4661cd634ee6,
        mid_setError_a5783a25d44ba15b,
        mid_clearError_a5783a25d44ba15b,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit PrintWriter(jobject obj) : ::java::io::Writer(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      PrintWriter(const PrintWriter& obj) : ::java::io::Writer(obj) {}

      PrintWriter(const ::java::io::File &);
      PrintWriter(const ::java::io::OutputStream &);
      PrintWriter(const ::java::io::Writer &);
      PrintWriter(const ::java::lang::String &);
      PrintWriter(const ::java::io::File &, const ::java::lang::String &);
      PrintWriter(const ::java::lang::String &, const ::java::lang::String &);
      PrintWriter(const ::java::io::OutputStream &, jboolean);
      PrintWriter(const ::java::io::Writer &, jboolean);

      PrintWriter append(jchar) const;
      PrintWriter append(const ::java::lang::CharSequence &) const;
      PrintWriter append(const ::java::lang::CharSequence &, jint, jint) const;
      jboolean checkError() const;
      void close() const;
      void flush() const;
      PrintWriter format(const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      PrintWriter format(const ::java::util::Locale &, const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      void print(const JArray< jchar > &) const;
      void print(const ::java::lang::String &) const;
      void print(jboolean) const;
      void print(jchar) const;
      void print(jdouble) const;
      void print(jfloat) const;
      void print(jint) const;
      void print(const ::java::lang::Object &) const;
      void print(jlong) const;
      PrintWriter printf(const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      PrintWriter printf(const ::java::util::Locale &, const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      void println() const;
      void println(const JArray< jchar > &) const;
      void println(const ::java::lang::String &) const;
      void println(jboolean) const;
      void println(jchar) const;
      void println(jdouble) const;
      void println(jfloat) const;
      void println(jint) const;
      void println(const ::java::lang::Object &) const;
      void println(jlong) const;
      void write(const JArray< jchar > &) const;
      void write(const ::java::lang::String &) const;
      void write(jint) const;
      void write(const JArray< jchar > &, jint, jint) const;
      void write(const ::java::lang::String &, jint, jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    extern PyType_Def PY_TYPE_DEF(PrintWriter);
    extern PyTypeObject *PY_TYPE(PrintWriter);

    class t_PrintWriter {
    public:
      PyObject_HEAD
      PrintWriter object;
      static PyObject *wrap_Object(const PrintWriter&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
