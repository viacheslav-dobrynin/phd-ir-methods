#ifndef java_io_PrintStream_H
#define java_io_PrintStream_H

#include "java/io/FilterOutputStream.h"

namespace java {
  namespace io {
    class OutputStream;
    class UnsupportedEncodingException;
    class IOException;
    class PrintStream;
    class FileNotFoundException;
    class File;
  }
  namespace lang {
    class Class;
    class String;
    class Object;
    class CharSequence;
    class Appendable;
  }
  namespace util {
    class Locale;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class PrintStream : public ::java::io::FilterOutputStream {
     public:
      enum {
        mid_init$_e5acd9fd0b5c2db4,
        mid_init$_8fb87594300dbff6,
        mid_init$_9b22ecdee06ea23c,
        mid_init$_ee89b727d2da3a1e,
        mid_init$_56d5ffc79e73287a,
        mid_init$_b8ed6908372bc1da,
        mid_init$_adf14561be2b7e53,
        mid_append_c0a3315e1b7176a1,
        mid_append_3f775ed50ebce71d,
        mid_append_9e347ea3e731ccf7,
        mid_checkError_201fceb6e9f1d0c5,
        mid_close_a5783a25d44ba15b,
        mid_flush_a5783a25d44ba15b,
        mid_format_e8efcb4a03717979,
        mid_format_bd400ee5cc5e0c21,
        mid_print_ce2f97877c2b0911,
        mid_print_9b22ecdee06ea23c,
        mid_print_a5b6a940fc16c6a1,
        mid_print_e1cbe4391c5d21d7,
        mid_print_44052de370ab2f98,
        mid_print_d35827da2088dce4,
        mid_print_8730ba9dfaf23a7b,
        mid_print_e391a919b9e60fbb,
        mid_print_270332bbfd4dc523,
        mid_printf_e8efcb4a03717979,
        mid_printf_bd400ee5cc5e0c21,
        mid_println_a5783a25d44ba15b,
        mid_println_ce2f97877c2b0911,
        mid_println_9b22ecdee06ea23c,
        mid_println_a5b6a940fc16c6a1,
        mid_println_e1cbe4391c5d21d7,
        mid_println_44052de370ab2f98,
        mid_println_d35827da2088dce4,
        mid_println_8730ba9dfaf23a7b,
        mid_println_e391a919b9e60fbb,
        mid_println_270332bbfd4dc523,
        mid_write_5cb5ede3b794e9e0,
        mid_write_8730ba9dfaf23a7b,
        mid_write_c2a753a75ddc609c,
        mid_writeBytes_5cb5ede3b794e9e0,
        mid_setError_a5783a25d44ba15b,
        mid_clearError_a5783a25d44ba15b,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit PrintStream(jobject obj) : ::java::io::FilterOutputStream(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      PrintStream(const PrintStream& obj) : ::java::io::FilterOutputStream(obj) {}

      PrintStream(const ::java::io::File &);
      PrintStream(const ::java::io::OutputStream &);
      PrintStream(const ::java::lang::String &);
      PrintStream(const ::java::io::File &, const ::java::lang::String &);
      PrintStream(const ::java::lang::String &, const ::java::lang::String &);
      PrintStream(const ::java::io::OutputStream &, jboolean);
      PrintStream(const ::java::io::OutputStream &, jboolean, const ::java::lang::String &);

      PrintStream append(jchar) const;
      PrintStream append(const ::java::lang::CharSequence &) const;
      PrintStream append(const ::java::lang::CharSequence &, jint, jint) const;
      jboolean checkError() const;
      void close() const;
      void flush() const;
      PrintStream format(const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      PrintStream format(const ::java::util::Locale &, const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      void print(const JArray< jchar > &) const;
      void print(const ::java::lang::String &) const;
      void print(jboolean) const;
      void print(jchar) const;
      void print(jdouble) const;
      void print(jfloat) const;
      void print(jint) const;
      void print(const ::java::lang::Object &) const;
      void print(jlong) const;
      PrintStream printf(const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      PrintStream printf(const ::java::util::Locale &, const ::java::lang::String &, const JArray< ::java::lang::Object > &) const;
      void println() const;
      void println(const JArray< jchar > &) const;
      void println(const ::java::lang::String &) const;
      void println(jboolean) const;
      void println(jchar) const;
      void println(jdouble) const;
      void println(jfloat) const;
      void println(jint) const;
      void println(const ::java::lang::Object &) const;
      void println(jlong) const;
      void write(const JArray< jbyte > &) const;
      void write(jint) const;
      void write(const JArray< jbyte > &, jint, jint) const;
      void writeBytes(const JArray< jbyte > &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    extern PyType_Def PY_TYPE_DEF(PrintStream);
    extern PyTypeObject *PY_TYPE(PrintStream);

    class t_PrintStream {
    public:
      PyObject_HEAD
      PrintStream object;
      static PyObject *wrap_Object(const PrintStream&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
