#ifndef java_io_InputStream_H
#define java_io_InputStream_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class OutputStream;
    class IOException;
    class Closeable;
    class InputStream;
  }
  namespace lang {
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class InputStream : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_available_f03edc6a210ac78c,
        mid_close_a5783a25d44ba15b,
        mid_mark_8730ba9dfaf23a7b,
        mid_markSupported_201fceb6e9f1d0c5,
        mid_nullInputStream_84a16f85c5c7542b,
        mid_read_f03edc6a210ac78c,
        mid_read_68e5ded3d63ae943,
        mid_read_7ec49c5eb7254927,
        mid_readAllBytes_9d49388b39cc642b,
        mid_readNBytes_c64573f38e8a66b0,
        mid_readNBytes_7ec49c5eb7254927,
        mid_reset_a5783a25d44ba15b,
        mid_skip_05d16795c0d6059e,
        mid_skipNBytes_270332bbfd4dc523,
        mid_transferTo_f49fd0f1191f4a7f,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit InputStream(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      InputStream(const InputStream& obj) : ::java::lang::Object(obj) {}

      InputStream();

      jint available() const;
      void close() const;
      void mark(jint) const;
      jboolean markSupported() const;
      static InputStream nullInputStream();
      jint read() const;
      jint read(const JArray< jbyte > &) const;
      jint read(const JArray< jbyte > &, jint, jint) const;
      JArray< jbyte > readAllBytes() const;
      JArray< jbyte > readNBytes(jint) const;
      jint readNBytes(const JArray< jbyte > &, jint, jint) const;
      void reset() const;
      jlong skip(jlong) const;
      void skipNBytes(jlong) const;
      jlong transferTo(const ::java::io::OutputStream &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    extern PyType_Def PY_TYPE_DEF(InputStream);
    extern PyTypeObject *PY_TYPE(InputStream);

    class t_InputStream {
    public:
      PyObject_HEAD
      InputStream object;
      static PyObject *wrap_Object(const InputStream&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
