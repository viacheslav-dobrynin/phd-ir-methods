#ifndef java_io_File_H
#define java_io_File_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class FileFilter;
    class IOException;
    class Serializable;
    class FilenameFilter;
    class File;
  }
  namespace lang {
    class Comparable;
    class Class;
    class String;
  }
  namespace nio {
    namespace file {
      class Path;
    }
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class File : public ::java::lang::Object {
     public:
      enum {
        mid_init$_9b22ecdee06ea23c,
        mid_init$_ee89b727d2da3a1e,
        mid_init$_56d5ffc79e73287a,
        mid_canExecute_201fceb6e9f1d0c5,
        mid_canRead_201fceb6e9f1d0c5,
        mid_canWrite_201fceb6e9f1d0c5,
        mid_compareTo_368c716a0b9bd4d3,
        mid_createNewFile_201fceb6e9f1d0c5,
        mid_createTempFile_f0c49af4e48c061b,
        mid_createTempFile_3426dfb5d047353f,
        mid_delete_201fceb6e9f1d0c5,
        mid_deleteOnExit_a5783a25d44ba15b,
        mid_equals_2a09f73f0549554f,
        mid_exists_201fceb6e9f1d0c5,
        mid_getAbsoluteFile_b557e19cb184383f,
        mid_getAbsolutePath_cb1e3f35ce7b2bd1,
        mid_getCanonicalFile_b557e19cb184383f,
        mid_getCanonicalPath_cb1e3f35ce7b2bd1,
        mid_getFreeSpace_d192af3db8896a5e,
        mid_getName_cb1e3f35ce7b2bd1,
        mid_getParent_cb1e3f35ce7b2bd1,
        mid_getParentFile_b557e19cb184383f,
        mid_getPath_cb1e3f35ce7b2bd1,
        mid_getTotalSpace_d192af3db8896a5e,
        mid_getUsableSpace_d192af3db8896a5e,
        mid_hashCode_f03edc6a210ac78c,
        mid_isAbsolute_201fceb6e9f1d0c5,
        mid_isDirectory_201fceb6e9f1d0c5,
        mid_isFile_201fceb6e9f1d0c5,
        mid_isHidden_201fceb6e9f1d0c5,
        mid_lastModified_d192af3db8896a5e,
        mid_length_d192af3db8896a5e,
        mid_list_c0724ba8b8f42824,
        mid_list_008d99991e7df756,
        mid_listFiles_096d83ab68be140b,
        mid_listFiles_1b0d2378555d5196,
        mid_listFiles_72abc5e1dd139285,
        mid_listRoots_096d83ab68be140b,
        mid_mkdir_201fceb6e9f1d0c5,
        mid_mkdirs_201fceb6e9f1d0c5,
        mid_renameTo_23bbcac359797842,
        mid_setExecutable_babb0003dbd8064f,
        mid_setExecutable_8712fceaa0de33c9,
        mid_setLastModified_f3b2890c43e7ff3f,
        mid_setReadOnly_201fceb6e9f1d0c5,
        mid_setReadable_babb0003dbd8064f,
        mid_setReadable_8712fceaa0de33c9,
        mid_setWritable_babb0003dbd8064f,
        mid_setWritable_8712fceaa0de33c9,
        mid_toPath_bd4213659d0d079d,
        mid_toString_cb1e3f35ce7b2bd1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit File(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      File(const File& obj) : ::java::lang::Object(obj) {}

      static ::java::lang::String *pathSeparator;
      static jchar pathSeparatorChar;
      static ::java::lang::String *separator;
      static jchar separatorChar;

      File(const ::java::lang::String &);
      File(const File &, const ::java::lang::String &);
      File(const ::java::lang::String &, const ::java::lang::String &);

      jboolean canExecute() const;
      jboolean canRead() const;
      jboolean canWrite() const;
      jint compareTo(const File &) const;
      jboolean createNewFile() const;
      static File createTempFile(const ::java::lang::String &, const ::java::lang::String &);
      static File createTempFile(const ::java::lang::String &, const ::java::lang::String &, const File &);
      jboolean delete$() const;
      void deleteOnExit() const;
      jboolean equals(const ::java::lang::Object &) const;
      jboolean exists() const;
      File getAbsoluteFile() const;
      ::java::lang::String getAbsolutePath() const;
      File getCanonicalFile() const;
      ::java::lang::String getCanonicalPath() const;
      jlong getFreeSpace() const;
      ::java::lang::String getName() const;
      ::java::lang::String getParent() const;
      File getParentFile() const;
      ::java::lang::String getPath() const;
      jlong getTotalSpace() const;
      jlong getUsableSpace() const;
      jint hashCode() const;
      jboolean isAbsolute() const;
      jboolean isDirectory() const;
      jboolean isFile() const;
      jboolean isHidden() const;
      jlong lastModified() const;
      jlong length() const;
      JArray< ::java::lang::String > list() const;
      JArray< ::java::lang::String > list(const ::java::io::FilenameFilter &) const;
      JArray< File > listFiles() const;
      JArray< File > listFiles(const ::java::io::FileFilter &) const;
      JArray< File > listFiles(const ::java::io::FilenameFilter &) const;
      static JArray< File > listRoots();
      jboolean mkdir() const;
      jboolean mkdirs() const;
      jboolean renameTo(const File &) const;
      jboolean setExecutable(jboolean) const;
      jboolean setExecutable(jboolean, jboolean) const;
      jboolean setLastModified(jlong) const;
      jboolean setReadOnly() const;
      jboolean setReadable(jboolean) const;
      jboolean setReadable(jboolean, jboolean) const;
      jboolean setWritable(jboolean) const;
      jboolean setWritable(jboolean, jboolean) const;
      ::java::nio::file::Path toPath() const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    extern PyType_Def PY_TYPE_DEF(File);
    extern PyTypeObject *PY_TYPE(File);

    class t_File {
    public:
      PyObject_HEAD
      File object;
      static PyObject *wrap_Object(const File&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
