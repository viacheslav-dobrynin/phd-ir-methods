#ifndef java_io_DataInput_H
#define java_io_DataInput_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class String;
    class Class;
  }
  namespace io {
    class IOException;
  }
}
template<class T> class JArray;

namespace java {
  namespace io {

    class DataInput : public ::java::lang::Object {
     public:
      enum {
        mid_readBoolean_201fceb6e9f1d0c5,
        mid_readByte_d6f5e90da65461cb,
        mid_readChar_24245e691763b30a,
        mid_readDouble_a6c1144f51bd8892,
        mid_readFloat_a9dac2c40463ba96,
        mid_readFully_5cb5ede3b794e9e0,
        mid_readFully_c2a753a75ddc609c,
        mid_readInt_f03edc6a210ac78c,
        mid_readLine_cb1e3f35ce7b2bd1,
        mid_readLong_d192af3db8896a5e,
        mid_readShort_322e7f113b6f2d2a,
        mid_readUTF_cb1e3f35ce7b2bd1,
        mid_readUnsignedByte_f03edc6a210ac78c,
        mid_readUnsignedShort_f03edc6a210ac78c,
        mid_skipBytes_ff66fe240ad72894,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit DataInput(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      DataInput(const DataInput& obj) : ::java::lang::Object(obj) {}

      jboolean readBoolean() const;
      jbyte readByte() const;
      jchar readChar() const;
      jdouble readDouble() const;
      jfloat readFloat() const;
      void readFully(const JArray< jbyte > &) const;
      void readFully(const JArray< jbyte > &, jint, jint) const;
      jint readInt() const;
      ::java::lang::String readLine() const;
      jlong readLong() const;
      jshort readShort() const;
      ::java::lang::String readUTF() const;
      jint readUnsignedByte() const;
      jint readUnsignedShort() const;
      jint skipBytes(jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace io {
    extern PyType_Def PY_TYPE_DEF(DataInput);
    extern PyTypeObject *PY_TYPE(DataInput);

    class t_DataInput {
    public:
      PyObject_HEAD
      DataInput object;
      static PyObject *wrap_Object(const DataInput&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
