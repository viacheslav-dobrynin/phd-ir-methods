#ifndef java_lang_Runtime_H
#define java_lang_Runtime_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Runtime$Version;
    class Process;
    class Runtime;
    class Thread;
  }
  namespace io {
    class IOException;
    class File;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Runtime : public ::java::lang::Object {
     public:
      enum {
        mid_addShutdownHook_50a064a6cccf8c46,
        mid_availableProcessors_f03edc6a210ac78c,
        mid_exec_eb1c130e089e09c5,
        mid_exec_2730887864dd9f0d,
        mid_exec_ad41be9a57d13175,
        mid_exec_14bc12950615403c,
        mid_exec_2c2b663bdf01cee2,
        mid_exec_777326c8777168f2,
        mid_exit_8730ba9dfaf23a7b,
        mid_freeMemory_d192af3db8896a5e,
        mid_gc_a5783a25d44ba15b,
        mid_getRuntime_86ec08444fb74730,
        mid_halt_8730ba9dfaf23a7b,
        mid_load_9b22ecdee06ea23c,
        mid_loadLibrary_9b22ecdee06ea23c,
        mid_maxMemory_d192af3db8896a5e,
        mid_removeShutdownHook_cdbf28f38eb4fc4c,
        mid_runFinalization_a5783a25d44ba15b,
        mid_totalMemory_d192af3db8896a5e,
        mid_version_3eac62d863e9bc91,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Runtime(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Runtime(const Runtime& obj) : ::java::lang::Object(obj) {}

      void addShutdownHook(const ::java::lang::Thread &) const;
      jint availableProcessors() const;
      ::java::lang::Process exec(const JArray< ::java::lang::String > &) const;
      ::java::lang::Process exec(const ::java::lang::String &) const;
      ::java::lang::Process exec(const JArray< ::java::lang::String > &, const JArray< ::java::lang::String > &) const;
      ::java::lang::Process exec(const ::java::lang::String &, const JArray< ::java::lang::String > &) const;
      ::java::lang::Process exec(const JArray< ::java::lang::String > &, const JArray< ::java::lang::String > &, const ::java::io::File &) const;
      ::java::lang::Process exec(const ::java::lang::String &, const JArray< ::java::lang::String > &, const ::java::io::File &) const;
      void exit(jint) const;
      jlong freeMemory() const;
      void gc() const;
      static Runtime getRuntime();
      void halt(jint) const;
      void load(const ::java::lang::String &) const;
      void loadLibrary(const ::java::lang::String &) const;
      jlong maxMemory() const;
      jboolean removeShutdownHook(const ::java::lang::Thread &) const;
      void runFinalization() const;
      jlong totalMemory() const;
      static ::java::lang::Runtime$Version version();
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Runtime);
    extern PyTypeObject *PY_TYPE(Runtime);

    class t_Runtime {
    public:
      PyObject_HEAD
      Runtime object;
      static PyObject *wrap_Object(const Runtime&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
