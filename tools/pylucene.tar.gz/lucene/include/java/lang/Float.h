#ifndef java_lang_Float_H
#define java_lang_Float_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class NumberFormatException;
    class Comparable;
    class Float;
    class Class;
    class String;
    class Object;
  }
  namespace util {
    class Optional;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Float : public ::java::lang::Number {
     public:
      enum {
        mid_init$_9b22ecdee06ea23c,
        mid_init$_44052de370ab2f98,
        mid_init$_d35827da2088dce4,
        mid_byteValue_d6f5e90da65461cb,
        mid_compare_5d64a6c7a03d374e,
        mid_compareTo_535b65b12709ee4c,
        mid_describeConstable_5dfa6fdc4ec946c6,
        mid_doubleValue_a6c1144f51bd8892,
        mid_equals_2a09f73f0549554f,
        mid_float16ToFloat_ebdb37ea9540a7c1,
        mid_floatToFloat16_cb0c8c2a2c7f4cc7,
        mid_floatToIntBits_182381c5f92fac15,
        mid_floatToRawIntBits_182381c5f92fac15,
        mid_floatValue_a9dac2c40463ba96,
        mid_hashCode_f03edc6a210ac78c,
        mid_hashCode_182381c5f92fac15,
        mid_intBitsToFloat_774c70860a3c670a,
        mid_intValue_f03edc6a210ac78c,
        mid_isFinite_56b69284e0e60c87,
        mid_isInfinite_201fceb6e9f1d0c5,
        mid_isInfinite_56b69284e0e60c87,
        mid_isNaN_201fceb6e9f1d0c5,
        mid_isNaN_56b69284e0e60c87,
        mid_longValue_d192af3db8896a5e,
        mid_max_df897db0c936ccdb,
        mid_min_df897db0c936ccdb,
        mid_parseFloat_3fdd98ce35e9ea38,
        mid_shortValue_322e7f113b6f2d2a,
        mid_sum_df897db0c936ccdb,
        mid_toHexString_217cc04a7fe6b835,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_toString_217cc04a7fe6b835,
        mid_valueOf_18b8bbe9862c54d1,
        mid_valueOf_cb499542e171564f,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Float(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Float(const Float& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jint MAX_EXPONENT;
      static jfloat MAX_VALUE;
      static jint MIN_EXPONENT;
      static jfloat MIN_NORMAL;
      static jfloat MIN_VALUE;
      static jfloat NEGATIVE_INFINITY;
      static jfloat NaN;
      static jfloat POSITIVE_INFINITY;
      static jint PRECISION;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Float(const ::java::lang::String &);
      Float(jdouble);
      Float(jfloat);

      jbyte byteValue() const;
      static jint compare(jfloat, jfloat);
      jint compareTo(const Float &) const;
      ::java::util::Optional describeConstable() const;
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      static jfloat float16ToFloat(jshort);
      static jshort floatToFloat16(jfloat);
      static jint floatToIntBits(jfloat);
      static jint floatToRawIntBits(jfloat);
      jfloat floatValue() const;
      jint hashCode() const;
      static jint hashCode(jfloat);
      static jfloat intBitsToFloat(jint);
      jint intValue() const;
      static jboolean isFinite(jfloat);
      jboolean isInfinite() const;
      static jboolean isInfinite(jfloat);
      jboolean isNaN() const;
      static jboolean isNaN(jfloat);
      jlong longValue() const;
      static jfloat max$(jfloat, jfloat);
      static jfloat min$(jfloat, jfloat);
      static jfloat parseFloat(const ::java::lang::String &);
      jshort shortValue() const;
      static jfloat sum(jfloat, jfloat);
      static ::java::lang::String toHexString(jfloat);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jfloat);
      static Float valueOf(const ::java::lang::String &);
      static Float valueOf(jfloat);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Float);
    extern PyTypeObject *PY_TYPE(Float);

    class t_Float {
    public:
      PyObject_HEAD
      Float object;
      static PyObject *wrap_Object(const Float&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
