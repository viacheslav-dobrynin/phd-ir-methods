#ifndef java_lang_Long_H
#define java_lang_Long_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class NumberFormatException;
    class Comparable;
    class Class;
    class String;
    class Object;
    class CharSequence;
    class Long;
  }
  namespace util {
    class Optional;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Long : public ::java::lang::Number {
     public:
      enum {
        mid_init$_9b22ecdee06ea23c,
        mid_init$_270332bbfd4dc523,
        mid_bitCount_5d9f29daea117180,
        mid_byteValue_d6f5e90da65461cb,
        mid_compare_57fdd94a8d977536,
        mid_compareTo_7f394f67787b86b9,
        mid_compareUnsigned_57fdd94a8d977536,
        mid_compress_55c1d7897ea77ab7,
        mid_decode_a319769b4d3e91e9,
        mid_describeConstable_5dfa6fdc4ec946c6,
        mid_divideUnsigned_55c1d7897ea77ab7,
        mid_doubleValue_a6c1144f51bd8892,
        mid_equals_2a09f73f0549554f,
        mid_expand_55c1d7897ea77ab7,
        mid_floatValue_a9dac2c40463ba96,
        mid_getLong_a319769b4d3e91e9,
        mid_getLong_2c7ce99a0b8e5386,
        mid_getLong_1024d5034c8234ce,
        mid_hashCode_f03edc6a210ac78c,
        mid_hashCode_5d9f29daea117180,
        mid_highestOneBit_05d16795c0d6059e,
        mid_intValue_f03edc6a210ac78c,
        mid_longValue_d192af3db8896a5e,
        mid_lowestOneBit_05d16795c0d6059e,
        mid_max_55c1d7897ea77ab7,
        mid_min_55c1d7897ea77ab7,
        mid_numberOfLeadingZeros_5d9f29daea117180,
        mid_numberOfTrailingZeros_5d9f29daea117180,
        mid_parseLong_e62386a53b3682b5,
        mid_parseLong_a170e0ad577b47da,
        mid_parseLong_5598d0af9c197814,
        mid_parseUnsignedLong_e62386a53b3682b5,
        mid_parseUnsignedLong_a170e0ad577b47da,
        mid_parseUnsignedLong_5598d0af9c197814,
        mid_remainderUnsigned_55c1d7897ea77ab7,
        mid_reverse_05d16795c0d6059e,
        mid_reverseBytes_05d16795c0d6059e,
        mid_rotateLeft_50cd9420616ee352,
        mid_rotateRight_50cd9420616ee352,
        mid_shortValue_322e7f113b6f2d2a,
        mid_signum_5d9f29daea117180,
        mid_sum_55c1d7897ea77ab7,
        mid_toBinaryString_3bbdb48ea758edad,
        mid_toHexString_3bbdb48ea758edad,
        mid_toOctalString_3bbdb48ea758edad,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_toString_3bbdb48ea758edad,
        mid_toString_010b1b9273a75572,
        mid_toUnsignedString_3bbdb48ea758edad,
        mid_toUnsignedString_010b1b9273a75572,
        mid_valueOf_a319769b4d3e91e9,
        mid_valueOf_b1c387bd114a700a,
        mid_valueOf_4c8dbe2ef0737bc6,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Long(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Long(const Long& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jlong MAX_VALUE;
      static jlong MIN_VALUE;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Long(const ::java::lang::String &);
      Long(jlong);

      static jint bitCount(jlong);
      jbyte byteValue() const;
      static jint compare(jlong, jlong);
      jint compareTo(const Long &) const;
      static jint compareUnsigned(jlong, jlong);
      static jlong compress(jlong, jlong);
      static Long decode(const ::java::lang::String &);
      ::java::util::Optional describeConstable() const;
      static jlong divideUnsigned(jlong, jlong);
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      static jlong expand(jlong, jlong);
      jfloat floatValue() const;
      static Long getLong(const ::java::lang::String &);
      static Long getLong(const ::java::lang::String &, const Long &);
      static Long getLong(const ::java::lang::String &, jlong);
      jint hashCode() const;
      static jint hashCode(jlong);
      static jlong highestOneBit(jlong);
      jint intValue() const;
      jlong longValue() const;
      static jlong lowestOneBit(jlong);
      static jlong max$(jlong, jlong);
      static jlong min$(jlong, jlong);
      static jint numberOfLeadingZeros(jlong);
      static jint numberOfTrailingZeros(jlong);
      static jlong parseLong(const ::java::lang::String &);
      static jlong parseLong(const ::java::lang::String &, jint);
      static jlong parseLong(const ::java::lang::CharSequence &, jint, jint, jint);
      static jlong parseUnsignedLong(const ::java::lang::String &);
      static jlong parseUnsignedLong(const ::java::lang::String &, jint);
      static jlong parseUnsignedLong(const ::java::lang::CharSequence &, jint, jint, jint);
      static jlong remainderUnsigned(jlong, jlong);
      static jlong reverse(jlong);
      static jlong reverseBytes(jlong);
      static jlong rotateLeft(jlong, jint);
      static jlong rotateRight(jlong, jint);
      jshort shortValue() const;
      static jint signum(jlong);
      static jlong sum(jlong, jlong);
      static ::java::lang::String toBinaryString(jlong);
      static ::java::lang::String toHexString(jlong);
      static ::java::lang::String toOctalString(jlong);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jlong);
      static ::java::lang::String toString(jlong, jint);
      static ::java::lang::String toUnsignedString(jlong);
      static ::java::lang::String toUnsignedString(jlong, jint);
      static Long valueOf(const ::java::lang::String &);
      static Long valueOf(jlong);
      static Long valueOf(const ::java::lang::String &, jint);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Long);
    extern PyTypeObject *PY_TYPE(Long);

    class t_Long {
    public:
      PyObject_HEAD
      Long object;
      static PyObject *wrap_Object(const Long&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
