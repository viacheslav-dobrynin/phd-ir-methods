#ifndef java_lang_Package_H
#define java_lang_Package_H

#include "java/lang/NamedPackage.h"

namespace java {
  namespace lang {
    class String;
    class NumberFormatException;
    class Package;
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Package : public ::java::lang::NamedPackage {
     public:
      enum {
        mid_getImplementationTitle_cb1e3f35ce7b2bd1,
        mid_getImplementationVendor_cb1e3f35ce7b2bd1,
        mid_getImplementationVersion_cb1e3f35ce7b2bd1,
        mid_getName_cb1e3f35ce7b2bd1,
        mid_getPackage_f51db747fc427905,
        mid_getPackages_3e486c1526386594,
        mid_getSpecificationTitle_cb1e3f35ce7b2bd1,
        mid_getSpecificationVendor_cb1e3f35ce7b2bd1,
        mid_getSpecificationVersion_cb1e3f35ce7b2bd1,
        mid_hashCode_f03edc6a210ac78c,
        mid_isCompatibleWith_7585662e3a5cb869,
        mid_isSealed_201fceb6e9f1d0c5,
        mid_toString_cb1e3f35ce7b2bd1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Package(jobject obj) : ::java::lang::NamedPackage(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Package(const Package& obj) : ::java::lang::NamedPackage(obj) {}

      ::java::lang::String getImplementationTitle() const;
      ::java::lang::String getImplementationVendor() const;
      ::java::lang::String getImplementationVersion() const;
      ::java::lang::String getName() const;
      static Package getPackage(const ::java::lang::String &);
      static JArray< Package > getPackages();
      ::java::lang::String getSpecificationTitle() const;
      ::java::lang::String getSpecificationVendor() const;
      ::java::lang::String getSpecificationVersion() const;
      jint hashCode() const;
      jboolean isCompatibleWith(const ::java::lang::String &) const;
      jboolean isSealed() const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Package);
    extern PyTypeObject *PY_TYPE(Package);

    class t_Package {
    public:
      PyObject_HEAD
      Package object;
      static PyObject *wrap_Object(const Package&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
