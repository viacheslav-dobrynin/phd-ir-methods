#ifndef java_lang_Character_H
#define java_lang_Character_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Comparable;
    class Class;
    class String;
    class CharSequence;
    class Character;
    namespace constant {
      class DynamicConstantDesc;
    }
  }
  namespace io {
    class Serializable;
  }
  namespace util {
    class Optional;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Character : public ::java::lang::Object {
     public:
      enum {
        mid_init$_e1cbe4391c5d21d7,
        mid_charCount_ff66fe240ad72894,
        mid_charValue_24245e691763b30a,
        mid_codePointAt_abc216454363972e,
        mid_codePointAt_24b9dc4fd670275f,
        mid_codePointAt_1658d338643354c7,
        mid_codePointBefore_abc216454363972e,
        mid_codePointBefore_24b9dc4fd670275f,
        mid_codePointBefore_1658d338643354c7,
        mid_codePointCount_1658d338643354c7,
        mid_codePointCount_256c9e9a0323d13a,
        mid_codePointOf_164529de03d21944,
        mid_compare_01142bdbaea0bcb5,
        mid_compareTo_23e2f4c0b56b8919,
        mid_describeConstable_5dfa6fdc4ec946c6,
        mid_digit_a67575966f498b8d,
        mid_digit_103e4c7b2b508548,
        mid_equals_2a09f73f0549554f,
        mid_forDigit_90c821c42d5637bf,
        mid_getDirectionality_0a4cb5df2e9d0506,
        mid_getDirectionality_84ab8169028f033c,
        mid_getName_aebd86204175b724,
        mid_getNumericValue_199f0af5b2534fde,
        mid_getNumericValue_ff66fe240ad72894,
        mid_getType_199f0af5b2534fde,
        mid_getType_ff66fe240ad72894,
        mid_hashCode_f03edc6a210ac78c,
        mid_hashCode_199f0af5b2534fde,
        mid_highSurrogate_0b9831c04f367f5c,
        mid_isAlphabetic_12fe561dd4de11f3,
        mid_isBmpCodePoint_12fe561dd4de11f3,
        mid_isDefined_5ddad6b6ca6f5522,
        mid_isDefined_12fe561dd4de11f3,
        mid_isDigit_5ddad6b6ca6f5522,
        mid_isDigit_12fe561dd4de11f3,
        mid_isEmoji_12fe561dd4de11f3,
        mid_isEmojiComponent_12fe561dd4de11f3,
        mid_isEmojiModifier_12fe561dd4de11f3,
        mid_isEmojiModifierBase_12fe561dd4de11f3,
        mid_isEmojiPresentation_12fe561dd4de11f3,
        mid_isExtendedPictographic_12fe561dd4de11f3,
        mid_isHighSurrogate_5ddad6b6ca6f5522,
        mid_isISOControl_5ddad6b6ca6f5522,
        mid_isISOControl_12fe561dd4de11f3,
        mid_isIdentifierIgnorable_5ddad6b6ca6f5522,
        mid_isIdentifierIgnorable_12fe561dd4de11f3,
        mid_isIdeographic_12fe561dd4de11f3,
        mid_isJavaIdentifierPart_5ddad6b6ca6f5522,
        mid_isJavaIdentifierPart_12fe561dd4de11f3,
        mid_isJavaIdentifierStart_5ddad6b6ca6f5522,
        mid_isJavaIdentifierStart_12fe561dd4de11f3,
        mid_isJavaLetter_5ddad6b6ca6f5522,
        mid_isJavaLetterOrDigit_5ddad6b6ca6f5522,
        mid_isLetter_5ddad6b6ca6f5522,
        mid_isLetter_12fe561dd4de11f3,
        mid_isLetterOrDigit_5ddad6b6ca6f5522,
        mid_isLetterOrDigit_12fe561dd4de11f3,
        mid_isLowSurrogate_5ddad6b6ca6f5522,
        mid_isLowerCase_5ddad6b6ca6f5522,
        mid_isLowerCase_12fe561dd4de11f3,
        mid_isMirrored_5ddad6b6ca6f5522,
        mid_isMirrored_12fe561dd4de11f3,
        mid_isSpace_5ddad6b6ca6f5522,
        mid_isSpaceChar_5ddad6b6ca6f5522,
        mid_isSpaceChar_12fe561dd4de11f3,
        mid_isSupplementaryCodePoint_12fe561dd4de11f3,
        mid_isSurrogate_5ddad6b6ca6f5522,
        mid_isSurrogatePair_3b22f686011b836b,
        mid_isTitleCase_5ddad6b6ca6f5522,
        mid_isTitleCase_12fe561dd4de11f3,
        mid_isUnicodeIdentifierPart_5ddad6b6ca6f5522,
        mid_isUnicodeIdentifierPart_12fe561dd4de11f3,
        mid_isUnicodeIdentifierStart_5ddad6b6ca6f5522,
        mid_isUnicodeIdentifierStart_12fe561dd4de11f3,
        mid_isUpperCase_5ddad6b6ca6f5522,
        mid_isUpperCase_12fe561dd4de11f3,
        mid_isValidCodePoint_12fe561dd4de11f3,
        mid_isWhitespace_5ddad6b6ca6f5522,
        mid_isWhitespace_12fe561dd4de11f3,
        mid_lowSurrogate_0b9831c04f367f5c,
        mid_offsetByCodePoints_256c9e9a0323d13a,
        mid_offsetByCodePoints_caca3877f598b368,
        mid_reverseBytes_ccd8c56fc3878ed4,
        mid_toChars_2c32d5c4b58a3235,
        mid_toChars_87c73f96b22034f6,
        mid_toCodePoint_01142bdbaea0bcb5,
        mid_toLowerCase_ccd8c56fc3878ed4,
        mid_toLowerCase_ff66fe240ad72894,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_toString_82edd1789d1cc009,
        mid_toString_aebd86204175b724,
        mid_toTitleCase_ccd8c56fc3878ed4,
        mid_toTitleCase_ff66fe240ad72894,
        mid_toUpperCase_ccd8c56fc3878ed4,
        mid_toUpperCase_ff66fe240ad72894,
        mid_valueOf_c4f2049ec3b04fa1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Character(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Character(const Character& obj) : ::java::lang::Object(obj) {}

      static jint BYTES;
      static jbyte COMBINING_SPACING_MARK;
      static jbyte CONNECTOR_PUNCTUATION;
      static jbyte CONTROL;
      static jbyte CURRENCY_SYMBOL;
      static jbyte DASH_PUNCTUATION;
      static jbyte DECIMAL_DIGIT_NUMBER;
      static jbyte DIRECTIONALITY_ARABIC_NUMBER;
      static jbyte DIRECTIONALITY_BOUNDARY_NEUTRAL;
      static jbyte DIRECTIONALITY_COMMON_NUMBER_SEPARATOR;
      static jbyte DIRECTIONALITY_EUROPEAN_NUMBER;
      static jbyte DIRECTIONALITY_EUROPEAN_NUMBER_SEPARATOR;
      static jbyte DIRECTIONALITY_EUROPEAN_NUMBER_TERMINATOR;
      static jbyte DIRECTIONALITY_FIRST_STRONG_ISOLATE;
      static jbyte DIRECTIONALITY_LEFT_TO_RIGHT;
      static jbyte DIRECTIONALITY_LEFT_TO_RIGHT_EMBEDDING;
      static jbyte DIRECTIONALITY_LEFT_TO_RIGHT_ISOLATE;
      static jbyte DIRECTIONALITY_LEFT_TO_RIGHT_OVERRIDE;
      static jbyte DIRECTIONALITY_NONSPACING_MARK;
      static jbyte DIRECTIONALITY_OTHER_NEUTRALS;
      static jbyte DIRECTIONALITY_PARAGRAPH_SEPARATOR;
      static jbyte DIRECTIONALITY_POP_DIRECTIONAL_FORMAT;
      static jbyte DIRECTIONALITY_POP_DIRECTIONAL_ISOLATE;
      static jbyte DIRECTIONALITY_RIGHT_TO_LEFT;
      static jbyte DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC;
      static jbyte DIRECTIONALITY_RIGHT_TO_LEFT_EMBEDDING;
      static jbyte DIRECTIONALITY_RIGHT_TO_LEFT_ISOLATE;
      static jbyte DIRECTIONALITY_RIGHT_TO_LEFT_OVERRIDE;
      static jbyte DIRECTIONALITY_SEGMENT_SEPARATOR;
      static jbyte DIRECTIONALITY_UNDEFINED;
      static jbyte DIRECTIONALITY_WHITESPACE;
      static jbyte ENCLOSING_MARK;
      static jbyte END_PUNCTUATION;
      static jbyte FINAL_QUOTE_PUNCTUATION;
      static jbyte FORMAT;
      static jbyte INITIAL_QUOTE_PUNCTUATION;
      static jbyte LETTER_NUMBER;
      static jbyte LINE_SEPARATOR;
      static jbyte LOWERCASE_LETTER;
      static jbyte MATH_SYMBOL;
      static jint MAX_CODE_POINT;
      static jchar MAX_HIGH_SURROGATE;
      static jchar MAX_LOW_SURROGATE;
      static jint MAX_RADIX;
      static jchar MAX_SURROGATE;
      static jchar MAX_VALUE;
      static jint MIN_CODE_POINT;
      static jchar MIN_HIGH_SURROGATE;
      static jchar MIN_LOW_SURROGATE;
      static jint MIN_RADIX;
      static jint MIN_SUPPLEMENTARY_CODE_POINT;
      static jchar MIN_SURROGATE;
      static jchar MIN_VALUE;
      static jbyte MODIFIER_LETTER;
      static jbyte MODIFIER_SYMBOL;
      static jbyte NON_SPACING_MARK;
      static jbyte OTHER_LETTER;
      static jbyte OTHER_NUMBER;
      static jbyte OTHER_PUNCTUATION;
      static jbyte OTHER_SYMBOL;
      static jbyte PARAGRAPH_SEPARATOR;
      static jbyte PRIVATE_USE;
      static jint SIZE;
      static jbyte SPACE_SEPARATOR;
      static jbyte START_PUNCTUATION;
      static jbyte SURROGATE;
      static jbyte TITLECASE_LETTER;
      static ::java::lang::Class *TYPE;
      static jbyte UNASSIGNED;
      static jbyte UPPERCASE_LETTER;

      Character(jchar);

      static jint charCount(jint);
      jchar charValue() const;
      static jint codePointAt(const JArray< jchar > &, jint);
      static jint codePointAt(const ::java::lang::CharSequence &, jint);
      static jint codePointAt(const JArray< jchar > &, jint, jint);
      static jint codePointBefore(const JArray< jchar > &, jint);
      static jint codePointBefore(const ::java::lang::CharSequence &, jint);
      static jint codePointBefore(const JArray< jchar > &, jint, jint);
      static jint codePointCount(const JArray< jchar > &, jint, jint);
      static jint codePointCount(const ::java::lang::CharSequence &, jint, jint);
      static jint codePointOf(const ::java::lang::String &);
      static jint compare(jchar, jchar);
      jint compareTo(const Character &) const;
      ::java::util::Optional describeConstable() const;
      static jint digit(jchar, jint);
      static jint digit(jint, jint);
      jboolean equals(const ::java::lang::Object &) const;
      static jchar forDigit(jint, jint);
      static jbyte getDirectionality(jchar);
      static jbyte getDirectionality(jint);
      static ::java::lang::String getName(jint);
      static jint getNumericValue(jchar);
      static jint getNumericValue(jint);
      static jint getType(jchar);
      static jint getType(jint);
      jint hashCode() const;
      static jint hashCode(jchar);
      static jchar highSurrogate(jint);
      static jboolean isAlphabetic(jint);
      static jboolean isBmpCodePoint(jint);
      static jboolean isDefined(jchar);
      static jboolean isDefined(jint);
      static jboolean isDigit(jchar);
      static jboolean isDigit(jint);
      static jboolean isEmoji(jint);
      static jboolean isEmojiComponent(jint);
      static jboolean isEmojiModifier(jint);
      static jboolean isEmojiModifierBase(jint);
      static jboolean isEmojiPresentation(jint);
      static jboolean isExtendedPictographic(jint);
      static jboolean isHighSurrogate(jchar);
      static jboolean isISOControl(jchar);
      static jboolean isISOControl(jint);
      static jboolean isIdentifierIgnorable(jchar);
      static jboolean isIdentifierIgnorable(jint);
      static jboolean isIdeographic(jint);
      static jboolean isJavaIdentifierPart(jchar);
      static jboolean isJavaIdentifierPart(jint);
      static jboolean isJavaIdentifierStart(jchar);
      static jboolean isJavaIdentifierStart(jint);
      static jboolean isJavaLetter(jchar);
      static jboolean isJavaLetterOrDigit(jchar);
      static jboolean isLetter(jchar);
      static jboolean isLetter(jint);
      static jboolean isLetterOrDigit(jchar);
      static jboolean isLetterOrDigit(jint);
      static jboolean isLowSurrogate(jchar);
      static jboolean isLowerCase(jchar);
      static jboolean isLowerCase(jint);
      static jboolean isMirrored(jchar);
      static jboolean isMirrored(jint);
      static jboolean isSpace(jchar);
      static jboolean isSpaceChar(jchar);
      static jboolean isSpaceChar(jint);
      static jboolean isSupplementaryCodePoint(jint);
      static jboolean isSurrogate(jchar);
      static jboolean isSurrogatePair(jchar, jchar);
      static jboolean isTitleCase(jchar);
      static jboolean isTitleCase(jint);
      static jboolean isUnicodeIdentifierPart(jchar);
      static jboolean isUnicodeIdentifierPart(jint);
      static jboolean isUnicodeIdentifierStart(jchar);
      static jboolean isUnicodeIdentifierStart(jint);
      static jboolean isUpperCase(jchar);
      static jboolean isUpperCase(jint);
      static jboolean isValidCodePoint(jint);
      static jboolean isWhitespace(jchar);
      static jboolean isWhitespace(jint);
      static jchar lowSurrogate(jint);
      static jint offsetByCodePoints(const ::java::lang::CharSequence &, jint, jint);
      static jint offsetByCodePoints(const JArray< jchar > &, jint, jint, jint, jint);
      static jchar reverseBytes(jchar);
      static JArray< jchar > toChars(jint);
      static jint toChars(jint, const JArray< jchar > &, jint);
      static jint toCodePoint(jchar, jchar);
      static jchar toLowerCase(jchar);
      static jint toLowerCase(jint);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jchar);
      static ::java::lang::String toString(jint);
      static jchar toTitleCase(jchar);
      static jint toTitleCase(jint);
      static jchar toUpperCase(jchar);
      static jint toUpperCase(jint);
      static Character valueOf(jchar);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Character);
    extern PyTypeObject *PY_TYPE(Character);

    class t_Character {
    public:
      PyObject_HEAD
      Character object;
      static PyObject *wrap_Object(const Character&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
