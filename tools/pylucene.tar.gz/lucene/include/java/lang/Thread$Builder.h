#ifndef java_lang_Thread$Builder_H
#define java_lang_Thread$Builder_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Thread$UncaughtExceptionHandler;
    class Class;
    class String;
    class Thread$Builder;
    class Runnable;
    class Thread;
  }
  namespace util {
    namespace concurrent {
      class ThreadFactory;
    }
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Thread$Builder : public ::java::lang::Object {
     public:
      enum {
        mid_factory_3cc367e4fd0607c1,
        mid_inheritInheritableThreadLocals_316b3fefb109df84,
        mid_name_9e4b07d00fccae99,
        mid_name_80d162dd41a8ab27,
        mid_start_05f629bf767ad47c,
        mid_uncaughtExceptionHandler_d3a34b407cf9ebd7,
        mid_unstarted_05f629bf767ad47c,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Thread$Builder(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Thread$Builder(const Thread$Builder& obj) : ::java::lang::Object(obj) {}

      ::java::util::concurrent::ThreadFactory factory() const;
      Thread$Builder inheritInheritableThreadLocals(jboolean) const;
      Thread$Builder name(const ::java::lang::String &) const;
      Thread$Builder name(const ::java::lang::String &, jlong) const;
      ::java::lang::Thread start(const ::java::lang::Runnable &) const;
      Thread$Builder uncaughtExceptionHandler(const ::java::lang::Thread$UncaughtExceptionHandler &) const;
      ::java::lang::Thread unstarted(const ::java::lang::Runnable &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Thread$Builder);
    extern PyTypeObject *PY_TYPE(Thread$Builder);

    class t_Thread$Builder {
    public:
      PyObject_HEAD
      Thread$Builder object;
      static PyObject *wrap_Object(const Thread$Builder&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
