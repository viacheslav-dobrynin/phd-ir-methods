#ifndef java_lang_Double_H
#define java_lang_Double_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class NumberFormatException;
    class Comparable;
    class Class;
    class String;
    class Double;
    class Object;
  }
  namespace util {
    class Optional;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Double : public ::java::lang::Number {
     public:
      enum {
        mid_init$_9b22ecdee06ea23c,
        mid_init$_44052de370ab2f98,
        mid_byteValue_d6f5e90da65461cb,
        mid_compare_51e8002648cfe4d4,
        mid_compareTo_be9d1c4aab2f51cd,
        mid_describeConstable_5dfa6fdc4ec946c6,
        mid_doubleToLongBits_3178db4719043b21,
        mid_doubleToRawLongBits_3178db4719043b21,
        mid_doubleValue_a6c1144f51bd8892,
        mid_equals_2a09f73f0549554f,
        mid_floatValue_a9dac2c40463ba96,
        mid_hashCode_f03edc6a210ac78c,
        mid_hashCode_43b58587b325d39c,
        mid_intValue_f03edc6a210ac78c,
        mid_isFinite_ee26c8eafd99a472,
        mid_isInfinite_201fceb6e9f1d0c5,
        mid_isInfinite_ee26c8eafd99a472,
        mid_isNaN_201fceb6e9f1d0c5,
        mid_isNaN_ee26c8eafd99a472,
        mid_longBitsToDouble_c6f6528d216e1b0d,
        mid_longValue_d192af3db8896a5e,
        mid_max_e0cc5a1725892117,
        mid_min_e0cc5a1725892117,
        mid_parseDouble_a5dc1e90806d58dd,
        mid_shortValue_322e7f113b6f2d2a,
        mid_sum_e0cc5a1725892117,
        mid_toHexString_74f601c4b6f2da5a,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_toString_74f601c4b6f2da5a,
        mid_valueOf_f16edfc3af09963f,
        mid_valueOf_fe91ceb9db46ad12,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Double(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Double(const Double& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jint MAX_EXPONENT;
      static jdouble MAX_VALUE;
      static jint MIN_EXPONENT;
      static jdouble MIN_NORMAL;
      static jdouble MIN_VALUE;
      static jdouble NEGATIVE_INFINITY;
      static jdouble NaN;
      static jdouble POSITIVE_INFINITY;
      static jint PRECISION;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Double(const ::java::lang::String &);
      Double(jdouble);

      jbyte byteValue() const;
      static jint compare(jdouble, jdouble);
      jint compareTo(const Double &) const;
      ::java::util::Optional describeConstable() const;
      static jlong doubleToLongBits(jdouble);
      static jlong doubleToRawLongBits(jdouble);
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      jfloat floatValue() const;
      jint hashCode() const;
      static jint hashCode(jdouble);
      jint intValue() const;
      static jboolean isFinite(jdouble);
      jboolean isInfinite() const;
      static jboolean isInfinite(jdouble);
      jboolean isNaN() const;
      static jboolean isNaN(jdouble);
      static jdouble longBitsToDouble(jlong);
      jlong longValue() const;
      static jdouble max$(jdouble, jdouble);
      static jdouble min$(jdouble, jdouble);
      static jdouble parseDouble(const ::java::lang::String &);
      jshort shortValue() const;
      static jdouble sum(jdouble, jdouble);
      static ::java::lang::String toHexString(jdouble);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jdouble);
      static Double valueOf(const ::java::lang::String &);
      static Double valueOf(jdouble);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Double);
    extern PyTypeObject *PY_TYPE(Double);

    class t_Double {
    public:
      PyObject_HEAD
      Double object;
      static PyObject *wrap_Object(const Double&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
