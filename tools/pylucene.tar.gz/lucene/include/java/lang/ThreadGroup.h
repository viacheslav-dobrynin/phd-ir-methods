#ifndef java_lang_ThreadGroup_H
#define java_lang_ThreadGroup_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Thread$UncaughtExceptionHandler;
    class ThreadGroup;
    class Class;
    class String;
    class Throwable;
    class Thread;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class ThreadGroup : public ::java::lang::Object {
     public:
      enum {
        mid_init$_9b22ecdee06ea23c,
        mid_init$_72f8a0e0bfa1217a,
        mid_activeCount_f03edc6a210ac78c,
        mid_activeGroupCount_f03edc6a210ac78c,
        mid_checkAccess_a5783a25d44ba15b,
        mid_destroy_a5783a25d44ba15b,
        mid_enumerate_2a81a3a2f345e3d8,
        mid_enumerate_2fa6b6bc494bfa2b,
        mid_enumerate_32893f32b0e471a5,
        mid_enumerate_d5b4c6f29dd646ef,
        mid_getMaxPriority_f03edc6a210ac78c,
        mid_getName_cb1e3f35ce7b2bd1,
        mid_getParent_2cc430c63cee02d8,
        mid_interrupt_a5783a25d44ba15b,
        mid_isDaemon_201fceb6e9f1d0c5,
        mid_isDestroyed_201fceb6e9f1d0c5,
        mid_list_a5783a25d44ba15b,
        mid_parentOf_d88a942fc6fb7c7e,
        mid_resume_a5783a25d44ba15b,
        mid_setDaemon_a5b6a940fc16c6a1,
        mid_setMaxPriority_8730ba9dfaf23a7b,
        mid_stop_a5783a25d44ba15b,
        mid_suspend_a5783a25d44ba15b,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_uncaughtException_3962524ff0e534a8,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit ThreadGroup(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      ThreadGroup(const ThreadGroup& obj) : ::java::lang::Object(obj) {}

      ThreadGroup(const ::java::lang::String &);
      ThreadGroup(const ThreadGroup &, const ::java::lang::String &);

      jint activeCount() const;
      jint activeGroupCount() const;
      void checkAccess() const;
      void destroy() const;
      jint enumerate(const JArray< ::java::lang::Thread > &) const;
      jint enumerate(const JArray< ThreadGroup > &) const;
      jint enumerate(const JArray< ::java::lang::Thread > &, jboolean) const;
      jint enumerate(const JArray< ThreadGroup > &, jboolean) const;
      jint getMaxPriority() const;
      ::java::lang::String getName() const;
      ThreadGroup getParent() const;
      void interrupt() const;
      jboolean isDaemon() const;
      jboolean isDestroyed() const;
      void list() const;
      jboolean parentOf(const ThreadGroup &) const;
      void resume() const;
      void setDaemon(jboolean) const;
      void setMaxPriority(jint) const;
      void stop() const;
      void suspend() const;
      ::java::lang::String toString() const;
      void uncaughtException(const ::java::lang::Thread &, const ::java::lang::Throwable &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(ThreadGroup);
    extern PyTypeObject *PY_TYPE(ThreadGroup);

    class t_ThreadGroup {
    public:
      PyObject_HEAD
      ThreadGroup object;
      static PyObject *wrap_Object(const ThreadGroup&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
