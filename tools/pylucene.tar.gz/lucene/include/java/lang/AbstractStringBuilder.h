#ifndef java_lang_AbstractStringBuilder_H
#define java_lang_AbstractStringBuilder_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class AbstractStringBuilder;
    class CharSequence;
    class StringBuffer;
    class Appendable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class AbstractStringBuilder : public ::java::lang::Object {
     public:
      enum {
        mid_append_bc6499b5cf2a9ee8,
        mid_append_a42d5004f9aa19e7,
        mid_append_6fb3ab0118c8db59,
        mid_append_3f7ded9c95266f54,
        mid_append_2b4d48e28fa598ee,
        mid_append_67855509a66e32ba,
        mid_append_07bd53537a317936,
        mid_append_3c1496cfdc4d5eaf,
        mid_append_cf703621844c7f64,
        mid_append_d75688bd104cafb8,
        mid_append_88980f4ad032c08c,
        mid_append_d2becc08df49ce3d,
        mid_append_1e7648beb659db0a,
        mid_appendCodePoint_3c1496cfdc4d5eaf,
        mid_capacity_f03edc6a210ac78c,
        mid_charAt_0b9831c04f367f5c,
        mid_codePointAt_ff66fe240ad72894,
        mid_codePointBefore_ff66fe240ad72894,
        mid_codePointCount_103e4c7b2b508548,
        mid_delete_5a167b56fe4233c5,
        mid_deleteCharAt_3c1496cfdc4d5eaf,
        mid_ensureCapacity_8730ba9dfaf23a7b,
        mid_getChars_cb528f2a42e4954d,
        mid_indexOf_164529de03d21944,
        mid_indexOf_fb95a845cd21cbac,
        mid_insert_ce79f9a996c12bb0,
        mid_insert_de3aebbc6c0f740d,
        mid_insert_f0e156b2d6ec780f,
        mid_insert_d794d3577bddedae,
        mid_insert_b193d6bfa6014eca,
        mid_insert_fb0fe4a2e1c4d914,
        mid_insert_5a167b56fe4233c5,
        mid_insert_373ac92547271cae,
        mid_insert_112b5ff7f2e02bf6,
        mid_insert_f2b98c886521fe57,
        mid_insert_fed541b49147f1d5,
        mid_insert_f4d1b1911a11e28c,
        mid_lastIndexOf_164529de03d21944,
        mid_lastIndexOf_fb95a845cd21cbac,
        mid_length_f03edc6a210ac78c,
        mid_offsetByCodePoints_103e4c7b2b508548,
        mid_repeat_5a167b56fe4233c5,
        mid_repeat_91afc53b4cba3f3f,
        mid_replace_81bfdf9c96486a40,
        mid_reverse_fed174e9fd2216a8,
        mid_setCharAt_fce6db950fe18d1c,
        mid_setLength_8730ba9dfaf23a7b,
        mid_subSequence_2af0256e00da87ed,
        mid_substring_aebd86204175b724,
        mid_substring_2b9e4dd3c6e0d2e6,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_trimToSize_a5783a25d44ba15b,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit AbstractStringBuilder(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      AbstractStringBuilder(const AbstractStringBuilder& obj) : ::java::lang::Object(obj) {}

      AbstractStringBuilder append(const ::java::lang::StringBuffer &) const;
      AbstractStringBuilder append(const JArray< jchar > &) const;
      AbstractStringBuilder append(const ::java::lang::String &) const;
      AbstractStringBuilder append(jboolean) const;
      AbstractStringBuilder append(jchar) const;
      AbstractStringBuilder append(jdouble) const;
      AbstractStringBuilder append(jfloat) const;
      AbstractStringBuilder append(jint) const;
      AbstractStringBuilder append(const ::java::lang::CharSequence &) const;
      AbstractStringBuilder append(const ::java::lang::Object &) const;
      AbstractStringBuilder append(jlong) const;
      AbstractStringBuilder append(const JArray< jchar > &, jint, jint) const;
      AbstractStringBuilder append(const ::java::lang::CharSequence &, jint, jint) const;
      AbstractStringBuilder appendCodePoint(jint) const;
      jint capacity() const;
      jchar charAt(jint) const;
      jint codePointAt(jint) const;
      jint codePointBefore(jint) const;
      jint codePointCount(jint, jint) const;
      AbstractStringBuilder delete$(jint, jint) const;
      AbstractStringBuilder deleteCharAt(jint) const;
      void ensureCapacity(jint) const;
      void getChars(jint, jint, const JArray< jchar > &, jint) const;
      jint indexOf(const ::java::lang::String &) const;
      jint indexOf(const ::java::lang::String &, jint) const;
      AbstractStringBuilder insert(jint, const JArray< jchar > &) const;
      AbstractStringBuilder insert(jint, const ::java::lang::String &) const;
      AbstractStringBuilder insert(jint, jboolean) const;
      AbstractStringBuilder insert(jint, jchar) const;
      AbstractStringBuilder insert(jint, jdouble) const;
      AbstractStringBuilder insert(jint, jfloat) const;
      AbstractStringBuilder insert(jint, jint) const;
      AbstractStringBuilder insert(jint, const ::java::lang::CharSequence &) const;
      AbstractStringBuilder insert(jint, const ::java::lang::Object &) const;
      AbstractStringBuilder insert(jint, jlong) const;
      AbstractStringBuilder insert(jint, const JArray< jchar > &, jint, jint) const;
      AbstractStringBuilder insert(jint, const ::java::lang::CharSequence &, jint, jint) const;
      jint lastIndexOf(const ::java::lang::String &) const;
      jint lastIndexOf(const ::java::lang::String &, jint) const;
      jint length() const;
      jint offsetByCodePoints(jint, jint) const;
      AbstractStringBuilder repeat(jint, jint) const;
      AbstractStringBuilder repeat(const ::java::lang::CharSequence &, jint) const;
      AbstractStringBuilder replace(jint, jint, const ::java::lang::String &) const;
      AbstractStringBuilder reverse() const;
      void setCharAt(jint, jchar) const;
      void setLength(jint) const;
      ::java::lang::CharSequence subSequence(jint, jint) const;
      ::java::lang::String substring(jint) const;
      ::java::lang::String substring(jint, jint) const;
      ::java::lang::String toString() const;
      void trimToSize() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(AbstractStringBuilder);
    extern PyTypeObject *PY_TYPE(AbstractStringBuilder);

    class t_AbstractStringBuilder {
    public:
      PyObject_HEAD
      AbstractStringBuilder object;
      static PyObject *wrap_Object(const AbstractStringBuilder&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
