#ifndef java_lang_Runtime$Version_H
#define java_lang_Runtime$Version_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Comparable;
    class Integer;
    class Class;
    class String;
    class Runtime$Version;
  }
  namespace util {
    class List;
    class Optional;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Runtime$Version : public ::java::lang::Object {
     public:
      enum {
        mid_build_5dfa6fdc4ec946c6,
        mid_compareTo_009a3929da6845e4,
        mid_compareToIgnoreOptional_009a3929da6845e4,
        mid_equals_2a09f73f0549554f,
        mid_equalsIgnoreOptional_2a09f73f0549554f,
        mid_feature_f03edc6a210ac78c,
        mid_hashCode_f03edc6a210ac78c,
        mid_interim_f03edc6a210ac78c,
        mid_major_f03edc6a210ac78c,
        mid_minor_f03edc6a210ac78c,
        mid_optional_5dfa6fdc4ec946c6,
        mid_parse_fd64f0a1b07c0cad,
        mid_patch_f03edc6a210ac78c,
        mid_pre_5dfa6fdc4ec946c6,
        mid_security_f03edc6a210ac78c,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_update_f03edc6a210ac78c,
        mid_version_7b3206bb4e2462d2,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Runtime$Version(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Runtime$Version(const Runtime$Version& obj) : ::java::lang::Object(obj) {}

      ::java::util::Optional build() const;
      jint compareTo(const Runtime$Version &) const;
      jint compareToIgnoreOptional(const Runtime$Version &) const;
      jboolean equals(const ::java::lang::Object &) const;
      jboolean equalsIgnoreOptional(const ::java::lang::Object &) const;
      jint feature() const;
      jint hashCode() const;
      jint interim() const;
      jint major() const;
      jint minor() const;
      ::java::util::Optional optional() const;
      static Runtime$Version parse(const ::java::lang::String &);
      jint patch() const;
      ::java::util::Optional pre() const;
      jint security() const;
      ::java::lang::String toString() const;
      jint update() const;
      ::java::util::List version() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Runtime$Version);
    extern PyTypeObject *PY_TYPE(Runtime$Version);

    class t_Runtime$Version {
    public:
      PyObject_HEAD
      Runtime$Version object;
      static PyObject *wrap_Object(const Runtime$Version&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
