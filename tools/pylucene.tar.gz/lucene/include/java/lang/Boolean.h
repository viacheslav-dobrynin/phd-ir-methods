#ifndef java_lang_Boolean_H
#define java_lang_Boolean_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Comparable;
    class Boolean;
    class String;
    class Class;
    namespace constant {
      class DynamicConstantDesc;
    }
  }
  namespace io {
    class Serializable;
  }
  namespace util {
    class Optional;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Boolean : public ::java::lang::Object {
     public:
      enum {
        mid_init$_9b22ecdee06ea23c,
        mid_init$_a5b6a940fc16c6a1,
        mid_booleanValue_201fceb6e9f1d0c5,
        mid_compare_92ff6b1dada696c5,
        mid_compareTo_4f606f44a9e4ddfa,
        mid_describeConstable_5dfa6fdc4ec946c6,
        mid_equals_2a09f73f0549554f,
        mid_getBoolean_7585662e3a5cb869,
        mid_hashCode_f03edc6a210ac78c,
        mid_hashCode_212e8158fad0d93d,
        mid_logicalAnd_8712fceaa0de33c9,
        mid_logicalOr_8712fceaa0de33c9,
        mid_logicalXor_8712fceaa0de33c9,
        mid_parseBoolean_7585662e3a5cb869,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_toString_68fa91587e49b2cd,
        mid_valueOf_040effb328cf59b5,
        mid_valueOf_fa467497668962d7,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Boolean(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Boolean(const Boolean& obj) : ::java::lang::Object(obj) {}

      static Boolean *FALSE;
      static Boolean *TRUE;
      static ::java::lang::Class *TYPE;

      Boolean(const ::java::lang::String &);
      Boolean(jboolean);

      jboolean booleanValue() const;
      static jint compare(jboolean, jboolean);
      jint compareTo(const Boolean &) const;
      ::java::util::Optional describeConstable() const;
      jboolean equals(const ::java::lang::Object &) const;
      static jboolean getBoolean(const ::java::lang::String &);
      jint hashCode() const;
      static jint hashCode(jboolean);
      static jboolean logicalAnd(jboolean, jboolean);
      static jboolean logicalOr(jboolean, jboolean);
      static jboolean logicalXor(jboolean, jboolean);
      static jboolean parseBoolean(const ::java::lang::String &);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jboolean);
      static Boolean valueOf(const ::java::lang::String &);
      static Boolean valueOf(jboolean);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Boolean);
    extern PyTypeObject *PY_TYPE(Boolean);

    class t_Boolean {
    public:
      PyObject_HEAD
      Boolean object;
      static PyObject *wrap_Object(const Boolean&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
