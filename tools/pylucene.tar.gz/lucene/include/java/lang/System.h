#ifndef java_lang_System_H
#define java_lang_System_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class Console;
    class PrintStream;
    class InputStream;
  }
  namespace lang {
    class System$Logger;
    class Class;
    class String;
    class SecurityManager;
  }
  namespace util {
    class Map;
    class ResourceBundle;
    class Properties;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class System : public ::java::lang::Object {
     public:
      enum {
        mid_arraycopy_2d28bd561d6f8619,
        mid_clearProperty_4fd613927a288526,
        mid_console_920c86d5490afb2e,
        mid_currentTimeMillis_d192af3db8896a5e,
        mid_exit_8730ba9dfaf23a7b,
        mid_gc_a5783a25d44ba15b,
        mid_getLogger_d7f3b30ad2d00441,
        mid_getLogger_78e7fbbeded2b310,
        mid_getProperties_22ce0f36fb110b2b,
        mid_getProperty_4fd613927a288526,
        mid_getProperty_5132ab8c6032328c,
        mid_getSecurityManager_e27fe132a0bd77f3,
        mid_getenv_2ccd91d439ff7d1f,
        mid_getenv_4fd613927a288526,
        mid_identityHashCode_8734b42132ce8667,
        mid_lineSeparator_cb1e3f35ce7b2bd1,
        mid_load_9b22ecdee06ea23c,
        mid_loadLibrary_9b22ecdee06ea23c,
        mid_mapLibraryName_4fd613927a288526,
        mid_nanoTime_d192af3db8896a5e,
        mid_runFinalization_a5783a25d44ba15b,
        mid_setErr_334c447f5ff9aeee,
        mid_setIn_0c01d19e107a92b8,
        mid_setOut_334c447f5ff9aeee,
        mid_setProperties_0954f7954e03e41e,
        mid_setProperty_5132ab8c6032328c,
        mid_setSecurityManager_0abe0b7874ff148c,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit System(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      System(const System& obj) : ::java::lang::Object(obj) {}

      static ::java::io::PrintStream *err;
      static ::java::io::InputStream *in;
      static ::java::io::PrintStream *out;

      static void arraycopy(const ::java::lang::Object &, jint, const ::java::lang::Object &, jint, jint);
      static ::java::lang::String clearProperty(const ::java::lang::String &);
      static ::java::io::Console console();
      static jlong currentTimeMillis();
      static void exit(jint);
      static void gc();
      static ::java::lang::System$Logger getLogger(const ::java::lang::String &);
      static ::java::lang::System$Logger getLogger(const ::java::lang::String &, const ::java::util::ResourceBundle &);
      static ::java::util::Properties getProperties();
      static ::java::lang::String getProperty(const ::java::lang::String &);
      static ::java::lang::String getProperty(const ::java::lang::String &, const ::java::lang::String &);
      static ::java::lang::SecurityManager getSecurityManager();
      static ::java::util::Map getenv();
      static ::java::lang::String getenv(const ::java::lang::String &);
      static jint identityHashCode(const ::java::lang::Object &);
      static ::java::lang::String lineSeparator();
      static void load(const ::java::lang::String &);
      static void loadLibrary(const ::java::lang::String &);
      static ::java::lang::String mapLibraryName(const ::java::lang::String &);
      static jlong nanoTime();
      static void runFinalization();
      static void setErr(const ::java::io::PrintStream &);
      static void setIn(const ::java::io::InputStream &);
      static void setOut(const ::java::io::PrintStream &);
      static void setProperties(const ::java::util::Properties &);
      static ::java::lang::String setProperty(const ::java::lang::String &, const ::java::lang::String &);
      static void setSecurityManager(const ::java::lang::SecurityManager &);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(System);
    extern PyTypeObject *PY_TYPE(System);

    class t_System {
    public:
      PyObject_HEAD
      System object;
      static PyObject *wrap_Object(const System&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
