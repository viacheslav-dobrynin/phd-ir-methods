#ifndef java_lang_Thread_H
#define java_lang_Thread_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class StackTraceElement;
    class ClassLoader;
    class ThreadGroup;
    class Thread$UncaughtExceptionHandler;
    class Thread$Builder$OfPlatform;
    class Class;
    class String;
    class Thread$State;
    class Thread$Builder$OfVirtual;
    class InterruptedException;
    class Runnable;
    class Thread;
  }
  namespace util {
    class Map;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Thread : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_9b22ecdee06ea23c,
        mid_init$_9b751813e93fd614,
        mid_init$_72f8a0e0bfa1217a,
        mid_init$_793603f37466b3a5,
        mid_init$_3892f78e90eb2393,
        mid_init$_d1e412638c145b39,
        mid_init$_b5be8f87368c457a,
        mid_init$_71a99e7b7f0f2a5b,
        mid_activeCount_f03edc6a210ac78c,
        mid_checkAccess_a5783a25d44ba15b,
        mid_countStackFrames_f03edc6a210ac78c,
        mid_currentThread_9541191e1984c1ad,
        mid_dumpStack_a5783a25d44ba15b,
        mid_enumerate_2a81a3a2f345e3d8,
        mid_getAllStackTraces_2ccd91d439ff7d1f,
        mid_getContextClassLoader_872562251d2105b9,
        mid_getDefaultUncaughtExceptionHandler_c41e33d4a3c9872b,
        mid_getId_d192af3db8896a5e,
        mid_getName_cb1e3f35ce7b2bd1,
        mid_getPriority_f03edc6a210ac78c,
        mid_getStackTrace_c58a5bd159b69443,
        mid_getState_65ee5ce3936ef041,
        mid_getThreadGroup_2cc430c63cee02d8,
        mid_getUncaughtExceptionHandler_c41e33d4a3c9872b,
        mid_holdsLock_2a09f73f0549554f,
        mid_interrupt_a5783a25d44ba15b,
        mid_interrupted_201fceb6e9f1d0c5,
        mid_isAlive_201fceb6e9f1d0c5,
        mid_isDaemon_201fceb6e9f1d0c5,
        mid_isInterrupted_201fceb6e9f1d0c5,
        mid_isVirtual_201fceb6e9f1d0c5,
        mid_join_a5783a25d44ba15b,
        mid_join_270332bbfd4dc523,
        mid_join_ca843eab9241c96e,
        mid_ofPlatform_822028d5e07de8f3,
        mid_ofVirtual_83d536c3564c8cfa,
        mid_onSpinWait_a5783a25d44ba15b,
        mid_resume_a5783a25d44ba15b,
        mid_run_a5783a25d44ba15b,
        mid_setContextClassLoader_e29185c148c81f19,
        mid_setDaemon_a5b6a940fc16c6a1,
        mid_setDefaultUncaughtExceptionHandler_93319f0257f7a106,
        mid_setName_9b22ecdee06ea23c,
        mid_setPriority_8730ba9dfaf23a7b,
        mid_setUncaughtExceptionHandler_93319f0257f7a106,
        mid_sleep_270332bbfd4dc523,
        mid_sleep_ca843eab9241c96e,
        mid_start_a5783a25d44ba15b,
        mid_startVirtualThread_05f629bf767ad47c,
        mid_stop_a5783a25d44ba15b,
        mid_suspend_a5783a25d44ba15b,
        mid_threadId_d192af3db8896a5e,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_yield_a5783a25d44ba15b,
        mid_clone_1543ec1f1674e5aa,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Thread(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Thread(const Thread& obj) : ::java::lang::Object(obj) {}

      static jint MAX_PRIORITY;
      static jint MIN_PRIORITY;
      static jint NORM_PRIORITY;

      Thread();
      Thread(const ::java::lang::String &);
      Thread(const ::java::lang::Runnable &);
      Thread(const ::java::lang::ThreadGroup &, const ::java::lang::String &);
      Thread(const ::java::lang::ThreadGroup &, const ::java::lang::Runnable &);
      Thread(const ::java::lang::Runnable &, const ::java::lang::String &);
      Thread(const ::java::lang::ThreadGroup &, const ::java::lang::Runnable &, const ::java::lang::String &);
      Thread(const ::java::lang::ThreadGroup &, const ::java::lang::Runnable &, const ::java::lang::String &, jlong);
      Thread(const ::java::lang::ThreadGroup &, const ::java::lang::Runnable &, const ::java::lang::String &, jlong, jboolean);

      static jint activeCount();
      void checkAccess() const;
      jint countStackFrames() const;
      static Thread currentThread();
      static void dumpStack();
      static jint enumerate(const JArray< Thread > &);
      static ::java::util::Map getAllStackTraces();
      ::java::lang::ClassLoader getContextClassLoader() const;
      static ::java::lang::Thread$UncaughtExceptionHandler getDefaultUncaughtExceptionHandler();
      jlong getId() const;
      ::java::lang::String getName() const;
      jint getPriority() const;
      JArray< ::java::lang::StackTraceElement > getStackTrace() const;
      ::java::lang::Thread$State getState() const;
      ::java::lang::ThreadGroup getThreadGroup() const;
      ::java::lang::Thread$UncaughtExceptionHandler getUncaughtExceptionHandler() const;
      static jboolean holdsLock(const ::java::lang::Object &);
      void interrupt() const;
      static jboolean interrupted();
      jboolean isAlive() const;
      jboolean isDaemon() const;
      jboolean isInterrupted() const;
      jboolean isVirtual() const;
      void join() const;
      void join(jlong) const;
      void join(jlong, jint) const;
      static ::java::lang::Thread$Builder$OfPlatform ofPlatform();
      static ::java::lang::Thread$Builder$OfVirtual ofVirtual();
      static void onSpinWait();
      void resume() const;
      void run() const;
      void setContextClassLoader(const ::java::lang::ClassLoader &) const;
      void setDaemon(jboolean) const;
      static void setDefaultUncaughtExceptionHandler(const ::java::lang::Thread$UncaughtExceptionHandler &);
      void setName(const ::java::lang::String &) const;
      void setPriority(jint) const;
      void setUncaughtExceptionHandler(const ::java::lang::Thread$UncaughtExceptionHandler &) const;
      static void sleep(jlong);
      static void sleep(jlong, jint);
      void start() const;
      static Thread startVirtualThread(const ::java::lang::Runnable &);
      void stop() const;
      void suspend() const;
      jlong threadId() const;
      ::java::lang::String toString() const;
      static void yield();
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Thread);
    extern PyTypeObject *PY_TYPE(Thread);

    class t_Thread {
    public:
      PyObject_HEAD
      Thread object;
      static PyObject *wrap_Object(const Thread&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
