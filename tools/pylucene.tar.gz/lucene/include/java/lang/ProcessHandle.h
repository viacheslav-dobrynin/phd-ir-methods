#ifndef java_lang_ProcessHandle_H
#define java_lang_ProcessHandle_H

#include "java/lang/Comparable.h"

namespace java {
  namespace util {
    namespace concurrent {
      class CompletableFuture;
    }
    class Optional;
  }
  namespace lang {
    class Class;
    class Object;
    class ProcessHandle$Info;
    class ProcessHandle;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class ProcessHandle : public ::java::lang::Comparable {
     public:
      enum {
        mid_compareTo_efe18ad64ca80bb9,
        mid_current_c7dbc166ed3f11a9,
        mid_destroy_201fceb6e9f1d0c5,
        mid_destroyForcibly_201fceb6e9f1d0c5,
        mid_equals_2a09f73f0549554f,
        mid_hashCode_f03edc6a210ac78c,
        mid_info_52c1da8e19ca26a2,
        mid_isAlive_201fceb6e9f1d0c5,
        mid_of_af8d2febbe02993c,
        mid_onExit_35b8f0b05b1fea65,
        mid_parent_5dfa6fdc4ec946c6,
        mid_pid_d192af3db8896a5e,
        mid_supportsNormalTermination_201fceb6e9f1d0c5,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit ProcessHandle(jobject obj) : ::java::lang::Comparable(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      ProcessHandle(const ProcessHandle& obj) : ::java::lang::Comparable(obj) {}

      jint compareTo(const ProcessHandle &) const;
      static ProcessHandle current();
      jboolean destroy() const;
      jboolean destroyForcibly() const;
      jboolean equals(const ::java::lang::Object &) const;
      jint hashCode() const;
      ::java::lang::ProcessHandle$Info info() const;
      jboolean isAlive() const;
      static ::java::util::Optional of(jlong);
      ::java::util::concurrent::CompletableFuture onExit() const;
      ::java::util::Optional parent() const;
      jlong pid() const;
      jboolean supportsNormalTermination() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(ProcessHandle);
    extern PyTypeObject *PY_TYPE(ProcessHandle);

    class t_ProcessHandle {
    public:
      PyObject_HEAD
      ProcessHandle object;
      static PyObject *wrap_Object(const ProcessHandle&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
