#ifndef java_lang_Throwable_H
#define java_lang_Throwable_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class StackTraceElement;
    class Class;
    class String;
    class Throwable;
  }
  namespace io {
    class PrintWriter;
    class PrintStream;
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Throwable : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_9b22ecdee06ea23c,
        mid_init$_c3ba80814cb49dbe,
        mid_addSuppressed_2c40686ddffa78ff,
        mid_fillInStackTrace_f02b1c3defd1579e,
        mid_getCause_f02b1c3defd1579e,
        mid_getLocalizedMessage_cb1e3f35ce7b2bd1,
        mid_getMessage_cb1e3f35ce7b2bd1,
        mid_getStackTrace_c58a5bd159b69443,
        mid_getSuppressed_495223bcc1b666a1,
        mid_initCause_fae9fbb28786638e,
        mid_printStackTrace_a5783a25d44ba15b,
        mid_printStackTrace_334c447f5ff9aeee,
        mid_printStackTrace_acf4a7f2150bf770,
        mid_setStackTrace_d3f080d6670f5c17,
        mid_toString_cb1e3f35ce7b2bd1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Throwable(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Throwable(const Throwable& obj) : ::java::lang::Object(obj) {}

      Throwable();
      Throwable(const ::java::lang::String &);
      Throwable(const ::java::lang::String &, const Throwable &);

      void addSuppressed(const Throwable &) const;
      Throwable fillInStackTrace() const;
      Throwable getCause() const;
      ::java::lang::String getLocalizedMessage() const;
      ::java::lang::String getMessage() const;
      JArray< ::java::lang::StackTraceElement > getStackTrace() const;
      JArray< Throwable > getSuppressed() const;
      Throwable initCause(const Throwable &) const;
      void printStackTrace() const;
      void printStackTrace(const ::java::io::PrintStream &) const;
      void printStackTrace(const ::java::io::PrintWriter &) const;
      void setStackTrace(const JArray< ::java::lang::StackTraceElement > &) const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Throwable);
    extern PyTypeObject *PY_TYPE(Throwable);

    class t_Throwable {
    public:
      PyObject_HEAD
      Throwable object;
      static PyObject *wrap_Object(const Throwable&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
