#ifndef java_lang_Integer_H
#define java_lang_Integer_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class NumberFormatException;
    class Comparable;
    class Integer;
    class Class;
    class String;
    class Object;
    class CharSequence;
  }
  namespace util {
    class Optional;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Integer : public ::java::lang::Number {
     public:
      enum {
        mid_init$_9b22ecdee06ea23c,
        mid_init$_8730ba9dfaf23a7b,
        mid_bitCount_ff66fe240ad72894,
        mid_byteValue_d6f5e90da65461cb,
        mid_compare_103e4c7b2b508548,
        mid_compareTo_c91ad4ba76d90afc,
        mid_compareUnsigned_103e4c7b2b508548,
        mid_compress_103e4c7b2b508548,
        mid_decode_e45e65957650111e,
        mid_describeConstable_5dfa6fdc4ec946c6,
        mid_divideUnsigned_103e4c7b2b508548,
        mid_doubleValue_a6c1144f51bd8892,
        mid_equals_2a09f73f0549554f,
        mid_expand_103e4c7b2b508548,
        mid_floatValue_a9dac2c40463ba96,
        mid_getInteger_e45e65957650111e,
        mid_getInteger_5dd9e98deab5eed3,
        mid_getInteger_852deff104184520,
        mid_hashCode_f03edc6a210ac78c,
        mid_hashCode_ff66fe240ad72894,
        mid_highestOneBit_ff66fe240ad72894,
        mid_intValue_f03edc6a210ac78c,
        mid_longValue_d192af3db8896a5e,
        mid_lowestOneBit_ff66fe240ad72894,
        mid_max_103e4c7b2b508548,
        mid_min_103e4c7b2b508548,
        mid_numberOfLeadingZeros_ff66fe240ad72894,
        mid_numberOfTrailingZeros_ff66fe240ad72894,
        mid_parseInt_164529de03d21944,
        mid_parseInt_fb95a845cd21cbac,
        mid_parseInt_b30923e9a346d60d,
        mid_parseUnsignedInt_164529de03d21944,
        mid_parseUnsignedInt_fb95a845cd21cbac,
        mid_parseUnsignedInt_b30923e9a346d60d,
        mid_remainderUnsigned_103e4c7b2b508548,
        mid_reverse_ff66fe240ad72894,
        mid_reverseBytes_ff66fe240ad72894,
        mid_rotateLeft_103e4c7b2b508548,
        mid_rotateRight_103e4c7b2b508548,
        mid_shortValue_322e7f113b6f2d2a,
        mid_signum_ff66fe240ad72894,
        mid_sum_103e4c7b2b508548,
        mid_toBinaryString_aebd86204175b724,
        mid_toHexString_aebd86204175b724,
        mid_toOctalString_aebd86204175b724,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_toString_aebd86204175b724,
        mid_toString_2b9e4dd3c6e0d2e6,
        mid_toUnsignedLong_ea9b180a0520cdd6,
        mid_toUnsignedString_aebd86204175b724,
        mid_toUnsignedString_2b9e4dd3c6e0d2e6,
        mid_valueOf_e45e65957650111e,
        mid_valueOf_95b57736d13d6d1d,
        mid_valueOf_852deff104184520,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Integer(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Integer(const Integer& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jint MAX_VALUE;
      static jint MIN_VALUE;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Integer(const ::java::lang::String &);
      Integer(jint);

      static jint bitCount(jint);
      jbyte byteValue() const;
      static jint compare(jint, jint);
      jint compareTo(const Integer &) const;
      static jint compareUnsigned(jint, jint);
      static jint compress(jint, jint);
      static Integer decode(const ::java::lang::String &);
      ::java::util::Optional describeConstable() const;
      static jint divideUnsigned(jint, jint);
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      static jint expand(jint, jint);
      jfloat floatValue() const;
      static Integer getInteger(const ::java::lang::String &);
      static Integer getInteger(const ::java::lang::String &, const Integer &);
      static Integer getInteger(const ::java::lang::String &, jint);
      jint hashCode() const;
      static jint hashCode(jint);
      static jint highestOneBit(jint);
      jint intValue() const;
      jlong longValue() const;
      static jint lowestOneBit(jint);
      static jint max$(jint, jint);
      static jint min$(jint, jint);
      static jint numberOfLeadingZeros(jint);
      static jint numberOfTrailingZeros(jint);
      static jint parseInt(const ::java::lang::String &);
      static jint parseInt(const ::java::lang::String &, jint);
      static jint parseInt(const ::java::lang::CharSequence &, jint, jint, jint);
      static jint parseUnsignedInt(const ::java::lang::String &);
      static jint parseUnsignedInt(const ::java::lang::String &, jint);
      static jint parseUnsignedInt(const ::java::lang::CharSequence &, jint, jint, jint);
      static jint remainderUnsigned(jint, jint);
      static jint reverse(jint);
      static jint reverseBytes(jint);
      static jint rotateLeft(jint, jint);
      static jint rotateRight(jint, jint);
      jshort shortValue() const;
      static jint signum(jint);
      static jint sum(jint, jint);
      static ::java::lang::String toBinaryString(jint);
      static ::java::lang::String toHexString(jint);
      static ::java::lang::String toOctalString(jint);
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jint);
      static ::java::lang::String toString(jint, jint);
      static jlong toUnsignedLong(jint);
      static ::java::lang::String toUnsignedString(jint);
      static ::java::lang::String toUnsignedString(jint, jint);
      static Integer valueOf(const ::java::lang::String &);
      static Integer valueOf(jint);
      static Integer valueOf(const ::java::lang::String &, jint);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Integer);
    extern PyTypeObject *PY_TYPE(Integer);

    class t_Integer {
    public:
      PyObject_HEAD
      Integer object;
      static PyObject *wrap_Object(const Integer&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
