#ifndef java_lang_Object_H
#define java_lang_Object_H

#include "JObject.h"

namespace java {
  namespace lang {
    class String;
    class Object;
    class InterruptedException;
    class Class;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Object : public ::JObject {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_equals_2a09f73f0549554f,
        mid_getClass_fdc882531907d38a,
        mid_hashCode_f03edc6a210ac78c,
        mid_notify_a5783a25d44ba15b,
        mid_notifyAll_a5783a25d44ba15b,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_wait_a5783a25d44ba15b,
        mid_wait_270332bbfd4dc523,
        mid_wait_ca843eab9241c96e,
        mid_finalize_a5783a25d44ba15b,
        mid_clone_1543ec1f1674e5aa,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Object(jobject obj) : ::JObject(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Object(const Object& obj) : ::JObject(obj) {}

      Object();

      jboolean equals(const Object &) const;
      ::java::lang::Class getClass() const;
      jint hashCode() const;
      void notify() const;
      void notifyAll() const;
      ::java::lang::String toString() const;
      void wait() const;
      void wait(jlong) const;
      void wait(jlong, jint) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Object);
    extern PyTypeObject *PY_TYPE(Object);

    class t_Object {
    public:
      PyObject_HEAD
      Object object;
      static PyObject *wrap_Object(const Object&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
