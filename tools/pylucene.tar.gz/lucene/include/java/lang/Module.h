#ifndef java_lang_Module_H
#define java_lang_Module_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class Class;
    class String;
    class Module;
    class ModuleLayer;
    class ClassLoader;
  }
  namespace util {
    class Set;
  }
  namespace io {
    class IOException;
    class InputStream;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Module : public ::java::lang::Object {
     public:
      enum {
        mid_addExports_9da01f2507e832d5,
        mid_addOpens_9da01f2507e832d5,
        mid_addReads_c2efeb4eec81a893,
        mid_addUses_77dc5ac37644461b,
        mid_canRead_6f7a10abeea8b270,
        mid_canUse_5bd42822be1cf6db,
        mid_getClassLoader_872562251d2105b9,
        mid_getLayer_a514d2d2399628b3,
        mid_getName_cb1e3f35ce7b2bd1,
        mid_getPackages_9cfd5750b6ef4685,
        mid_getResourceAsStream_23dd608c97688dfd,
        mid_isExported_7585662e3a5cb869,
        mid_isExported_9778fc60aeadc379,
        mid_isNamed_201fceb6e9f1d0c5,
        mid_isNativeAccessEnabled_201fceb6e9f1d0c5,
        mid_isOpen_7585662e3a5cb869,
        mid_isOpen_9778fc60aeadc379,
        mid_toString_cb1e3f35ce7b2bd1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Module(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Module(const Module& obj) : ::java::lang::Object(obj) {}

      Module addExports(const ::java::lang::String &, const Module &) const;
      Module addOpens(const ::java::lang::String &, const Module &) const;
      Module addReads(const Module &) const;
      Module addUses(const ::java::lang::Class &) const;
      jboolean canRead(const Module &) const;
      jboolean canUse(const ::java::lang::Class &) const;
      ::java::lang::ClassLoader getClassLoader() const;
      ::java::lang::ModuleLayer getLayer() const;
      ::java::lang::String getName() const;
      ::java::util::Set getPackages() const;
      ::java::io::InputStream getResourceAsStream(const ::java::lang::String &) const;
      jboolean isExported(const ::java::lang::String &) const;
      jboolean isExported(const ::java::lang::String &, const Module &) const;
      jboolean isNamed() const;
      jboolean isNativeAccessEnabled() const;
      jboolean isOpen(const ::java::lang::String &) const;
      jboolean isOpen(const ::java::lang::String &, const Module &) const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Module);
    extern PyTypeObject *PY_TYPE(Module);

    class t_Module {
    public:
      PyObject_HEAD
      Module object;
      static PyObject *wrap_Object(const Module&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
