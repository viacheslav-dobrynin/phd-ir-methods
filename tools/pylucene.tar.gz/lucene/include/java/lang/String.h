#ifndef java_lang_String_H
#define java_lang_String_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    class Comparator;
    class Optional;
    class Locale;
    namespace function {
      class Function;
    }
  }
  namespace lang {
    class Iterable;
    class Comparable;
    class Class;
    class String;
    class CharSequence;
    class StringBuilder;
    class StringBuffer;
  }
  namespace io {
    class UnsupportedEncodingException;
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class String : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_d09edbbd30f45052,
        mid_init$_0888ce519724b72c,
        mid_init$_5cb5ede3b794e9e0,
        mid_init$_ce2f97877c2b0911,
        mid_init$_5b939ef95f5ba7c2,
        mid_init$_e5bd0017ffefcc8f,
        mid_init$_c2a753a75ddc609c,
        mid_init$_4640b6b0a50abfea,
        mid_init$_de88236c88dbfb1b,
        mid_init$_62083be81c03586a,
        mid_init$_8bda9338dcc627a7,
        mid_charAt_0b9831c04f367f5c,
        mid_codePointAt_ff66fe240ad72894,
        mid_codePointBefore_ff66fe240ad72894,
        mid_codePointCount_103e4c7b2b508548,
        mid_compareTo_164529de03d21944,
        mid_compareToIgnoreCase_164529de03d21944,
        mid_concat_4fd613927a288526,
        mid_contains_e954bdc5b64f5e34,
        mid_contentEquals_a9c3f81f4cfd0b53,
        mid_contentEquals_e954bdc5b64f5e34,
        mid_copyValueOf_8771d71efbfe1c9c,
        mid_copyValueOf_0b9bfdc50ab4cc32,
        mid_describeConstable_5dfa6fdc4ec946c6,
        mid_endsWith_7585662e3a5cb869,
        mid_equals_2a09f73f0549554f,
        mid_equalsIgnoreCase_7585662e3a5cb869,
        mid_format_1295241fdc998ab7,
        mid_format_3296cacffd9ddcb7,
        mid_formatted_fd086fa2107bd22c,
        mid_getBytes_9d49388b39cc642b,
        mid_getBytes_e18b10fb4c27ec3a,
        mid_getBytes_ebb5efdcbc4f2930,
        mid_getChars_cb528f2a42e4954d,
        mid_hashCode_f03edc6a210ac78c,
        mid_indent_aebd86204175b724,
        mid_indexOf_164529de03d21944,
        mid_indexOf_ff66fe240ad72894,
        mid_indexOf_fb95a845cd21cbac,
        mid_indexOf_103e4c7b2b508548,
        mid_indexOf_1d406781885e6e74,
        mid_indexOf_bcec83214ce6fc4d,
        mid_intern_cb1e3f35ce7b2bd1,
        mid_isBlank_201fceb6e9f1d0c5,
        mid_isEmpty_201fceb6e9f1d0c5,
        mid_join_9aa0a5ff055583d4,
        mid_join_c45e5285aad6d9cc,
        mid_lastIndexOf_164529de03d21944,
        mid_lastIndexOf_ff66fe240ad72894,
        mid_lastIndexOf_fb95a845cd21cbac,
        mid_lastIndexOf_103e4c7b2b508548,
        mid_length_f03edc6a210ac78c,
        mid_matches_7585662e3a5cb869,
        mid_offsetByCodePoints_103e4c7b2b508548,
        mid_regionMatches_600b4d8deef35948,
        mid_regionMatches_13b4856e4220dd3f,
        mid_repeat_aebd86204175b724,
        mid_replace_d060cd14b82d302a,
        mid_replace_f18f5428d4d7bdb2,
        mid_replaceAll_5132ab8c6032328c,
        mid_replaceFirst_5132ab8c6032328c,
        mid_split_57dcd2e1ad8b9098,
        mid_split_6e31482e0f7c6be9,
        mid_splitWithDelimiters_6e31482e0f7c6be9,
        mid_startsWith_7585662e3a5cb869,
        mid_startsWith_f079f4c4341c83ab,
        mid_strip_cb1e3f35ce7b2bd1,
        mid_stripIndent_cb1e3f35ce7b2bd1,
        mid_stripLeading_cb1e3f35ce7b2bd1,
        mid_stripTrailing_cb1e3f35ce7b2bd1,
        mid_subSequence_2af0256e00da87ed,
        mid_substring_aebd86204175b724,
        mid_substring_2b9e4dd3c6e0d2e6,
        mid_toCharArray_de6d194e81f65e82,
        mid_toLowerCase_cb1e3f35ce7b2bd1,
        mid_toLowerCase_e3e73dfada614e4b,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_toUpperCase_cb1e3f35ce7b2bd1,
        mid_toUpperCase_e3e73dfada614e4b,
        mid_transform_6ee24d13812d81ad,
        mid_translateEscapes_cb1e3f35ce7b2bd1,
        mid_trim_cb1e3f35ce7b2bd1,
        mid_valueOf_8771d71efbfe1c9c,
        mid_valueOf_68fa91587e49b2cd,
        mid_valueOf_82edd1789d1cc009,
        mid_valueOf_74f601c4b6f2da5a,
        mid_valueOf_217cc04a7fe6b835,
        mid_valueOf_aebd86204175b724,
        mid_valueOf_ab94fa0faf1a0844,
        mid_valueOf_3bbdb48ea758edad,
        mid_valueOf_0b9bfdc50ab4cc32,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit String(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      String(const String& obj) : ::java::lang::Object(obj) {}

      static ::java::util::Comparator *CASE_INSENSITIVE_ORDER;

      String();
      String(const ::java::lang::StringBuffer &);
      String(const ::java::lang::StringBuilder &);
      String(const JArray< jbyte > &);
      String(const JArray< jchar > &);
      String(const JArray< jbyte > &, const String &);
      String(const JArray< jbyte > &, jint);
      String(const JArray< jbyte > &, jint, jint);
      String(const JArray< jchar > &, jint, jint);
      String(const JArray< jint > &, jint, jint);
      String(const JArray< jbyte > &, jint, jint, const String &);
      String(const JArray< jbyte > &, jint, jint, jint);

      jchar charAt(jint) const;
      jint codePointAt(jint) const;
      jint codePointBefore(jint) const;
      jint codePointCount(jint, jint) const;
      jint compareTo(const String &) const;
      jint compareToIgnoreCase(const String &) const;
      String concat(const String &) const;
      jboolean contains(const ::java::lang::CharSequence &) const;
      jboolean contentEquals(const ::java::lang::StringBuffer &) const;
      jboolean contentEquals(const ::java::lang::CharSequence &) const;
      static String copyValueOf(const JArray< jchar > &);
      static String copyValueOf(const JArray< jchar > &, jint, jint);
      ::java::util::Optional describeConstable() const;
      jboolean endsWith(const String &) const;
      jboolean equals(const ::java::lang::Object &) const;
      jboolean equalsIgnoreCase(const String &) const;
      static String format(const String &, const JArray< ::java::lang::Object > &);
      static String format(const ::java::util::Locale &, const String &, const JArray< ::java::lang::Object > &);
      String formatted(const JArray< ::java::lang::Object > &) const;
      JArray< jbyte > getBytes() const;
      JArray< jbyte > getBytes(const String &) const;
      void getBytes(jint, jint, const JArray< jbyte > &, jint) const;
      void getChars(jint, jint, const JArray< jchar > &, jint) const;
      jint hashCode() const;
      String indent(jint) const;
      jint indexOf(const String &) const;
      jint indexOf(jint) const;
      jint indexOf(const String &, jint) const;
      jint indexOf(jint, jint) const;
      jint indexOf(const String &, jint, jint) const;
      jint indexOf(jint, jint, jint) const;
      String intern() const;
      jboolean isBlank() const;
      jboolean isEmpty() const;
      static String join(const ::java::lang::CharSequence &, const JArray< ::java::lang::CharSequence > &);
      static String join(const ::java::lang::CharSequence &, const ::java::lang::Iterable &);
      jint lastIndexOf(const String &) const;
      jint lastIndexOf(jint) const;
      jint lastIndexOf(const String &, jint) const;
      jint lastIndexOf(jint, jint) const;
      jint length() const;
      jboolean matches(const String &) const;
      jint offsetByCodePoints(jint, jint) const;
      jboolean regionMatches(jint, const String &, jint, jint) const;
      jboolean regionMatches(jboolean, jint, const String &, jint, jint) const;
      String repeat(jint) const;
      String replace(jchar, jchar) const;
      String replace(const ::java::lang::CharSequence &, const ::java::lang::CharSequence &) const;
      String replaceAll(const String &, const String &) const;
      String replaceFirst(const String &, const String &) const;
      JArray< String > split(const String &) const;
      JArray< String > split(const String &, jint) const;
      JArray< String > splitWithDelimiters(const String &, jint) const;
      jboolean startsWith(const String &) const;
      jboolean startsWith(const String &, jint) const;
      String strip() const;
      String stripIndent() const;
      String stripLeading() const;
      String stripTrailing() const;
      ::java::lang::CharSequence subSequence(jint, jint) const;
      String substring(jint) const;
      String substring(jint, jint) const;
      JArray< jchar > toCharArray() const;
      String toLowerCase() const;
      String toLowerCase(const ::java::util::Locale &) const;
      String toString() const;
      String toUpperCase() const;
      String toUpperCase(const ::java::util::Locale &) const;
      ::java::lang::Object transform(const ::java::util::function::Function &) const;
      String translateEscapes() const;
      String trim() const;
      static String valueOf(const JArray< jchar > &);
      static String valueOf(jboolean);
      static String valueOf(jchar);
      static String valueOf(jdouble);
      static String valueOf(jfloat);
      static String valueOf(jint);
      static String valueOf(const ::java::lang::Object &);
      static String valueOf(jlong);
      static String valueOf(const JArray< jchar > &, jint, jint);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(String);
    extern PyTypeObject *PY_TYPE(String);

    class t_String {
    public:
      PyObject_HEAD
      String object;
      static PyObject *wrap_Object(const String&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
