#ifndef java_lang_ClassLoader_H
#define java_lang_ClassLoader_H

#include "java/lang/Object.h"

namespace java {
  namespace lang {
    class ClassNotFoundException;
    class Class;
    class String;
    class Package;
    class Module;
    class ClassLoader;
  }
  namespace io {
    class InputStream;
  }
  namespace util {
    class Enumeration;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class ClassLoader : public ::java::lang::Object {
     public:
      enum {
        mid_clearAssertionStatus_a5783a25d44ba15b,
        mid_getDefinedPackage_f51db747fc427905,
        mid_getDefinedPackages_3e486c1526386594,
        mid_getName_cb1e3f35ce7b2bd1,
        mid_getParent_872562251d2105b9,
        mid_getPlatformClassLoader_872562251d2105b9,
        mid_getResourceAsStream_23dd608c97688dfd,
        mid_getSystemClassLoader_872562251d2105b9,
        mid_getSystemResourceAsStream_23dd608c97688dfd,
        mid_getUnnamedModule_b4ec989574f2ee68,
        mid_isRegisteredAsParallelCapable_201fceb6e9f1d0c5,
        mid_loadClass_fbda6142847f0acf,
        mid_setClassAssertionStatus_9155751da0793cda,
        mid_setDefaultAssertionStatus_a5b6a940fc16c6a1,
        mid_setPackageAssertionStatus_9155751da0793cda,
        mid_loadClass_def4f5efc4c45b94,
        mid_definePackage_924b0358fdf1ce0e,
        mid_findResource_721b072226cb99d9,
        mid_findResource_abef3fef603a333f,
        mid_getPackage_f51db747fc427905,
        mid_setSigners_3cb4cd75976df55f,
        mid_getClassLoadingLock_374166fc5538a93c,
        mid_findLoadedClass_fbda6142847f0acf,
        mid_findClass_fbda6142847f0acf,
        mid_findClass_9c1d20c7b461bcbe,
        mid_resolveClass_028809e75bfdf012,
        mid_defineClass_e30db7cd9f114d5c,
        mid_defineClass_8e324781960d5f59,
        mid_defineClass_1c9a982cec95aa41,
        mid_defineClass_f58eeaa5d7e45ff1,
        mid_findResources_01d08eeb9987a9cc,
        mid_registerAsParallelCapable_201fceb6e9f1d0c5,
        mid_findLibrary_4fd613927a288526,
        mid_findSystemClass_fbda6142847f0acf,
        mid_getPackages_3e486c1526386594,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit ClassLoader(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      ClassLoader(const ClassLoader& obj) : ::java::lang::Object(obj) {}

      void clearAssertionStatus() const;
      ::java::lang::Package getDefinedPackage(const ::java::lang::String &) const;
      JArray< ::java::lang::Package > getDefinedPackages() const;
      ::java::lang::String getName() const;
      ClassLoader getParent() const;
      static ClassLoader getPlatformClassLoader();
      ::java::io::InputStream getResourceAsStream(const ::java::lang::String &) const;
      static ClassLoader getSystemClassLoader();
      static ::java::io::InputStream getSystemResourceAsStream(const ::java::lang::String &);
      ::java::lang::Module getUnnamedModule() const;
      jboolean isRegisteredAsParallelCapable() const;
      ::java::lang::Class loadClass(const ::java::lang::String &) const;
      void setClassAssertionStatus(const ::java::lang::String &, jboolean) const;
      void setDefaultAssertionStatus(jboolean) const;
      void setPackageAssertionStatus(const ::java::lang::String &, jboolean) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(ClassLoader);
    extern PyTypeObject *PY_TYPE(ClassLoader);

    class t_ClassLoader {
    public:
      PyObject_HEAD
      ClassLoader object;
      static PyObject *wrap_Object(const ClassLoader&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
