#ifndef java_lang_Byte_H
#define java_lang_Byte_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class NumberFormatException;
    class Comparable;
    class Class;
    class String;
    class Object;
    class Byte;
  }
  namespace util {
    class Optional;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Byte : public ::java::lang::Number {
     public:
      enum {
        mid_init$_9b22ecdee06ea23c,
        mid_init$_87f93f7960689e94,
        mid_byteValue_d6f5e90da65461cb,
        mid_compare_3f4849adee9561c6,
        mid_compareTo_0746fbb7a15cec8a,
        mid_compareUnsigned_3f4849adee9561c6,
        mid_decode_88914eca55bcbd3d,
        mid_doubleValue_a6c1144f51bd8892,
        mid_equals_2a09f73f0549554f,
        mid_floatValue_a9dac2c40463ba96,
        mid_hashCode_f03edc6a210ac78c,
        mid_hashCode_8f80bda0981eacfd,
        mid_intValue_f03edc6a210ac78c,
        mid_longValue_d192af3db8896a5e,
        mid_parseByte_b32f21c95c3472c5,
        mid_parseByte_731adcc6e3c3e38b,
        mid_shortValue_322e7f113b6f2d2a,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_toString_1d3d85c9ba42b67a,
        mid_toUnsignedInt_8f80bda0981eacfd,
        mid_toUnsignedLong_1aa6af66970658c3,
        mid_valueOf_88914eca55bcbd3d,
        mid_valueOf_dc25b3a40beb6f66,
        mid_valueOf_73ba805d312cbf10,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Byte(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Byte(const Byte& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jbyte MAX_VALUE;
      static jbyte MIN_VALUE;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Byte(const ::java::lang::String &);
      Byte(jbyte);

      jbyte byteValue() const;
      static jint compare(jbyte, jbyte);
      jint compareTo(const Byte &) const;
      static jint compareUnsigned(jbyte, jbyte);
      static Byte decode(const ::java::lang::String &);
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      jfloat floatValue() const;
      jint hashCode() const;
      static jint hashCode(jbyte);
      jint intValue() const;
      jlong longValue() const;
      static jbyte parseByte(const ::java::lang::String &);
      static jbyte parseByte(const ::java::lang::String &, jint);
      jshort shortValue() const;
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jbyte);
      static jint toUnsignedInt(jbyte);
      static jlong toUnsignedLong(jbyte);
      static Byte valueOf(const ::java::lang::String &);
      static Byte valueOf(jbyte);
      static Byte valueOf(const ::java::lang::String &, jint);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Byte);
    extern PyTypeObject *PY_TYPE(Byte);

    class t_Byte {
    public:
      PyObject_HEAD
      Byte object;
      static PyObject *wrap_Object(const Byte&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
