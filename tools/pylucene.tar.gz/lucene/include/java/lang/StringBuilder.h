#ifndef java_lang_StringBuilder_H
#define java_lang_StringBuilder_H

#include "java/lang/AbstractStringBuilder.h"

namespace java {
  namespace lang {
    class Comparable;
    class Class;
    class String;
    class CharSequence;
    class Object;
    class StringBuilder;
    class StringBuffer;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class StringBuilder : public ::java::lang::AbstractStringBuilder {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_9b22ecdee06ea23c,
        mid_init$_8730ba9dfaf23a7b,
        mid_init$_c3de4787507adac3,
        mid_append_9496c95671be8dda,
        mid_append_d8fc140c51ae720b,
        mid_append_bb05e76d32a97908,
        mid_append_6963ff9292ec32fe,
        mid_append_ef3d48b4858da92c,
        mid_append_87f850229722a605,
        mid_append_3d3a30259ddbb2a3,
        mid_append_2cf1e32a8f42a3cf,
        mid_append_a6e05fd02e4e27bb,
        mid_append_1579e83086afee22,
        mid_append_fd185631ab133538,
        mid_append_36a08575fe1d0fcb,
        mid_append_139a8ffbd5d55153,
        mid_appendCodePoint_2cf1e32a8f42a3cf,
        mid_compareTo_f8f4e15027a8b126,
        mid_delete_90808bbb238fd169,
        mid_deleteCharAt_2cf1e32a8f42a3cf,
        mid_indexOf_164529de03d21944,
        mid_indexOf_fb95a845cd21cbac,
        mid_insert_50f8f1c1a1f2399d,
        mid_insert_d24fb3f03f311b11,
        mid_insert_eab348982892d28c,
        mid_insert_51ac86e2a8f1ea28,
        mid_insert_4b7ea9113cc5048b,
        mid_insert_8c510495dc39d59d,
        mid_insert_90808bbb238fd169,
        mid_insert_f2a804e42bc45a28,
        mid_insert_5f6c9e8a8dcec4be,
        mid_insert_3ca5a3167d3bd894,
        mid_insert_47d47e4ecddc5cde,
        mid_insert_71d3de9907d15c03,
        mid_lastIndexOf_164529de03d21944,
        mid_lastIndexOf_fb95a845cd21cbac,
        mid_repeat_90808bbb238fd169,
        mid_repeat_d9778a1b493f53f2,
        mid_replace_b1dd7e11ba145601,
        mid_reverse_0b10b545dc7b84c3,
        mid_toString_cb1e3f35ce7b2bd1,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit StringBuilder(jobject obj) : ::java::lang::AbstractStringBuilder(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      StringBuilder(const StringBuilder& obj) : ::java::lang::AbstractStringBuilder(obj) {}

      StringBuilder();
      StringBuilder(const ::java::lang::String &);
      StringBuilder(jint);
      StringBuilder(const ::java::lang::CharSequence &);

      StringBuilder append(const ::java::lang::StringBuffer &) const;
      StringBuilder append(const JArray< jchar > &) const;
      StringBuilder append(const ::java::lang::String &) const;
      StringBuilder append(jboolean) const;
      StringBuilder append(jchar) const;
      StringBuilder append(jdouble) const;
      StringBuilder append(jfloat) const;
      StringBuilder append(jint) const;
      StringBuilder append(const ::java::lang::CharSequence &) const;
      StringBuilder append(const ::java::lang::Object &) const;
      StringBuilder append(jlong) const;
      StringBuilder append(const JArray< jchar > &, jint, jint) const;
      StringBuilder append(const ::java::lang::CharSequence &, jint, jint) const;
      StringBuilder appendCodePoint(jint) const;
      jint compareTo(const StringBuilder &) const;
      StringBuilder delete$(jint, jint) const;
      StringBuilder deleteCharAt(jint) const;
      jint indexOf(const ::java::lang::String &) const;
      jint indexOf(const ::java::lang::String &, jint) const;
      StringBuilder insert(jint, const JArray< jchar > &) const;
      StringBuilder insert(jint, const ::java::lang::String &) const;
      StringBuilder insert(jint, jboolean) const;
      StringBuilder insert(jint, jchar) const;
      StringBuilder insert(jint, jdouble) const;
      StringBuilder insert(jint, jfloat) const;
      StringBuilder insert(jint, jint) const;
      StringBuilder insert(jint, const ::java::lang::CharSequence &) const;
      StringBuilder insert(jint, const ::java::lang::Object &) const;
      StringBuilder insert(jint, jlong) const;
      StringBuilder insert(jint, const JArray< jchar > &, jint, jint) const;
      StringBuilder insert(jint, const ::java::lang::CharSequence &, jint, jint) const;
      jint lastIndexOf(const ::java::lang::String &) const;
      jint lastIndexOf(const ::java::lang::String &, jint) const;
      StringBuilder repeat(jint, jint) const;
      StringBuilder repeat(const ::java::lang::CharSequence &, jint) const;
      StringBuilder replace(jint, jint, const ::java::lang::String &) const;
      StringBuilder reverse() const;
      ::java::lang::String toString() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(StringBuilder);
    extern PyTypeObject *PY_TYPE(StringBuilder);

    class t_StringBuilder {
    public:
      PyObject_HEAD
      StringBuilder object;
      static PyObject *wrap_Object(const StringBuilder&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
