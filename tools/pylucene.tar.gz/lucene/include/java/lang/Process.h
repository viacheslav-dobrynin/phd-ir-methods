#ifndef java_lang_Process_H
#define java_lang_Process_H

#include "java/lang/Object.h"

namespace java {
  namespace util {
    namespace concurrent {
      class CompletableFuture;
      class TimeUnit;
    }
  }
  namespace io {
    class OutputStream;
    class BufferedReader;
    class InputStream;
    class BufferedWriter;
  }
  namespace lang {
    class Class;
    class Process;
    class InterruptedException;
    class ProcessHandle$Info;
    class ProcessHandle;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Process : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_destroy_a5783a25d44ba15b,
        mid_destroyForcibly_44002808075394ce,
        mid_errorReader_689f67ca6948bdc3,
        mid_exitValue_f03edc6a210ac78c,
        mid_getErrorStream_84a16f85c5c7542b,
        mid_getInputStream_84a16f85c5c7542b,
        mid_getOutputStream_723865f64f8ab01d,
        mid_info_52c1da8e19ca26a2,
        mid_inputReader_689f67ca6948bdc3,
        mid_isAlive_201fceb6e9f1d0c5,
        mid_onExit_35b8f0b05b1fea65,
        mid_outputWriter_1a6ad054cea41e7a,
        mid_pid_d192af3db8896a5e,
        mid_supportsNormalTermination_201fceb6e9f1d0c5,
        mid_toHandle_c7dbc166ed3f11a9,
        mid_waitFor_f03edc6a210ac78c,
        mid_waitFor_b926844730e4bbc5,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Process(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Process(const Process& obj) : ::java::lang::Object(obj) {}

      Process();

      void destroy() const;
      Process destroyForcibly() const;
      ::java::io::BufferedReader errorReader() const;
      jint exitValue() const;
      ::java::io::InputStream getErrorStream() const;
      ::java::io::InputStream getInputStream() const;
      ::java::io::OutputStream getOutputStream() const;
      ::java::lang::ProcessHandle$Info info() const;
      ::java::io::BufferedReader inputReader() const;
      jboolean isAlive() const;
      ::java::util::concurrent::CompletableFuture onExit() const;
      ::java::io::BufferedWriter outputWriter() const;
      jlong pid() const;
      jboolean supportsNormalTermination() const;
      ::java::lang::ProcessHandle toHandle() const;
      jint waitFor() const;
      jboolean waitFor(jlong, const ::java::util::concurrent::TimeUnit &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Process);
    extern PyTypeObject *PY_TYPE(Process);

    class t_Process {
    public:
      PyObject_HEAD
      Process object;
      static PyObject *wrap_Object(const Process&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
