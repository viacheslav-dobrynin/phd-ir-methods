#ifndef java_lang_Short_H
#define java_lang_Short_H

#include "java/lang/Number.h"

namespace java {
  namespace lang {
    class Short;
    class NumberFormatException;
    class Comparable;
    class Class;
    class String;
    class Object;
  }
  namespace util {
    class Optional;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Short : public ::java::lang::Number {
     public:
      enum {
        mid_init$_9b22ecdee06ea23c,
        mid_init$_0858ff88a9f74679,
        mid_byteValue_d6f5e90da65461cb,
        mid_compare_c8cb7e24b3cde97c,
        mid_compareTo_6661fc03bbd199bd,
        mid_compareUnsigned_c8cb7e24b3cde97c,
        mid_decode_cbc08e2c960c4485,
        mid_doubleValue_a6c1144f51bd8892,
        mid_equals_2a09f73f0549554f,
        mid_floatValue_a9dac2c40463ba96,
        mid_hashCode_f03edc6a210ac78c,
        mid_hashCode_f5dfe0ea0327d9df,
        mid_intValue_f03edc6a210ac78c,
        mid_longValue_d192af3db8896a5e,
        mid_parseShort_1a0e7f765ca084c1,
        mid_parseShort_fad7d7771416ff39,
        mid_reverseBytes_39966eb93a768a55,
        mid_shortValue_322e7f113b6f2d2a,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_toString_b1ffa07c7da0bb38,
        mid_toUnsignedInt_f5dfe0ea0327d9df,
        mid_toUnsignedLong_1b716cfb7df6bfb1,
        mid_valueOf_cbc08e2c960c4485,
        mid_valueOf_ed4cd6da25a10126,
        mid_valueOf_6f24e93c911200e4,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Short(jobject obj) : ::java::lang::Number(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Short(const Short& obj) : ::java::lang::Number(obj) {}

      static jint BYTES;
      static jshort MAX_VALUE;
      static jshort MIN_VALUE;
      static jint SIZE;
      static ::java::lang::Class *TYPE;

      Short(const ::java::lang::String &);
      Short(jshort);

      jbyte byteValue() const;
      static jint compare(jshort, jshort);
      jint compareTo(const Short &) const;
      static jint compareUnsigned(jshort, jshort);
      static Short decode(const ::java::lang::String &);
      jdouble doubleValue() const;
      jboolean equals(const ::java::lang::Object &) const;
      jfloat floatValue() const;
      jint hashCode() const;
      static jint hashCode(jshort);
      jint intValue() const;
      jlong longValue() const;
      static jshort parseShort(const ::java::lang::String &);
      static jshort parseShort(const ::java::lang::String &, jint);
      static jshort reverseBytes(jshort);
      jshort shortValue() const;
      ::java::lang::String toString() const;
      static ::java::lang::String toString(jshort);
      static jint toUnsignedInt(jshort);
      static jlong toUnsignedLong(jshort);
      static Short valueOf(const ::java::lang::String &);
      static Short valueOf(jshort);
      static Short valueOf(const ::java::lang::String &, jint);
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Short);
    extern PyTypeObject *PY_TYPE(Short);

    class t_Short {
    public:
      PyObject_HEAD
      Short object;
      static PyObject *wrap_Object(const Short&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
