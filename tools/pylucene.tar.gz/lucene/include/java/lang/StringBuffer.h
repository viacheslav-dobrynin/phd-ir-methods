#ifndef java_lang_StringBuffer_H
#define java_lang_StringBuffer_H

#include "java/lang/AbstractStringBuilder.h"

namespace java {
  namespace lang {
    class Comparable;
    class Class;
    class String;
    class CharSequence;
    class Object;
    class StringBuffer;
  }
  namespace io {
    class Serializable;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class StringBuffer : public ::java::lang::AbstractStringBuilder {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_init$_9b22ecdee06ea23c,
        mid_init$_8730ba9dfaf23a7b,
        mid_init$_c3de4787507adac3,
        mid_append_8c5af213ff271496,
        mid_append_a6b02d401636329f,
        mid_append_5cfaa4f8e488d96b,
        mid_append_bce24d2a2eecf992,
        mid_append_6a70cd07d485dcf9,
        mid_append_b90dd984638f8ddc,
        mid_append_fa075d0bd4767234,
        mid_append_8d6a9e8e16edb1d8,
        mid_append_b39b80b9399a48bf,
        mid_append_262761c0169017ca,
        mid_append_f9de5b2d865f0576,
        mid_append_8e129bf600aea012,
        mid_append_1278937688e003c9,
        mid_appendCodePoint_8d6a9e8e16edb1d8,
        mid_capacity_f03edc6a210ac78c,
        mid_charAt_0b9831c04f367f5c,
        mid_codePointAt_ff66fe240ad72894,
        mid_codePointBefore_ff66fe240ad72894,
        mid_codePointCount_103e4c7b2b508548,
        mid_compareTo_87bf3096acae55f7,
        mid_delete_fb7d4210d676694f,
        mid_deleteCharAt_8d6a9e8e16edb1d8,
        mid_ensureCapacity_8730ba9dfaf23a7b,
        mid_getChars_cb528f2a42e4954d,
        mid_indexOf_164529de03d21944,
        mid_indexOf_fb95a845cd21cbac,
        mid_insert_ad9d3f20c010f692,
        mid_insert_9978c75042bee116,
        mid_insert_9a0c972d6fef1cba,
        mid_insert_5b225393479ec620,
        mid_insert_75bd13d86b15398a,
        mid_insert_565a9ca2ea4b5581,
        mid_insert_fb7d4210d676694f,
        mid_insert_88660f86a928006a,
        mid_insert_f3db55d319833ae7,
        mid_insert_d7d9fe64b140a6e9,
        mid_insert_421aca1d2afa85b1,
        mid_insert_d738c4cedf01ec63,
        mid_lastIndexOf_164529de03d21944,
        mid_lastIndexOf_fb95a845cd21cbac,
        mid_length_f03edc6a210ac78c,
        mid_offsetByCodePoints_103e4c7b2b508548,
        mid_repeat_fb7d4210d676694f,
        mid_repeat_7d52ac361d2e7f86,
        mid_replace_bc3e3a83b5ccd988,
        mid_reverse_6916934d714637ac,
        mid_setCharAt_fce6db950fe18d1c,
        mid_setLength_8730ba9dfaf23a7b,
        mid_subSequence_2af0256e00da87ed,
        mid_substring_aebd86204175b724,
        mid_substring_2b9e4dd3c6e0d2e6,
        mid_toString_cb1e3f35ce7b2bd1,
        mid_trimToSize_a5783a25d44ba15b,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit StringBuffer(jobject obj) : ::java::lang::AbstractStringBuilder(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      StringBuffer(const StringBuffer& obj) : ::java::lang::AbstractStringBuilder(obj) {}

      StringBuffer();
      StringBuffer(const ::java::lang::String &);
      StringBuffer(jint);
      StringBuffer(const ::java::lang::CharSequence &);

      StringBuffer append(const StringBuffer &) const;
      StringBuffer append(const JArray< jchar > &) const;
      StringBuffer append(const ::java::lang::String &) const;
      StringBuffer append(jboolean) const;
      StringBuffer append(jchar) const;
      StringBuffer append(jdouble) const;
      StringBuffer append(jfloat) const;
      StringBuffer append(jint) const;
      StringBuffer append(const ::java::lang::CharSequence &) const;
      StringBuffer append(const ::java::lang::Object &) const;
      StringBuffer append(jlong) const;
      StringBuffer append(const JArray< jchar > &, jint, jint) const;
      StringBuffer append(const ::java::lang::CharSequence &, jint, jint) const;
      StringBuffer appendCodePoint(jint) const;
      jint capacity() const;
      jchar charAt(jint) const;
      jint codePointAt(jint) const;
      jint codePointBefore(jint) const;
      jint codePointCount(jint, jint) const;
      jint compareTo(const StringBuffer &) const;
      StringBuffer delete$(jint, jint) const;
      StringBuffer deleteCharAt(jint) const;
      void ensureCapacity(jint) const;
      void getChars(jint, jint, const JArray< jchar > &, jint) const;
      jint indexOf(const ::java::lang::String &) const;
      jint indexOf(const ::java::lang::String &, jint) const;
      StringBuffer insert(jint, const JArray< jchar > &) const;
      StringBuffer insert(jint, const ::java::lang::String &) const;
      StringBuffer insert(jint, jboolean) const;
      StringBuffer insert(jint, jchar) const;
      StringBuffer insert(jint, jdouble) const;
      StringBuffer insert(jint, jfloat) const;
      StringBuffer insert(jint, jint) const;
      StringBuffer insert(jint, const ::java::lang::CharSequence &) const;
      StringBuffer insert(jint, const ::java::lang::Object &) const;
      StringBuffer insert(jint, jlong) const;
      StringBuffer insert(jint, const JArray< jchar > &, jint, jint) const;
      StringBuffer insert(jint, const ::java::lang::CharSequence &, jint, jint) const;
      jint lastIndexOf(const ::java::lang::String &) const;
      jint lastIndexOf(const ::java::lang::String &, jint) const;
      jint length() const;
      jint offsetByCodePoints(jint, jint) const;
      StringBuffer repeat(jint, jint) const;
      StringBuffer repeat(const ::java::lang::CharSequence &, jint) const;
      StringBuffer replace(jint, jint, const ::java::lang::String &) const;
      StringBuffer reverse() const;
      void setCharAt(jint, jchar) const;
      void setLength(jint) const;
      ::java::lang::CharSequence subSequence(jint, jint) const;
      ::java::lang::String substring(jint) const;
      ::java::lang::String substring(jint, jint) const;
      ::java::lang::String toString() const;
      void trimToSize() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(StringBuffer);
    extern PyTypeObject *PY_TYPE(StringBuffer);

    class t_StringBuffer {
    public:
      PyObject_HEAD
      StringBuffer object;
      static PyObject *wrap_Object(const StringBuffer&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
