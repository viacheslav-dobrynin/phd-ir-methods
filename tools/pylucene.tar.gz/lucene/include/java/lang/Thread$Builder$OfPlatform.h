#ifndef java_lang_Thread$Builder$OfPlatform_H
#define java_lang_Thread$Builder$OfPlatform_H

#include "java/lang/Thread$Builder.h"

namespace java {
  namespace lang {
    class Thread$Builder$OfPlatform;
    class ThreadGroup;
    class Thread$UncaughtExceptionHandler;
    class Class;
    class String;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class Thread$Builder$OfPlatform : public ::java::lang::Thread$Builder {
     public:
      enum {
        mid_daemon_822028d5e07de8f3,
        mid_daemon_fe33f9075c8b3961,
        mid_group_277e9b1b481cc8cc,
        mid_inheritInheritableThreadLocals_fe33f9075c8b3961,
        mid_name_9082ecfa02723b73,
        mid_name_e094ceafd017c910,
        mid_priority_ad1b515474f0ee4f,
        mid_stackSize_b04de543f3e11f61,
        mid_uncaughtExceptionHandler_a194761fc575a489,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit Thread$Builder$OfPlatform(jobject obj) : ::java::lang::Thread$Builder(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      Thread$Builder$OfPlatform(const Thread$Builder$OfPlatform& obj) : ::java::lang::Thread$Builder(obj) {}

      Thread$Builder$OfPlatform daemon() const;
      Thread$Builder$OfPlatform daemon(jboolean) const;
      Thread$Builder$OfPlatform group(const ::java::lang::ThreadGroup &) const;
      Thread$Builder$OfPlatform inheritInheritableThreadLocals(jboolean) const;
      Thread$Builder$OfPlatform name(const ::java::lang::String &) const;
      Thread$Builder$OfPlatform name(const ::java::lang::String &, jlong) const;
      Thread$Builder$OfPlatform priority(jint) const;
      Thread$Builder$OfPlatform stackSize(jlong) const;
      Thread$Builder$OfPlatform uncaughtExceptionHandler(const ::java::lang::Thread$UncaughtExceptionHandler &) const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(Thread$Builder$OfPlatform);
    extern PyTypeObject *PY_TYPE(Thread$Builder$OfPlatform);

    class t_Thread$Builder$OfPlatform {
    public:
      PyObject_HEAD
      Thread$Builder$OfPlatform object;
      static PyObject *wrap_Object(const Thread$Builder$OfPlatform&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
