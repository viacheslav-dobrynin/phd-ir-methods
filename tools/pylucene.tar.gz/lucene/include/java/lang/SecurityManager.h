#ifndef java_lang_SecurityManager_H
#define java_lang_SecurityManager_H

#include "java/lang/Object.h"

namespace java {
  namespace io {
    class FileDescriptor;
  }
  namespace lang {
    class ThreadGroup;
    class Class;
    class String;
    class Thread;
  }
}
template<class T> class JArray;

namespace java {
  namespace lang {

    class SecurityManager : public ::java::lang::Object {
     public:
      enum {
        mid_init$_a5783a25d44ba15b,
        mid_checkAccept_2af0dd68bf156a84,
        mid_checkAccess_50a064a6cccf8c46,
        mid_checkAccess_ca2f14ec90ee6ac0,
        mid_checkConnect_2af0dd68bf156a84,
        mid_checkConnect_03ea7aa9afa6eb33,
        mid_checkCreateClassLoader_a5783a25d44ba15b,
        mid_checkDelete_9b22ecdee06ea23c,
        mid_checkExec_9b22ecdee06ea23c,
        mid_checkExit_8730ba9dfaf23a7b,
        mid_checkLink_9b22ecdee06ea23c,
        mid_checkListen_8730ba9dfaf23a7b,
        mid_checkPackageAccess_9b22ecdee06ea23c,
        mid_checkPackageDefinition_9b22ecdee06ea23c,
        mid_checkPrintJobAccess_a5783a25d44ba15b,
        mid_checkPropertiesAccess_a5783a25d44ba15b,
        mid_checkPropertyAccess_9b22ecdee06ea23c,
        mid_checkRead_9b5eb160f6c6621d,
        mid_checkRead_9b22ecdee06ea23c,
        mid_checkRead_00a4ee7ce7c1b7b5,
        mid_checkSecurityAccess_9b22ecdee06ea23c,
        mid_checkSetFactory_a5783a25d44ba15b,
        mid_checkWrite_9b5eb160f6c6621d,
        mid_checkWrite_9b22ecdee06ea23c,
        mid_getSecurityContext_1543ec1f1674e5aa,
        mid_getThreadGroup_2cc430c63cee02d8,
        mid_getClassContext_809ada818e927c0c,
        max_mid
      };

      static ::java::lang::Class *class$;
      static jmethodID *mids$;
      static bool live$;
      static jclass initializeClass(bool);

      explicit SecurityManager(jobject obj) : ::java::lang::Object(obj) {
        if (obj != NULL && mids$ == NULL)
          env->getClass(initializeClass);
      }
      SecurityManager(const SecurityManager& obj) : ::java::lang::Object(obj) {}

      SecurityManager();

      void checkAccept(const ::java::lang::String &, jint) const;
      void checkAccess(const ::java::lang::Thread &) const;
      void checkAccess(const ::java::lang::ThreadGroup &) const;
      void checkConnect(const ::java::lang::String &, jint) const;
      void checkConnect(const ::java::lang::String &, jint, const ::java::lang::Object &) const;
      void checkCreateClassLoader() const;
      void checkDelete(const ::java::lang::String &) const;
      void checkExec(const ::java::lang::String &) const;
      void checkExit(jint) const;
      void checkLink(const ::java::lang::String &) const;
      void checkListen(jint) const;
      void checkPackageAccess(const ::java::lang::String &) const;
      void checkPackageDefinition(const ::java::lang::String &) const;
      void checkPrintJobAccess() const;
      void checkPropertiesAccess() const;
      void checkPropertyAccess(const ::java::lang::String &) const;
      void checkRead(const ::java::io::FileDescriptor &) const;
      void checkRead(const ::java::lang::String &) const;
      void checkRead(const ::java::lang::String &, const ::java::lang::Object &) const;
      void checkSecurityAccess(const ::java::lang::String &) const;
      void checkSetFactory() const;
      void checkWrite(const ::java::io::FileDescriptor &) const;
      void checkWrite(const ::java::lang::String &) const;
      ::java::lang::Object getSecurityContext() const;
      ::java::lang::ThreadGroup getThreadGroup() const;
    };
  }
}

#include <Python.h>

namespace java {
  namespace lang {
    extern PyType_Def PY_TYPE_DEF(SecurityManager);
    extern PyTypeObject *PY_TYPE(SecurityManager);

    class t_SecurityManager {
    public:
      PyObject_HEAD
      SecurityManager object;
      static PyObject *wrap_Object(const SecurityManager&);
      static PyObject *wrap_jobject(const jobject&);
      static void install(PyObject *module);
      static void initialize(PyObject *module);
    };
  }
}

#endif
