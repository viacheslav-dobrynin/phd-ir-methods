
INCLUDES=['/usr/lib/jvm/temurin-21-jdk-amd64/include', '/usr/lib/jvm/temurin-21-jdk-amd64/include/linux']
CFLAGS=['-fno-strict-aliasing', '-Wno-write-strings']
DEBUG_CFLAGS=['-O0', '-g', '-DDEBUG']
LFLAGS=['-L/usr/lib/jvm/temurin-21-jdk-amd64/lib', '-ljava', '-L/usr/lib/jvm/temurin-21-jdk-amd64/lib/server', '-ljvm', '-Wl,-rpath=/usr/lib/jvm/temurin-21-jdk-amd64/lib:/usr/lib/jvm/temurin-21-jdk-amd64/lib/server']
IMPLIB_LFLAGS=[]
SHARED=True
VERSION="3.15"
